/*
 * Mapa.h
 *
 *  Created on: 29/8/2016
 *      Author: utnso
 */

#ifndef MAPA_H_
#define MAPA_H_

#include "Configuracion.h"
#include <commons/config.h>
#include <commons/log.h>
#include <commons/collections/list.h>
#include <netinet/in.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <src/sw_sockets.h>
#include <sys/inotify.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <src/tiposDato.h>
#include <unistd.h>
#include <tad_items.h>
#include <curses.h>
#include <commons/collections/list.h>
#include <nivel.h>

//
#define PUERTO 8000

t_dictionary* diccionarioDePokemonesAtrapados;
t_dictionary* diccionarioDePosiciones;
t_dictionary* recursosDeTodasLasPokenests;
char* mapaActual;
char* charToString(char element) {
	char* new = malloc(2);
	*new = element;
	*(new + 1) = '\0';
	return new;
}

typedef struct entrenador_t {
	uint32_t pid;
	estado_t estado;
	int socket;
	int quantum;
	int posicionEnX;
	int PosicionEnY;
	char* pokenestAPedir;
	char* simboloIdentificador;
	t_list * listaAtrapados;
	t_list * pokemonesSolicitados;
} t_entrenador;

typedef struct cantidadPokemones_t {

	char *pokeparada;
	int cantidadDePokemones;

} t_cantidad_pokemones;

typedef struct t_rutaPoke {
	char* rutaPokemon;
	char*nombrePOkemon;
} rutaPoke_t;

typedef struct recursoPokenest_t {
	int cantidadDeRecurso;
} recursoPokenest;

typedef struct posicionPokenest_t {
	char pokeparada;
	char* posicionDePokenest;
	int posEnX;
	int PosEnY;
} posicionPokenest;

DIR *dir1;
struct dirent *direntp1;
char *rutaDelPokemonAtrapado(char* pokemonAAtrapar, t_list* unLista) {
	DIR *dir;
	struct dirent *direntp;
	char*pokeee;
	char * direccion1 = "/home/utnso/mnt/pokedex/Mapas/";
	char*PokeNests = "/PokeNests";
	char* direccionDePokemonesAAtrapar = malloc(
			strlen(direccion1) + strlen(mapaActual) + strlen(PokeNests) + 1);
	direccionDePokemonesAAtrapar[0] = '\0';
	strcat(direccionDePokemonesAAtrapar, direccion1);
	strcat(direccionDePokemonesAAtrapar, mapaActual);
	strcat(direccionDePokemonesAAtrapar, PokeNests);
	dir = opendir(direccionDePokemonesAAtrapar);
	while ((direntp = readdir(dir)) != NULL) {

		if (strstr(direntp->d_name, pokemonAAtrapar) != NULL) {

			pokeee = direntp->d_name;

		}
	}

	closedir(dir);
	char*usoUnico = malloc(sizeof(pokeee));
	usoUnico[0] = '\0';
	//free(direccionDePokemonesAAtrapar);
	strcat(usoUnico, pokeee);
	 direccionDePokemonesAAtrapar = malloc(
			strlen(direccion1) + strlen(mapaActual) + strlen(usoUnico)
					+ strlen(PokeNests) + strlen("/") + 1);
	direccionDePokemonesAAtrapar[0] = '\0';

	strcat(direccionDePokemonesAAtrapar, direccion1);
	strcat(direccionDePokemonesAAtrapar, mapaActual);
	strcat(direccionDePokemonesAAtrapar, PokeNests);
	strcat(direccionDePokemonesAAtrapar, "/");

	strcat(direccionDePokemonesAAtrapar, usoUnico);

	dir1 = opendir(direccionDePokemonesAAtrapar);
	char* pokeee2;
	bool flagPokemon = true;
	direntp1 = readdir(dir1);
	while (flagPokemon == true) {

		if (strstr(direntp1->d_name, usoUnico) != NULL) {

			if (dictionary_size(diccionarioDePokemonesAtrapados) > 0) {
				if (dictionary_has_key(diccionarioDePokemonesAtrapados,
						direntp1->d_name)) {
					direntp1 = readdir(dir1);

				} else {

					char*dire2 = malloc(
							strlen("/home/utnso/mnt/pokedex/Mapas/")
									+ strlen(mapaActual) + strlen(PokeNests)
									+ strlen(usoUnico) + strlen("/")
									+ strlen("/") + strlen(direntp1->d_name));
					dire2[0] = '\0';
					strcat(dire2, "/home/utnso/mnt/pokedex/Mapas/");
					strcat(dire2, mapaActual);
					strcat(dire2, PokeNests);
					strcat(dire2, "/");
					strcat(dire2, usoUnico);
					strcat(dire2, "/");
					strcat(dire2, direntp1->d_name);
					char*unaWord = malloc(strlen(direntp1->d_name));
					unaWord[0] = '\0';
					strcat(unaWord, direntp1->d_name);
					rutaPoke_t* unpokemonsote = malloc(sizeof(rutaPoke_t));
					unpokemonsote->nombrePOkemon = unaWord;
					unpokemonsote->rutaPokemon = dire2;
					if (!string_ends_with(unpokemonsote->nombrePOkemon, ".dat")) {
									bool flag = true;
									int j = 0;
									while (flag) {
										if ('.' == unpokemonsote->nombrePOkemon[j]) {
											if ('d' == unpokemonsote->nombrePOkemon[j + 1]) {
												if ('a' == unpokemonsote->nombrePOkemon[j + 2]) {
													if ('t' == unpokemonsote->nombrePOkemon[j + 3]) {
														unpokemonsote->nombrePOkemon[j + 4] = '\0';
														flag = false;
													}
												}
											}
										}
										j++;
									}
								}

								if (!string_ends_with(unpokemonsote->rutaPokemon , ".dat")) {
									bool flag = true;
									int j = 0;
									while (flag) {
										if ('.' == unpokemonsote->rutaPokemon [j]) {
											if ('d' == unpokemonsote->rutaPokemon [j + 1]) {
												if ('a' == unpokemonsote->rutaPokemon [j + 2]) {
													if ('t' == unpokemonsote->rutaPokemon [j + 3]) {
														unpokemonsote->rutaPokemon [j + 4] = '\0';
														flag = false;
													}
												}
											}
										}
										j++;
									}
								}
					dictionary_put(diccionarioDePokemonesAtrapados,
							direntp1->d_name, unpokemonsote);
					list_add(unLista, unpokemonsote);
					pokeee2 = dire2;

					flagPokemon = false;

				}
			} else {
				char*dire2 = malloc(
						strlen("/home/utnso/mnt/pokedex/Mapas/")
								+ strlen(mapaActual) + strlen(PokeNests)
								+ strlen(usoUnico) + strlen("/") + strlen("/")
								+ strlen(direntp1->d_name));
				dire2[0] = '\0';
				strcat(dire2, "/home/utnso/mnt/pokedex/Mapas/");
				strcat(dire2, mapaActual);
				strcat(dire2, PokeNests);
				strcat(dire2, "/");
				strcat(dire2, usoUnico);
				strcat(dire2, "/");
				strcat(dire2, direntp1->d_name);

				char*unaWord = malloc(strlen(direntp1->d_name));
				unaWord[0] = '\0';
				strcat(unaWord, direntp1->d_name);
				rutaPoke_t* unpokemonsote = malloc(sizeof(rutaPoke_t));
				unpokemonsote->nombrePOkemon = unaWord;
				unpokemonsote->rutaPokemon = dire2;
				if (!string_ends_with(unpokemonsote->nombrePOkemon, ".dat")) {
								bool flag = true;
								int j = 0;
								while (flag) {
									if ('.' == unpokemonsote->nombrePOkemon[j]) {
										if ('d' == unpokemonsote->nombrePOkemon[j + 1]) {
											if ('a' == unpokemonsote->nombrePOkemon[j + 2]) {
												if ('t' == unpokemonsote->nombrePOkemon[j + 3]) {
													unpokemonsote->nombrePOkemon[j + 4] = '\0';
													flag = false;
												}
											}
										}
									}
									j++;
								}
							}

							if (!string_ends_with(unpokemonsote->rutaPokemon , ".dat")) {
								bool flag = true;
								int j = 0;
								while (flag) {
									if ('.' == unpokemonsote->rutaPokemon [j]) {
										if ('d' == unpokemonsote->rutaPokemon [j + 1]) {
											if ('a' == unpokemonsote->rutaPokemon [j + 2]) {
												if ('t' == unpokemonsote->rutaPokemon [j + 3]) {
													unpokemonsote->rutaPokemon [j + 4] = '\0';
													flag = false;
												}
											}
										}
									}
									j++;
								}
							}

				dictionary_put(diccionarioDePokemonesAtrapados,
						direntp1->d_name, unpokemonsote);
				list_add(unLista, unpokemonsote);
				pokeee2 = dire2;
				//			free(dire2);
				flagPokemon = false;

			}

		} else {
			direntp1 = readdir(dir1);
		}
	}

	free(direccionDePokemonesAAtrapar);
	closedir(dir1);
	return pokeee2;
}

void actualizarDibujo(t_list* items, t_entrenador *unEntrenador) {
	int y = 0;
	while (list_size(unEntrenador->listaAtrapados) != 0) {
		rutaPoke_t* L1 = list_remove(unEntrenador->listaAtrapados, 0);
		rutaPoke_t* L2 = dictionary_remove(diccionarioDePokemonesAtrapados,
				L1->nombrePOkemon);
		//verificar esto!!!!!!!!!!!!!!!!!!!!!!
		char* pokeparadaABorrar = charToString(L2->nombrePOkemon[0]);
		recursoPokenest* unaPoke2 = (recursoPokenest*) dictionary_get(
				recursosDeTodasLasPokenests, pokeparadaABorrar);
		unaPoke2->cantidadDeRecurso++;

		/////

		posicionPokenest* unaPos = dictionary_get(diccionarioDePosiciones,
				charToString(L2->nombrePOkemon[0]));
		//BorrarItem(items, L2->nombrePOkemon[0]);

		t_cantidad_pokemones * pokei;

		///aca rompe en lo unico
		bool trucho=true;
		while(trucho ==true){
		pokei = list_get(cantidadDePokemones, y);
		if (pokei->pokeparada[0] == unaPos->pokeparada) {
			pokei->cantidadDePokemones++;
			y=0;
			trucho=false;
		}else{
			y++;
		}
		}

		sumarRecurso(items, pokei->pokeparada[0]);
//		CrearCaja(items, pokei->pokeparada[0],
//				obtenerCoordenadaEnX(unaPos->posicionDePokenest),
//				obtenerCoodenadaEnY(unaPos->posicionDePokenest),
//				pokei->cantidadDePokemones);
//		CrearItem(items,pokei->pokeparada[0],obtenerCoordenadaEnX(unaPos->posicionDePokenest),
//				obtenerCoodenadaEnY(unaPos->posicionDePokenest),'E',pokei->cantidadDePokemones);

	}
	list_destroy(unEntrenador->listaAtrapados);

	while (list_size(unEntrenador->pokemonesSolicitados) != 0) {
		list_remove(unEntrenador->pokemonesSolicitados, 0);

	}
	list_destroy(unEntrenador->pokemonesSolicitados);
}

void restarPokeparada(char* pokenest) {
	posicionPokenest* unaPos = dictionary_get(diccionarioDePosiciones,
			pokenest);
//	recursoPokenest* unaPoke2 = (recursoPokenest*) dictionary_get(
//				recursosDeTodasLasPokenests, pokenest);
//	unaPoke2->cantidadDeRecurso--;
	int u = list_size(cantidadDePokemones);
	t_cantidad_pokemones * pokei;
	int y = 0;
	bool flag = true;
	while (u != 0 && flag == true) {

		pokei = list_get(cantidadDePokemones, y);
		if (pokei->pokeparada[0] == unaPos->pokeparada) {
			pokei->cantidadDePokemones--;
			flag = false;
		} else {
			y++;
			u--;
		}
	}
}

//ver mas adelante el tema de memori leaks
int obtenerCoordenadaEnX(char* posicion) {

	char *a = ";";
	char*palabra = charToString(a[0]);
	int contador = 0;
	int i = 0;
	while (posicion[i] != palabra[0]) {
		contador++;
		i++;
	}

	contador--;
	int j = 1;

	char*pos1 = charToString(posicion[0]);
	while (contador != 0) {
		char*pos2 = charToString(posicion[j]);
		strcat(pos1, pos2);
		j++;

		contador--;
	}

	return atoi(pos1);
}

//ver mas adelante el tema de memori leaks
int obtenerCoodenadaEnY(char* posicion) {
	char *a = ";";
	char*palabra = charToString(a[0]);
	int contador = 0;
	int i = 0;
	while (posicion[i] != palabra[0]) {
		contador++;
		i++;
	}
	contador += 1;

	char*pos1 = charToString(posicion[contador]);
	int j = contador + 1;
	char *b = "\0";
	char*palabra2 = charToString(b[0]);
	while (posicion[j] != palabra2[0]) {
		char*pos2 = charToString(posicion[j]);
		strcat(pos1, pos2);
		j++;

	}
	return atoi(pos1);

}

///////////////////////esto para deadlock verlo despuessssssss
//////////////////////////////////////////////////////////////
/*aca sacariamos por ejemplo Pikachu001 que nos sirva para darselo al segundo parametro eso sirve para mapa*/
void hol() {

//			char *str = malloc(sizeof(mensajeARecibir.texto));
//			str = mensajeARecibir.texto;
	char *str = malloc(sizeof(1));
	str = "";
	const char ch = 'B';
	char *ret;

	ret = strrchr(str, ch);
	printf("%s\n", ret);

	/*flag del momento para el while y que me devuelva pikachu en vez de pikachu001 esto sirve en mapa*/
	bool delMomento = true;
	int w = 0;

	char*pokemon = malloc(strlen(ret) + 1);
	pokemon[0] = '\0';
	while (delMomento) {
		if (isalpha(ret[w])) {
			char *elem = charToString(ret[w]);
			strcat(pokemon, elem);
			w++;

		} else {
			delMomento = false;
		}
	}
	int e = 0;
	int ContadorNuevo = 0;

	printf("%s\n", pokemon);
}

#endif /* MAPA_H_ */
