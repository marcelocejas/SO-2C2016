/*
 * Configuracion.h
 *
 *  Created on: 29/8/2016
 *      Author: utnso
 */

#ifndef CONFIGURACION_H_
#define CONFIGURACION_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <commons/config.h>
#include <commons/collections/list.h>
#include <pkmn/battle.h>
#include <pkmn/factory.h>
#include <sys/types.h>
#include <dirent.h>

#define CANTIDAD_PARAMETROS_CONFIG  7

typedef struct configInfo {
	int TiempoChequeoDeadLock;
	int Batalla;
	char*algoritmo;
	int quantum;
	int retardo;
	char* IP;
	int puerto;
} t_config_server;


typedef struct configPokeNest {
	char* Tipo;
	char* Posicion;
	char* Identificador;
	} t_config_PokeNest;



	t_pkmn_factory* factory;
	t_list * listaPokenests;
	t_list * listaDePokemones;
	t_list* cantidadDePokemones;

int cargarConfiguracion(char*, t_config_server*);
int cargarConfigDePokemon( char *,char *);
void finalizarConfig(void);


#endif /* CONFIGURACION_H_ */
