/*
 * Configuracion.c
 *
 *  Created on: 29/8/2016
 *      Author: utnso
 */


#include "Configuracion.h"
t_config *tConfig;

t_config *tConfig3;


int cargarConfigGeneral(char* archivoRuta, t_config_server* configServer ) {
	// Genero tabla de configuracion
	tConfig = config_create(archivoRuta);
	if (tConfig == NULL) {
		printf("ERROR: no se encuentra o falta el archivo de configuracion en la direccion \t%s \n", archivoRuta);

		return 0;
	}
	// Verifico que el archivo de configuracion tenga la cantidad de parametros correcta.
	if (config_keys_amount(tConfig) == CANTIDAD_PARAMETROS_CONFIG) {
		// Verifico que los parametros tengan sus valores OK
		// Verifico parametro PUERTO
		if (config_has_property(tConfig, "TiempoChequeoDeadLock")) {
					configServer->TiempoChequeoDeadLock = config_get_int_value(tConfig, "TiempoChequeoDeadLock");
				} else {
					printf("ERROR: Falta el parametro: %s. \n", "TiempoChequeoDeadLock");
					return 1;
				}
		if (config_has_property(tConfig, "Batalla")) {
					configServer->Batalla = config_get_int_value(tConfig, "Batalla");
				} else {
					printf("ERROR: Falta el parametro: %s. \n", "Batalla");
					return 1;
				}

		if (config_has_property(tConfig, "algoritmo")) {
							configServer->algoritmo = config_get_string_value(tConfig, "algoritmo");
						} else {
							printf("ERROR: Falta el parametro: %s. \n", "algoritmo");
							return 1;
						}
		if (config_has_property(tConfig, "quantum")) {
							configServer->quantum = config_get_int_value(tConfig, "quantum");
						} else {
							printf("ERROR: Falta el parametro: %s. \n", "quantum");
							return 1;
						}
		if (config_has_property(tConfig, "retardo")) {
									configServer->retardo= config_get_int_value(tConfig, "retardo");
								} else {
									printf("ERROR: Falta el parametro: %s. \n", "retardo");
									return 1;
								}
		if (config_has_property(tConfig, "IP")) {
									configServer->IP = config_get_string_value(tConfig, "IP");
								} else {
									printf("ERROR: Falta el parametro: %s. \n", "IP");
									return 1;
								}
		if (config_has_property(tConfig, "PUERTO")) {
			configServer->puerto = config_get_int_value(tConfig, "PUERTO");
		} else {
			printf("ERROR: Falta el parametro: %s. \n", "PUERTO");
			return 1;
		}

//		printf("el tiempo de chequeo del DeadLock es:%d\n,la batalla esta en modo:%d\n,el algoritmo de planificacion es:%s\n,el quantum es:%d\n el retardo es:%d\n la IP es:%s\n y el PUERTO es: %d\n",
//				configServer->TiempoChequeoDeadLock,
//				configServer->Batalla,
//				configServer->algoritmo,
//				configServer->quantum,
//				configServer->retardo,
//				configServer->IP,
//				configServer->puerto);
		return 1;
	} else {
		printf("ERROR: El archivo SERVER.cfg no tiene los %d campos que debería.\n", CANTIDAD_PARAMETROS_CONFIG);
		return 0;
	}
}









void finalizarConfig() {
	config_destroy(tConfig);
	config_destroy(tConfig3);
}
