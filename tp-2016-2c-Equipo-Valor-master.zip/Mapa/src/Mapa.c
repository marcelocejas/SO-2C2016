/*
 ============================================================================
 Name        : Mapa.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "Mapa.h"
extern t_list* listaPokenests;

t_config *tConfig2;

//semaforos necesarios dentro de la funcion que atiende a los entrenadores
t_list * listaEntrenadoresListos;

t_list * listaAuxiliar;
//para deadlock
t_list *listaEntrenadoresParaCrearMatriz;
t_list *listaDePokemonesParaCrearMatriz;

t_pokemon* unPokemon;
t_list * listaPrioridad;
t_list *listaDeadLock;
pthread_mutex_t sem_entradores;
pthread_mutex_t sem_DeadLockAtiende;
pthread_mutex_t sem_DeadLockAPlanificador;
t_log* logger_mapa;
pthread_mutex_t sem_log;
sem_t semaforo_EntrenadorLibre;
sem_t vamoAsincronizarno;
sem_t s;
sem_t h;
sem_t mx;
pthread_t roundRobin_thread;
pthread_t deadlock_thread;
//hilo necesario para atender a cada entrenador
pthread_t entrenador_thread;
//hilo para crear el mapa

pthread_mutex_t sem_de_mapa;
sem_t semaforo_Entrenadorbloqueado;

t_config_server* ClienteConfig;

t_config_PokeNest* ClienteConfig3;
t_list* items;
int rows, cols;

bool flagMacabro;
bool superNecesario = false;
bool flagDeadlockMolesto = false;
//cosas para el deadlock
int **matrizSolicitud;
int **matrizAsignacion;
int *vectorDisponibles;
int cantidadDePokeparadas = 0;
void crearMatrizSolicitudYAsignacion();
bool atenderPrimeraBloqueadoYdespuesContinuar = false;

int recursodePokenestSolicitado(char* pokenestSolicitada) {
	//como el nombre lo dice resta la pokenest que el entrenador solicita cuando atrapa un mapa
	int x;
	//recursoPokenest* unaPoke = malloc(sizeof(recursoPokenest));
	recursoPokenest* unaPoke2 = (recursoPokenest*) dictionary_get(
			recursosDeTodasLasPokenests, pokenestSolicitada);
	x = unaPoke2->cantidadDeRecurso;
	if (x != 0) {
		unaPoke2->cantidadDeRecurso--;
//		unaPoke->cantidadDeRecurso = unaPoke2->cantidadDeRecurso;
//		dictionary_remove(recursosDeTodasLasPokenests, pokenestSolicitada);
//		dictionary_put(recursosDeTodasLasPokenests, pokenestSolicitada,
//				(void*) unaPoke);
	}
//	else {
//		free(unaPoke);
//	}
	return x;

}
bool flagRoundRobin = true;
bool flagSRDF = false;
bool flagSemaforo;
void atiendeClienteEntrenador(t_entrenador * unEntrenador,
		mensaje_MAPA_ENTRENADOR mensajeARecibir) {
	// el mensaje al entrenador por ahora no sirve pero va a servir
	mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
	char*dispositivo;
	int valor;
	int valorcito;
	t_entrenador *unEntre;

	switch (mensajeARecibir.protocolo) {
	case INICIARJUEGO:

		CrearPersonaje(items, mensajeARecibir.texto[0], 0, 0);
		nivel_gui_dibujar(items, mapaActual);
		////agregar las vidas al principio tambien
		unEntrenador->simboloIdentificador = mensajeARecibir.texto;
		mensajeAEntrenador.protocolo = ACEPTARSOLICITUD;
		mensajeAEntrenador.quantum = ClienteConfig->quantum;
		if (!strcmp(ClienteConfig->algoritmo, "RR")) {
			mensajeAEntrenador.algoritmo = 1;
		} else {
			mensajeAEntrenador.algoritmo = 0;
		}
		enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
				mensajeAEntrenador);
		pthread_mutex_unlock(&sem_entradores);
		//pthread_mutex_unlock(&sem_DeadLockAtiende);
		flagSemaforo = true;
		break;

	case PEDIRPOKENEST:
		// cuando pide pokenest dependiendo el algoritmo hace algo
		//para srdf estan los semaforos para planificar
		mensajeAEntrenador.protocolo = ENVIARLOCALIZACIONPOKENEST;

		if (strcmp(ClienteConfig->algoritmo, "RR")) {

			//saca de la lista auxiliar para planificar en el SRDF
			if (list_size(listaEntrenadoresListos) > 1
					|| list_size(listaPrioridad) >= 1) {
				unEntrenador->posicionEnX = mensajeARecibir.valor;
				unEntrenador->PosicionEnY = mensajeARecibir.valor2;
				unEntrenador->pokenestAPedir = mensajeARecibir.texto;
				list_add(listaAuxiliar, (void*) unEntrenador);
				list_remove(listaEntrenadoresListos, 0);
				mensajeAEntrenador.protocolo = OKEY;
				enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
						mensajeAEntrenador);

			} else {

				sem_wait(&s);
				sem_wait(&mx);

				//pthread_mutex_lock(&sem_entradores);

				unEntrenador->posicionEnX = mensajeARecibir.valor;
				unEntrenador->PosicionEnY = mensajeARecibir.valor2;
				unEntrenador->pokenestAPedir = mensajeARecibir.texto;
				list_add(listaAuxiliar, (void*) unEntrenador);
				list_remove(listaEntrenadoresListos, 0);
				if (list_size(listaEntrenadoresListos) >= 1) {

					//esto esta al pedo

					int w = 0;
					while (w < list_size(listaEntrenadoresListos)) {
						t_entrenador* unEntre = list_get(
								listaEntrenadoresListos, w);
						list_add(listaAuxiliar, unEntre);
						list_remove(listaEntrenadoresListos, w);
						w++;

					}
					w = 0;
				}

				//pthread_mutex_unlock(&sem_entradores);
				pthread_mutex_unlock(&sem_entradores);
				sem_post(&mx);
				sem_post(&h);
				sem_wait(&semaforo_EntrenadorLibre);
				//pthread_mutex_lock(&sem_entradores);
				pthread_mutex_lock(&sem_entradores);
				if (list_size(listaAuxiliar) == 0) {
					posicionPokenest* unaPosi =
							(posicionPokenest*) dictionary_get(
									diccionarioDePosiciones,
									mensajeARecibir.texto);
					mensajeAEntrenador.texto = malloc(
							strlen(unaPosi->posicionDePokenest) + 1);
					strcpy(mensajeAEntrenador.texto,
							unaPosi->posicionDePokenest);
					enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
							mensajeAEntrenador);
				} else {
					//pthread_mutex_unlock(&sem_entradores);
					//pthread_mutex_lock(&sem_entradores);
					t_entrenador * entrenadorAAgregar22 = list_get(
							listaEntrenadoresListos, 0);
					posicionPokenest* unaPosi =
							(posicionPokenest*) dictionary_get(
									diccionarioDePosiciones,
									entrenadorAAgregar22->pokenestAPedir);
					mensajeAEntrenador.texto = malloc(
							strlen(unaPosi->posicionDePokenest) + 1);
					strcpy(mensajeAEntrenador.texto,
							unaPosi->posicionDePokenest);
					enviarMensajeEntreMapaYEntrenador(
							entrenadorAAgregar22->socket, mensajeAEntrenador);
					//pthread_mutex_unlock(&sem_entradores);
				}
			}
		} else {
			//pthread_mutex_lock(&sem_entradores);
			unEntrenador->pokenestAPedir = mensajeARecibir.texto;
			posicionPokenest* unaPosi = (posicionPokenest*) dictionary_get(
					diccionarioDePosiciones, mensajeARecibir.texto);
			mensajeAEntrenador.texto = malloc(
					strlen(unaPosi->posicionDePokenest) + 1);
			strcpy(mensajeAEntrenador.texto, unaPosi->posicionDePokenest);
			enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
					mensajeAEntrenador);

		}
		//pthread_mutex_unlock(&sem_entradores);
		usleep(ClienteConfig->retardo*1000);
		pthread_mutex_unlock(&sem_entradores);
		//pthread_mutex_unlock(&sem_DeadLockAtiende);
		flagSemaforo = true;
		break;

	case AVANZARUNAPOSICION:
		if (mensajeARecibir.valor >= 0) {
			valor = mensajeARecibir.valor++;
		} else {
			valor = mensajeARecibir.valor--;
		}
		MoverPersonaje(items, mensajeARecibir.texto[0], valor,
				mensajeARecibir.valor2);

		nivel_gui_dibujar(items, mapaActual);

		mensajeAEntrenador.protocolo = MOVIMIENTOREALIZADO;

		enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
				mensajeAEntrenador);
		pthread_mutex_unlock(&sem_entradores);
		//pthread_mutex_unlock(&sem_DeadLockAtiende);
		flagSemaforo = true;
		break;

	case MOVERENX:
		MoverPersonaje(items, mensajeARecibir.texto[0], mensajeARecibir.valor,
				mensajeARecibir.valor2);
		nivel_gui_dibujar(items, mapaActual);

		mensajeAEntrenador.protocolo = MOVIMIENTOREALIZADO;

		enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
				mensajeAEntrenador);
		pthread_mutex_unlock(&sem_entradores);
		//pthread_mutex_unlock(&sem_DeadLockAtiende);
		flagSemaforo = true;
		break;
	case MOVERENY:
		MoverPersonaje(items, mensajeARecibir.texto[0], mensajeARecibir.valor2,
				mensajeARecibir.valor);
		nivel_gui_dibujar(items, mapaActual);

		mensajeAEntrenador.protocolo = MOVIMIENTOREALIZADO;

		enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
				mensajeAEntrenador);
		pthread_mutex_unlock(&sem_entradores);
		//pthread_mutex_unlock(&sem_DeadLockAtiende);
		flagSemaforo = true;
		break;

	case ATRAPARPOKEMON:

		if (recursodePokenestSolicitado(mensajeARecibir.texto) > 0) {
			//pthread_mutex_lock(&sem_entradores);
			restarRecurso(items, mensajeARecibir.texto[0]);
			nivel_gui_dibujar(items, mapaActual);
			mensajeAEntrenador.protocolo = CAPTURAREALIZADA;
			mensajeAEntrenador.texto = rutaDelPokemonAtrapado(
					mensajeARecibir.texto, unEntrenador->listaAtrapados);
			restarPokeparada(mensajeARecibir.texto);
			verificarLasListas(unEntrenador->listaAtrapados,
					unEntrenador->pokemonesSolicitados);
			enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
					mensajeAEntrenador);
			flagSemaforo = true;
			pthread_mutex_unlock(&sem_entradores);
			//pthread_mutex_unlock(&sem_DeadLockAtiende);
		} else {
			//enviamos protocolo deadlock para que entrenador nos envie el mejor pokemon
			//lo pongo en la lista de deadlock  en paralelo detecto con el algoritmo el deadlock
			if (ClienteConfig->Batalla == 1) {

				if (!strcmp(ClienteConfig->algoritmo, "RR")) {
					sem_wait(&s);
					sem_wait(&mx);
					//pthread_mutex_lock(&sem_DeadLockAtiende);
					mensajeAEntrenador.protocolo = DEADLOCK;
					t_entrenador* entrenadorDeadlok = list_get(
							listaEntrenadoresListos, 0);
					list_add(listaDeadLock, entrenadorDeadlok);
					list_remove(listaEntrenadoresListos, 0);

					rutaPoke_t* unpokemonsote = malloc(sizeof(rutaPoke_t));
					unpokemonsote->nombrePOkemon = unEntrenador->pokenestAPedir;
					unpokemonsote->rutaPokemon = "nada";

					list_add(unEntrenador->pokemonesSolicitados, unpokemonsote);
					// este mensaje es con el fin de reactivar el select asi atiende a los entrenadores que qdaron

					enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
							mensajeAEntrenador);
					flagRoundRobin = false;

					flagSemaforo = true;
					usleep(ClienteConfig->retardo*1000);
					pthread_mutex_unlock(&sem_entradores);
					//pthread_mutex_unlock(&sem_DeadLockAtiende);
					//superNecesario = true;
					//pthread_mutex_unlock(&sem_DeadLockAtiende);

					sem_post(&mx);
					sem_post(&h);
				} else {
					sem_wait(&s);
					sem_wait(&mx);
					//pthread_mutex_lock(&sem_DeadLockAtiende);

					t_entrenador* entrenadorDeadlok = list_get(
							listaEntrenadoresListos, 0);
					// este mensaje es con el fin de reactivar el select asi atiende a los entrenadores que qdaron
					mensajeAEntrenador.protocolo = DEADLOCK;
					rutaPoke_t* unpokemonsote = malloc(sizeof(rutaPoke_t));
					unpokemonsote->nombrePOkemon = unEntrenador->pokenestAPedir;
					unpokemonsote->rutaPokemon = "nada";

					list_add(unEntrenador->pokemonesSolicitados, unpokemonsote);
					enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
							mensajeAEntrenador);
					list_add(listaDeadLock, entrenadorDeadlok);
					list_remove(listaEntrenadoresListos, 0);
					flagSRDF = true;
					superNecesario = true;
					flagSemaforo = true;
					usleep(ClienteConfig->retardo*1000);
					pthread_mutex_unlock(&sem_entradores);
					//pthread_mutex_unlock(&sem_DeadLockAtiende);
					//pthread_mutex_unlock(&sem_DeadLockAtiende);

					sem_post(&mx);
					sem_post(&h);

				}
			} else {
				//cuando el modo batalla esta desactivado
				//deberiamos hacer lo mismo agregar a a lista de dealock pensarlo mas tarde

				if (!strcmp(ClienteConfig->algoritmo, "RR")) {
					sem_wait(&s);
					sem_wait(&mx);
					//pthread_mutex_lock(&sem_DeadLockAtiende);

					t_entrenador* entrenadorDeadlok = list_get(
							listaEntrenadoresListos, 0);
					list_add(listaDeadLock, entrenadorDeadlok);
					list_remove(listaEntrenadoresListos, 0);

					rutaPoke_t* unpokemonsote = malloc(sizeof(rutaPoke_t));
					unpokemonsote->nombrePOkemon = unEntrenador->pokenestAPedir;
					unpokemonsote->rutaPokemon = "nada";

					list_add(unEntrenador->pokemonesSolicitados, unpokemonsote);
					// este mensaje es con el fin de reactivar el select asi atiende a los entrenadores que qdaron
					mensajeAEntrenador.protocolo = ESPERAR;
					enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
							mensajeAEntrenador);
					flagRoundRobin = false;
					//fijarse flag necesario para round robin
					superNecesario = true;
					//pthread_mutex_unlock(&sem_DeadLockAtiende);
					flagSemaforo = true;
					pthread_mutex_unlock(&sem_entradores);
					//pthread_mutex_unlock(&sem_DeadLockAtiende);
					usleep(ClienteConfig->retardo*1000);
					sem_post(&mx);
					sem_post(&h);
				} else {
					sem_wait(&s);
					sem_wait(&mx);
					//pthread_mutex_lock(&sem_DeadLockAtiende);

					t_entrenador* entrenadorDeadlok = list_get(
							listaEntrenadoresListos, 0);
					// este mensaje es con el fin de reactivar el select asi atiende a los entrenadores que qdaron
					mensajeAEntrenador.protocolo = ESPERAR;
					rutaPoke_t* unpokemonsote = malloc(sizeof(rutaPoke_t));
					unpokemonsote->nombrePOkemon = unEntrenador->pokenestAPedir;
					unpokemonsote->rutaPokemon = "nada";
					unEntrenador->quantum = mensajeARecibir.quantum;
					list_add(unEntrenador->pokemonesSolicitados, unpokemonsote);
					enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
							mensajeAEntrenador);
					list_add(listaDeadLock, entrenadorDeadlok);
					list_remove(listaEntrenadoresListos, 0);
					flagSRDF = true;
					superNecesario = true;
					//pthread_mutex_unlock(&sem_DeadLockAtiende);
					flagSemaforo = true;
					usleep(ClienteConfig->retardo*1000);
					pthread_mutex_unlock(&sem_entradores);
					//pthread_mutex_unlock(&sem_DeadLockAtiende);
					sem_post(&mx);
					sem_post(&h);

				}
			}

		}

		break;
	case DEADLOCK:

		break;
	case FINDEQUANTUM:
		//valorcito = ClienteConfig->retardo-498;
		sem_wait(&s);
		sem_wait(&mx);
		mensajeAEntrenador.protocolo = OKEY;
		mensajeAEntrenador.quantum = ClienteConfig->quantum;
		enviarMensajeEntreMapaYEntrenador(unEntrenador->socket,
				mensajeAEntrenador);
//				sem_post(&semaforo_EntrenadorLibre);
		flagSemaforo = true;
		pthread_mutex_unlock(&sem_entradores);
		usleep(ClienteConfig->retardo*1000);
		sem_post(&mx);
		sem_post(&h);
//				sem_post(&semaforo_EntrenadorLibre);

//		pthread_mutex_unlock(&sem_DeadLockAtiende);

		break;
	}
}

void verificarLasListas(t_list* listaAtrapados, t_list *pokemonesSolicitados) {

	//basicamente esta funcion sirve para cuando un entrenador atrapa un pokemon
	//lo saque de la lista de solicitados si es lo tenia ahi
	int i = list_size(listaAtrapados);
	int j = list_size(pokemonesSolicitados);
	int h = 0;
	int k = 0;
	rutaPoke_t* unpokemonsote2;
	rutaPoke_t* unpokemonsote;
	if (i == 1 && j == 0) {
		i--;
	} else if (j == 1 && i == 0) {
		j--;
	}

	while (i != 0) {

		while (j != 0) {
			unpokemonsote = list_get(listaAtrapados, h);
			unpokemonsote2 = list_get(pokemonesSolicitados, k);
			if (unpokemonsote->nombrePOkemon[0]
					== unpokemonsote2->nombrePOkemon[0]) {
				list_remove(pokemonesSolicitados, k);
				j--;
				k++;
			} else {
				j--;
				k++;
			}

		}
		i--;
		h++;
		j = list_size(pokemonesSolicitados);
		k = 0;

	}

}
fd_set master;
void iniciarEscuchaDeEntrenador() {

	fd_set read_fds;
	struct sockaddr_in remoteaddr;
	int tamanioMaximoDelFd;
	int socketListen;
	int nuevoSocketAceptado;
	int addrlen;
	int i;
	FD_ZERO(&master);
	FD_ZERO(&read_fds);
	socketListen = IniciarSocketServidor(ClienteConfig->puerto);
//	AceptarConexionCliente(socketListen);
	FD_SET(socketListen, &master);
	tamanioMaximoDelFd = socketListen;
	int j = 0;
	int cantidadEntrenadores = 0;

	// por ahora el mensaje a recibir no sirve pero va a servir
	mensaje_MAPA_ENTRENADOR mensajeARecibir;
	while (1) {
		read_fds = master;
		pthread_mutex_lock(&sem_DeadLockAtiende);
		if (select(tamanioMaximoDelFd + 1, &read_fds, NULL, NULL, NULL) == -1) {
			perror("select");
			exit(1);
		}
		for (i = 0; i <= tamanioMaximoDelFd; i++) {
			pthread_mutex_lock(&sem_entradores);

			flagSemaforo = false;
			if (FD_ISSET(i, &read_fds)) {
				if (i == socketListen) {
					addrlen = sizeof(remoteaddr);
					if ((nuevoSocketAceptado = accept(socketListen,
							(struct sockaddr *) &remoteaddr, &addrlen)) == -1) {
						perror("accept");
					} else {
						//pthread_mutex_lock(&sem_entradores);
						FD_SET(nuevoSocketAceptado, &master);
						if (nuevoSocketAceptado > tamanioMaximoDelFd) {
							tamanioMaximoDelFd = nuevoSocketAceptado;
						}

						//creo entrenador nuevo con todas sus propiedades para q juegue en el mapa
						//a medida que se va avanzando en el juego se incrementan las lista
						//que tiene el entenador de ListaAtrapados y pokemonesSolicitados

						t_entrenador* nuevoEntrenador = malloc(
								sizeof(t_entrenador));
						nuevoEntrenador->socket = nuevoSocketAceptado;
						nuevoEntrenador->estado = LIBRE;
						nuevoEntrenador->pid = j;
						nuevoEntrenador->listaAtrapados = list_create();
						nuevoEntrenador->pokemonesSolicitados = list_create();
						j++;
						cantidadEntrenadores++;

						if (ClienteConfig->Batalla == 1) {
							if (list_size(listaAuxiliar)
									== 1&& list_size(listaDeadLock) == 1
									&& atenderPrimeraBloqueadoYdespuesContinuar == true) {
								mensaje_MAPA_ENTRENADOR mensajeAEntrenador2;
								mensaje_MAPA_ENTRENADOR mensajeRecibido2;
								t_entrenador *entrenador34;
								entrenador34 = list_get(listaAuxiliar, 0);
								t_entrenador * entrenador35;
								entrenador35 = list_get(listaDeadLock, 0);
//								if (recibirMensajeEntreMapaYEntrenador(
//										entrenador34->socket, &mensajeRecibido2)
//										<= 0) {
//									list_remove(listaAuxiliar, 0);
//									close(entrenador34->socket);
//									FD_CLR(entrenador34->socket, &master);
//
//									//pthread_mutex_unlock(&sem_entradores);
//									/////considerar para despues las vidas...
//									BorrarItem(items,
//											entrenador34->simboloIdentificador[0]);
//									nivel_gui_dibujar(items, mapaActual);
//									actualizarDibujo(items, entrenador34);
//									nivel_gui_dibujar(items, mapaActual);
//									int k = entrenador34->pid;
//									bool obtenerEntrenador22(void *data) {
//										t_entrenador * unEntrenador12 =
//												(t_entrenador *) data;
//										return (unEntrenador12->pid == k);
//									}
//
//									list_remove_by_condition(
//											listaEntrenadoresParaCrearMatriz,
//											obtenerEntrenador22);
//								}

								if (recursodePokenestSolicitado(
										entrenador35->pokenestAPedir)
										> 0&& atenderPrimeraBloqueadoYdespuesContinuar == true) {

									mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
									mensaje_MAPA_ENTRENADOR mensajeRecibido;
									mensajeAEntrenador.protocolo =
											CAPTURAREALIZADA;
									mensajeAEntrenador.texto =
											rutaDelPokemonAtrapado(
													entrenador35->pokenestAPedir,
													entrenador35->listaAtrapados);
									restarPokeparada(
											entrenador35->pokenestAPedir);
									restarRecurso(items,
											entrenador35->pokenestAPedir[0]);
									verificarLasListas(
											entrenador35->listaAtrapados,
											entrenador35->pokemonesSolicitados);
									if (entrenador35->quantum == 0) {
										entrenador35->quantum =
												ClienteConfig->quantum;

									}
									enviarMensajeEntreMapaYEntrenador(
											entrenador35->socket,
											mensajeAEntrenador);
									list_add(listaAuxiliar, entrenador35);
									list_remove(listaDeadLock, 0);
//									if (recibirMensajeEntreMapaYEntrenador(
//											entrenador35->socket,
//											&mensajeRecibido) > 0) {
//										list_add(listaAuxiliar, entrenador35);
//										list_remove(listaDeadLock, 0);
//									} else {
//										list_remove(listaDeadLock, 0);
//										close(entrenador35->socket);
//										FD_CLR(entrenador35->socket, &master);
//
//										//pthread_mutex_unlock(&sem_entradores);
//										/////considerar para despues las vidas...
//										BorrarItem(items,
//												entrenador35->simboloIdentificador[0]);
//										nivel_gui_dibujar(items, mapaActual);
//										actualizarDibujo(items, entrenador35);
//										nivel_gui_dibujar(items, mapaActual);
//										int k = entrenador35->pid;
//										bool obtenerEntrenador22(void *data) {
//											t_entrenador * unEntrenador12 =
//													(t_entrenador *) data;
//											return (unEntrenador12->pid == k);
//										}
//
//										list_remove_by_condition(
//												listaEntrenadoresParaCrearMatriz,
//												obtenerEntrenador22);
//
//									}
								}
							}
							atenderPrimeraBloqueadoYdespuesContinuar = false;
						}

						///matria necesaria para la deteccion del deadlock
						if (ClienteConfig->Batalla == 1) {
							list_add(listaEntrenadoresParaCrearMatriz,
									nuevoEntrenador);
						}
						///////////////////

						if (!strcmp(ClienteConfig->algoritmo, "RR")) {
							if (list_size(listaEntrenadoresListos) >= 1) {
								list_add(listaAuxiliar,
										(void *) nuevoEntrenador);
							} else {
								list_add(listaEntrenadoresListos,
										(void *) nuevoEntrenador);

							}
						} else {
							///encola en prioridad
							list_add(listaPrioridad, (void*) nuevoEntrenador);

						}

						//pthread_mutex_unlock(&sem_entradores);

					}
				} else {

					//	pthread_mutex_lock(&sem_DeadLockAtiende);
					if (list_size(listaDeadLock) == 0) {
						flagRoundRobin = true;

					}
					//pthread_mutex_unlock(&sem_DeadLockAtiende);
					//pthread_mutex_lock(&sem_entradores);

					///////////////agregado para el algortimo srdf////////////////

					//listaDePrioridad importantisima para el algoritmo srdf
					//su uso basicamente sirve para cuando un entrenador inicia el mapa sea el primero en atenderse
					//para saber su ubicacion a la proxima pokenest y asi poder planificarlo con el resto de los entrenadores
					if (list_size(listaPrioridad) > 0) {
						t_entrenador * entrenador1 = list_get(listaPrioridad,
								0);
						list_add_in_index(listaEntrenadoresListos, 0,
								entrenador1);
						list_remove(listaPrioridad, 0);
					}

					//contemplo alguno de los casos que se puede llegar a dar en caso
					//del que el deadlock este activado
					if (ClienteConfig->Batalla == 1) {

						if (list_size(listaAuxiliar) == 1
								&& list_size(listaEntrenadoresListos) == 0
								&& list_size(listaDeadLock) > 0) {
							t_entrenador* entrenadorNuevo = list_get(
									listaAuxiliar, 0);
							list_add(listaEntrenadoresListos, entrenadorNuevo);
							list_remove(listaAuxiliar, 0);

						}
					}

					bool obtenerEntrenador(void *data) {
						t_entrenador * unEntrenador = (t_entrenador *) data;
//						return (unEntrenador->socket == i);
						return (unEntrenador->socket);
					}

					if (list_size(listaEntrenadoresListos) >= 1) {
						t_entrenador * unEntrenador = list_find(
								listaEntrenadoresListos, obtenerEntrenador);

						//este if con el flagNecesario es importante para el deadlock porque si un entrenador se bloquea
						//el otro no puede seguir en caso de haber dos o mas

						if (superNecesario == true) {
							mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
							mensajeAEntrenador.protocolo =
									ENVIARLOCALIZACIONPOKENEST;
							posicionPokenest* unaPosi =
									(posicionPokenest*) dictionary_get(
											diccionarioDePosiciones,
											unEntrenador->pokenestAPedir);
							mensajeAEntrenador.texto = malloc(
									strlen(unaPosi->posicionDePokenest) + 1);
							strcpy(mensajeAEntrenador.texto,
									unaPosi->posicionDePokenest);
							enviarMensajeEntreMapaYEntrenador(
									unEntrenador->socket, mensajeAEntrenador);

							superNecesario = false;
						}

						//pthread_mutex_unlock(&sem_entradores);
						bool banderita = true;
						//en donde iba i ahora va unEntrenador->socket
						if (recibirMensajeEntreMapaYEntrenador(
								unEntrenador->socket, &mensajeARecibir) <= 0) {
							// si no se recibe mensaje por muerte del entrenador aca se actualiza el dibujo del mapa

							// se lo saca del master y se usa el flag banderita para que no se pueda atender al entrenador

							//pthread_mutex_lock(&sem_entradores);
							close(unEntrenador->socket);
							FD_CLR(unEntrenador->socket, &master);

							//pthread_mutex_unlock(&sem_entradores);
							/////considerar para despues las vidas...
							BorrarItem(items,
									unEntrenador->simboloIdentificador[0]);
							nivel_gui_dibujar(items, mapaActual);
							actualizarDibujo(items, unEntrenador);
							nivel_gui_dibujar(items, mapaActual);

							if (ClienteConfig->Batalla == 0) {
								// considero que si hay uno solo en deadlock que haya quedado anteiormente
								// se puede satifacer el pedidio del pokemon
								if (list_size(listaAuxiliar) == 0
										&& list_size(listaDeadLock) == 1) {
									t_entrenador * entrenador35;

									entrenador35 = list_get(listaDeadLock, 0);

									list_add(listaEntrenadoresListos,
											entrenador35);
									list_remove(listaDeadLock, 0);
									mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
									mensajeAEntrenador.protocolo =
											CAPTURAREALIZADA;
									mensajeAEntrenador.texto =
											rutaDelPokemonAtrapado(
													mensajeARecibir.texto,
													entrenador35->listaAtrapados);
									restarPokeparada(
											entrenador35->pokenestAPedir);
									restarRecurso(items,
											entrenador35->pokenestAPedir[0]);
									verificarLasListas(
											entrenador35->listaAtrapados,
											entrenador35->pokemonesSolicitados);

									enviarMensajeEntreMapaYEntrenador(
											entrenador35->socket,
											mensajeAEntrenador);

								}
							}

							if (ClienteConfig->Batalla == 1) {
								if (list_size(listaAuxiliar) == 0
										&& list_size(listaDeadLock) == 1) {
									t_entrenador * entrenador35;
									entrenador35 = list_get(listaDeadLock, 0);
									if (recursodePokenestSolicitado(
											entrenador35->pokenestAPedir) > 0) {

										mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
										mensaje_MAPA_ENTRENADOR mensajeRecibido;
										mensajeAEntrenador.protocolo =
												CAPTURAREALIZADA;
										mensajeAEntrenador.texto =
												rutaDelPokemonAtrapado(
														entrenador35->pokenestAPedir,
														entrenador35->listaAtrapados);
										restarPokeparada(
												entrenador35->pokenestAPedir);
										restarRecurso(items,
												entrenador35->pokenestAPedir[0]);
										verificarLasListas(
												entrenador35->listaAtrapados,
												entrenador35->pokemonesSolicitados);
										if (entrenador35->quantum == 0) {
											entrenador35->quantum =
													ClienteConfig->quantum;

										}
										enviarMensajeEntreMapaYEntrenador(
												entrenador35->socket,
												mensajeAEntrenador);
										list_add(listaAuxiliar, entrenador35);
										list_remove(listaDeadLock, 0);
//										if (recibirMensajeEntreMapaYEntrenador(
//												entrenador35->socket,
//												&mensajeRecibido) > 0) {
//											list_add(listaAuxiliar,
//													entrenador35);
//											list_remove(listaDeadLock, 0);
//										} else {
//											list_remove(listaDeadLock, 0);
//											close(entrenador35->socket);
//											FD_CLR(entrenador35->socket,
//													&master);
//
//											//pthread_mutex_unlock(&sem_entradores);
//											/////considerar para despues las vidas...
//											BorrarItem(items,
//													entrenador35->simboloIdentificador[0]);
//											nivel_gui_dibujar(items,
//													mapaActual);
//											actualizarDibujo(items,
//													entrenador35);
//											nivel_gui_dibujar(items,
//													mapaActual);
//											int k = entrenador35->pid;
//											bool obtenerEntrenador22(void *data) {
//												t_entrenador * unEntrenador12 =
//														(t_entrenador *) data;
//												return (unEntrenador12->pid == k);
//											}
//
//											list_remove_by_condition(
//													listaEntrenadoresParaCrearMatriz,
//													obtenerEntrenador22);
//
//										}
									}
								}
							}

							///////
							unEntrenador->estado = FINALIZADO;

							banderita = false;
							//pthread_mutex_lock(&sem_entradores);

							///////remueve de la listaEntrenadorresParaCrearMatriz para la detecccion de deadlock
							if (ClienteConfig->Batalla == 1) {
								int k = unEntrenador->pid;
								bool obtenerEntrenador(void *data) {
									t_entrenador * unEntrenador =
											(t_entrenador *) data;
									return (unEntrenador->pid == k);
								}
								if (list_size(listaEntrenadoresParaCrearMatriz)
										> 0) {
									list_remove_by_condition(
											listaEntrenadoresParaCrearMatriz,
											obtenerEntrenador);
								}
							}

							////////////////

							//si borro a un entrenador y es round robin saco de la listaDeEntrenadoresListo
							//y saco uno de la auxiliar en caso de que halla

							if (!strcmp(ClienteConfig->algoritmo, "RR")) {
								if (list_size(listaAuxiliar) > 0) {
									list_remove(listaEntrenadoresListos, 0);
									t_entrenador * unEntrenador28 = list_get(
											listaAuxiliar, 0);
									list_add(listaEntrenadoresListos,
											unEntrenador28);
									list_remove(listaAuxiliar, 0);
								} else {
									list_remove(listaEntrenadoresListos, 0);
								}
								//comprobar que funciona esto para round robin
								//cuando haya un solo entrenador en la lista de bloqueados
								//se debe mandar mensaje de atrapar pokemones y pasarlo
								//a la lista de entrenadoresListos
								//resuevo el caso de que haya solo un entrenador en deadlock
								//y pueda agarrar los recursos

//								if (ClienteConfig->Batalla == 1) {
//									if (list_size(listaAuxiliar) == 0
//											&& list_size(
//													listaEntrenadoresListos)
//													== 0
//											&& list_size(listaDeadLock) == 1) {
//										t_entrenador *entrenador35 = list_get(
//												listaDeadLock, 0);
//										list_add(listaEntrenadoresListos,
//												entrenador35);
//										list_remove(listaDeadLock, 0);
//										mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
//										mensajeAEntrenador.protocolo =
//												CAPTURAREALIZADA;
//										mensajeAEntrenador.texto =
//												rutaDelPokemonAtrapado(
//														entrenador35->pokenestAPedir,
//														entrenador35->listaAtrapados);
//										restarPokeparada(
//												entrenador35->pokenestAPedir);
//										restarRecurso(items,
//												entrenador35->pokenestAPedir[0]);
//										verificarLasListas(
//												entrenador35->listaAtrapados,
//												entrenador35->pokemonesSolicitados);
//
//										enviarMensajeEntreMapaYEntrenador(
//												entrenador35->socket,
//												mensajeAEntrenador);
//									}
//								}

							} else {

								//si borro a un entrenador en SRDF lo que hago es eliminar el entrenador
								//de la listaDeEntrenadoresListos y en caso de q haya 1 o mas en la lista Auxiliar
								//usar el agortimo de seleccion

								list_remove(listaEntrenadoresListos, 0);
								if (list_size(listaAuxiliar) == 1) {
									t_entrenador * entrenador35 = list_get(
											listaAuxiliar, 0);
									list_add(listaEntrenadoresListos,
											entrenador35);
									list_remove(listaAuxiliar, 0);
									// envia un mensaje al entrenador restante
									mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
									mensajeAEntrenador.protocolo =
											ENVIARLOCALIZACIONPOKENEST;
									posicionPokenest* unaPosi =
											(posicionPokenest*) dictionary_get(
													diccionarioDePosiciones,
													entrenador35->pokenestAPedir);
									mensajeAEntrenador.texto = malloc(
											strlen(unaPosi->posicionDePokenest)
													+ 1);
									strcpy(mensajeAEntrenador.texto,
											unaPosi->posicionDePokenest);
									enviarMensajeEntreMapaYEntrenador(
											entrenador35->socket,
											mensajeAEntrenador);

								}

								if (list_size(listaAuxiliar) > 1) {
									algoritmoDeSeleccion();
									t_entrenador* entrenador001 = list_get(
											listaEntrenadoresListos, 0);
									mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
									mensajeAEntrenador.protocolo =
											ENVIARLOCALIZACIONPOKENEST;
									posicionPokenest* unaPosi =
											(posicionPokenest*) dictionary_get(
													diccionarioDePosiciones,
													entrenador001->pokenestAPedir);
									mensajeAEntrenador.texto = malloc(
											strlen(unaPosi->posicionDePokenest)
													+ 1);
									strcpy(mensajeAEntrenador.texto,
											unaPosi->posicionDePokenest);
									enviarMensajeEntreMapaYEntrenador(
											entrenador001->socket,
											mensajeAEntrenador);
								}

								//resuevo el caso de que haya solo un entrenador en deadlock
								//y pueda agarrar los recursos
//								if (ClienteConfig->Batalla == 1) {
//									if (list_size(listaDeadLock) == 1) {
//										t_entrenador * entrenador35;
//										if (recursodePokenestSolicitado(
//												entrenador35->pokenestAPedir)
//												> 0) {
//
//											entrenador35 = list_get(
//													listaDeadLock, 0);
//
//											list_add(listaEntrenadoresListos,
//													entrenador35);
//											list_remove(listaDeadLock, 0);
//											mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
//											mensajeAEntrenador.protocolo =
//													CAPTURAREALIZADA;
//											mensajeAEntrenador.texto =
//													rutaDelPokemonAtrapado(
//															entrenador35->pokenestAPedir,
//															entrenador35->listaAtrapados);
//											restarPokeparada(
//													entrenador35->pokenestAPedir);
//											restarRecurso(items,
//													entrenador35->pokenestAPedir[0]);
//											verificarLasListas(
//													entrenador35->listaAtrapados,
//													entrenador35->pokemonesSolicitados);
//
//											enviarMensajeEntreMapaYEntrenador(
//													entrenador35->socket,
//													mensajeAEntrenador);
//										}
//									}
//								}

							}

							//pthread_mutex_unlock(&sem_entradores);

						}

						sleep(1);

						if (banderita == true) {

							atiendeClienteEntrenador(unEntrenador,
									mensajeARecibir);

						}
//					} else {
//						pthread_mutex_unlock(&sem_entradores);
					}
					if (ClienteConfig->Batalla == 1) {
						if (list_size(listaDeadLock) == 1
								&& list_size(listaEntrenadoresListos) > 0) {
							t_entrenador * entrenador35;
							entrenador35 = list_get(listaDeadLock, 0);
							if (recursodePokenestSolicitado(
									entrenador35->pokenestAPedir) > 0) {

								mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
								mensaje_MAPA_ENTRENADOR mensajeRecibido;
								mensajeAEntrenador.protocolo = CAPTURAREALIZADA;
								mensajeAEntrenador.texto =
										rutaDelPokemonAtrapado(
												entrenador35->pokenestAPedir,
												entrenador35->listaAtrapados);
								restarPokeparada(entrenador35->pokenestAPedir);
								restarRecurso(items,
										entrenador35->pokenestAPedir[0]);
								verificarLasListas(entrenador35->listaAtrapados,
										entrenador35->pokemonesSolicitados);
								if (entrenador35->quantum == 0) {
									entrenador35->quantum =
											ClienteConfig->quantum;

								}
								list_add(listaAuxiliar, entrenador35);
								list_remove(listaDeadLock, 0);
								enviarMensajeEntreMapaYEntrenador(
										entrenador35->socket,
										mensajeAEntrenador);
//								if (recibirMensajeEntreMapaYEntrenador(
//										entrenador35->socket, &mensajeRecibido)
//										> 0) {
//									list_add(listaAuxiliar, entrenador35);
//									list_remove(listaDeadLock, 0);
//								} else {
//									list_remove(listaDeadLock, 0);
//									close(entrenador35->socket);
//									FD_CLR(entrenador35->socket, &master);
//
//									//pthread_mutex_unlock(&sem_entradores);
//									/////considerar para despues las vidas...
//									BorrarItem(items,
//											entrenador35->simboloIdentificador[0]);
//									nivel_gui_dibujar(items, mapaActual);
//									actualizarDibujo(items, entrenador35);
//									nivel_gui_dibujar(items, mapaActual);
//									int k = entrenador35->pid;
//									bool obtenerEntrenador22(void *data) {
//										t_entrenador * unEntrenador12 =
//												(t_entrenador *) data;
//										return (unEntrenador12->pid == k);
//									}
//
//									list_remove_by_condition(
//											listaEntrenadoresParaCrearMatriz,
//											obtenerEntrenador22);
//
//								}
							}
						}
					}

					if (ClienteConfig->Batalla == 1) {
						if (list_size(listaAuxiliar)
								== 1&& list_size(listaDeadLock) == 1
								&& atenderPrimeraBloqueadoYdespuesContinuar == true) {
							mensaje_MAPA_ENTRENADOR mensajeAEntrenador2;
							mensaje_MAPA_ENTRENADOR mensajeRecibido2;
							t_entrenador *entrenador34;
							entrenador34 = list_get(listaAuxiliar, 0);
							t_entrenador * entrenador35;
							entrenador35 = list_get(listaDeadLock, 0);
//							if (recibirMensajeEntreMapaYEntrenador(
//									entrenador34->socket, &mensajeRecibido2)
//									< 0) {
//								list_remove(listaAuxiliar, 0);
//								close(entrenador34->socket);
//								FD_CLR(entrenador34->socket, &master);
//
//								//pthread_mutex_unlock(&sem_entradores);
//								/////considerar para despues las vidas...
//								BorrarItem(items,
//										entrenador34->simboloIdentificador[0]);
//								nivel_gui_dibujar(items, mapaActual);
//								actualizarDibujo(items, entrenador34);
//								nivel_gui_dibujar(items, mapaActual);
//								int k = entrenador34->pid;
//								bool obtenerEntrenador22(void *data) {
//									t_entrenador * unEntrenador12 =
//											(t_entrenador *) data;
//									return (unEntrenador12->pid == k);
//								}
//
//								list_remove_by_condition(
//										listaEntrenadoresParaCrearMatriz,
//										obtenerEntrenador22);
//							}

							if (recursodePokenestSolicitado(
									entrenador35->pokenestAPedir)
									> 0&& atenderPrimeraBloqueadoYdespuesContinuar == true) {

								mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
								mensaje_MAPA_ENTRENADOR mensajeRecibido;
								mensajeAEntrenador.protocolo = CAPTURAREALIZADA;
								mensajeAEntrenador.texto =
										rutaDelPokemonAtrapado(
												entrenador35->pokenestAPedir,
												entrenador35->listaAtrapados);
								restarPokeparada(entrenador35->pokenestAPedir);
								restarRecurso(items,
										entrenador35->pokenestAPedir[0]);
								verificarLasListas(entrenador35->listaAtrapados,
										entrenador35->pokemonesSolicitados);
								if (entrenador35->quantum == 0) {
									entrenador35->quantum =
											ClienteConfig->quantum;

								}
								enviarMensajeEntreMapaYEntrenador(
										entrenador35->socket,
										mensajeAEntrenador);
//								if (recibirMensajeEntreMapaYEntrenador(
//										entrenador35->socket, &mensajeRecibido)
//										> 0) {
//									list_add(listaAuxiliar, entrenador35);
//									list_remove(listaDeadLock, 0);
//								} else {
//									list_remove(listaDeadLock, 0);
//									close(entrenador35->socket);
//									FD_CLR(entrenador35->socket, &master);
//
//									//pthread_mutex_unlock(&sem_entradores);
//									/////considerar para despues las vidas...
//									BorrarItem(items,
//											entrenador35->simboloIdentificador[0]);
//									nivel_gui_dibujar(items, mapaActual);
//									actualizarDibujo(items, entrenador35);
//									nivel_gui_dibujar(items, mapaActual);
//									int k = entrenador35->pid;
//									bool obtenerEntrenador22(void *data) {
//										t_entrenador * unEntrenador12 =
//												(t_entrenador *) data;
//										return (unEntrenador12->pid == k);
//									}
//
//									list_remove_by_condition(
//											listaEntrenadoresParaCrearMatriz,
//											obtenerEntrenador22);
//
//								}
							}
						}
						atenderPrimeraBloqueadoYdespuesContinuar = false;
					}

					if (ClienteConfig->Batalla == 0) {
						if (list_size(listaDeadLock) >= 1
								&& (list_size(listaEntrenadoresListos) == 0
										&& list_size(listaAuxiliar) == 0)) {

							t_entrenador * entrenador35;

							int j = list_size(listaDeadLock);
							int w = 0;

							bool obtenerEntrenadorDeadLock(void *data) {
								t_entrenador * unEntrenador =
										(t_entrenador *) data;
								return (unEntrenador->socket == i);

							}

							t_entrenador * unEntrenador = list_find(
									listaDeadLock, obtenerEntrenadorDeadLock);
							if (recibirMensajeEntreMapaYEntrenador(
									unEntrenador->socket, &mensajeARecibir)
									<= 0) {
								bool momento = true;
								while (j != 0) {
									entrenador35 = list_get(listaDeadLock, w);
									if (unEntrenador == entrenador35) {
										w++;
										j--;
									} else {
										char * unPokemon =
												entrenador35->pokenestAPedir;
										bool confimarPokemon(void* data) {
											rutaPoke_t* unPokeAVerificar =
													(rutaPoke_t*) data;
											return unPokeAVerificar->nombrePOkemon[0]
													== unPokemon[0];
										}
										bool verdadero = list_any_satisfy(
												unEntrenador->listaAtrapados,
												confimarPokemon);

										if (verdadero == true) {

											FD_CLR(unEntrenador->socket,
													&master);
											//										list_remove_by_condition(listaDeadLock,
											//												obtenerEntrenadorDeadLock);
											BorrarItem(items,
													unEntrenador->simboloIdentificador[0]);
											nivel_gui_dibujar(items,
													mapaActual);
											actualizarDibujo(items,
													unEntrenador);
											nivel_gui_dibujar(items,
													mapaActual);
											momento = false;

											list_add(listaEntrenadoresListos,
													entrenador35);
											bool obtenerEntrenadorDeadLock11(
													void *data) {
												t_entrenador * unEntrenador =
														(t_entrenador *) data;
												return (unEntrenador
														== entrenador35);

											}

											list_remove_by_condition(
													listaDeadLock,
													obtenerEntrenadorDeadLock11);
											//hacer remove del este mismo
											mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
											mensajeAEntrenador.protocolo =
													CAPTURAREALIZADA;
											mensajeAEntrenador.texto =
													rutaDelPokemonAtrapado(
															unPokemon,
															entrenador35->listaAtrapados);
											restarPokeparada(
													entrenador35->pokenestAPedir);
											restarRecurso(items,
													entrenador35->pokenestAPedir[0]);
											verificarLasListas(
													entrenador35->listaAtrapados,
													entrenador35->pokemonesSolicitados);

											//le mando el quantum correspondiente
											// en caso de que sea necesario

											if (!strcmp(
													ClienteConfig->algoritmo,
													"RR")) {
												if (entrenador35->quantum
														== 0) {
													mensajeAEntrenador.quantum =
															ClienteConfig->quantum;
												}
											}

											enviarMensajeEntreMapaYEntrenador(
													entrenador35->socket,
													mensajeAEntrenador);
											j = 0;

										} else {
											j--;
											w++;
//											if(momento==true && j==0){
//												j=0;
//												momento=false;
//											}

										}

									}

								}
								if (momento == true) {
									FD_CLR(unEntrenador->socket, &master);

									BorrarItem(items,
											unEntrenador->simboloIdentificador[0]);
									nivel_gui_dibujar(items, mapaActual);
									actualizarDibujo(items, unEntrenador);
									nivel_gui_dibujar(items, mapaActual);
									momento = false;
								}
								list_remove_by_condition(listaDeadLock,
										obtenerEntrenadorDeadLock);
							}

						}

					}

				}
			}
			//podria ir ahi el semaforo
			if (flagSemaforo == false) {
				pthread_mutex_unlock(&sem_entradores);

			}
		}
		pthread_mutex_unlock(&sem_DeadLockAtiende);
		//deberia ir semaforo
	}
}
// ROUND ROBIN
void roundRobin() {
	while (1) {
		t_entrenador* unEntrenador2;

		sem_wait(&h);
		sem_wait(&mx);
		pthread_mutex_lock(&sem_entradores);
		if (flagRoundRobin == true) {
			unEntrenador2 = list_get(listaEntrenadoresListos, 0);
			list_add(listaAuxiliar, unEntrenador2);
			list_remove(listaEntrenadoresListos, 0);
		}
		if (list_size(listaAuxiliar) >= 1) {
			unEntrenador2 = list_get(listaAuxiliar, 0);
			list_add(listaEntrenadoresListos, unEntrenador2);
			list_remove(listaAuxiliar, 0);
		}
		flagRoundRobin = true;

		if (list_size(listaEntrenadoresListos) > 0) {
			t_entrenador* entrenadorLista = list_get(listaEntrenadoresListos,
					0);
			log_info(logger_mapa, "ENTRENADOR QUE SE ESTA EJECUTANDO:%d",
					entrenadorLista->pid);

		}
		if (list_size(listaAuxiliar) > 0) {
			int j = list_size(listaAuxiliar);
			int w = 0;
			log_info(logger_mapa, "ENTRENADORES LISTOS PARA EJECUTAR:");
			while (j != 0) {

				t_entrenador* entrenadorLista = list_get(listaAuxiliar, w);
				log_info(logger_mapa, "%d", entrenadorLista->pid);
				w++;
				j--;
			}

		}

		pthread_mutex_unlock(&sem_entradores);
		sem_post(&mx);
		sem_post(&s);
	}
}

int distanciaDelJugador(t_entrenador* unEntrenador) {
	int Xfinal;
	int Yfinal;
	posicionPokenest* unaPosicion = dictionary_get(diccionarioDePosiciones,
			unEntrenador->pokenestAPedir);
	Xfinal = unaPosicion->posEnX - unEntrenador->posicionEnX;
	Yfinal = unaPosicion->PosEnY - unEntrenador->PosicionEnY;
	if (Xfinal < 0) {
		Xfinal = Xfinal * -1;
	} else if (Yfinal < 0) {
		Yfinal = Yfinal * -1;
	}
	return Xfinal + Yfinal;
}

void algoritmoDeSeleccion() {
	mensaje_MAPA_ENTRENADOR mensajeAEntrenador12;
	t_entrenador* entrenadorAAgregar;
	int i = 0;
	int j = 1;
	int posFinal;

	int k = list_size(listaAuxiliar);
	while (i < k && j < k) {
		if (distanciaDelJugador(list_get(listaAuxiliar, i))
				<= distanciaDelJugador(list_get(listaAuxiliar, j))) {
			entrenadorAAgregar = list_get(listaAuxiliar, i);
			j++;
			if (i == j) {
				j++;
			}
			posFinal = i;
		} else {
			i++;
			if (i == j) {
				i++;
			}
			entrenadorAAgregar = list_get(listaAuxiliar, j);
			posFinal = j;
		}
	}
	list_remove(listaAuxiliar, posFinal);
	list_add(listaEntrenadoresListos, entrenadorAAgregar);

}

// SRDF
void SRDF() {
	while (1) {
		t_entrenador* unEntrenador2;

		sem_wait(&h);
		sem_wait(&mx);
		pthread_mutex_lock(&sem_entradores);
		if (list_size(listaAuxiliar) == 1) {
			unEntrenador2 = list_get(listaAuxiliar, 0);
			list_add(listaEntrenadoresListos, unEntrenador2);
			list_remove(listaAuxiliar, 0);
			if (flagSRDF == false) {
				sem_post(&semaforo_EntrenadorLibre);
			}
		}

		if (list_size(listaAuxiliar) > 1) {
			algoritmoDeSeleccion();
			if (flagSRDF == false) {
				sem_post(&semaforo_EntrenadorLibre);
			}
		}
		flagSRDF = false;
		if (list_size(listaEntrenadoresListos) > 0) {
			t_entrenador* entrenadorLista = list_get(listaEntrenadoresListos,
					0);
			log_info(logger_mapa, "ENTRENADOR QUE SE ESTA EJECUTANDO:%d",
					entrenadorLista->pid);

		}
		if (list_size(listaAuxiliar) > 0) {
			int j = list_size(listaAuxiliar);
			int w = 0;
			log_info(logger_mapa, "ENTRENADORES LISTOS PARA EJECUTAR:");
			while (j != 0) {

				t_entrenador* entrenadorLista = list_get(
						listaEntrenadoresListos, w);
				log_info(logger_mapa, "%d", entrenadorLista->pid);
				w++;
				j--;
			}

		}
		pthread_mutex_unlock(&sem_entradores);
		sem_post(&mx);
		sem_post(&s);
	}

}

void crearHiloParaAtenderEntrenadores() {
	pthread_create(&entrenador_thread, NULL, (void*) iniciarEscuchaDeEntrenador,
	NULL);
}

void rellenarTabla(int **a, int **b, int filas, int columnas) {
	int i;
	int j;
	for (i = 0; i < filas; i++)
		for (j = 0; j < columnas; j++)
			b[i][j] = a[i][j];
}

void ModificarMatricesParaDeadLock(int filas) {
	//
	int **matrizAuxiliarParaAsignacion = (int**) malloc(
			(filas - 1) * sizeof(int));
	int i;
	for (i = 0; i < 1; i++) {
		matrizAuxiliarParaAsignacion[i] = (int*) malloc(
				cantidadDePokeparadas * sizeof(int));
	}
	rellenarTabla(matrizAsignacion, matrizAuxiliarParaAsignacion, filas - 1,
			cantidadDePokeparadas);

	int **matrizAuxiliarParaSolicitud = (int**) malloc(
			(filas - 1) * sizeof(int));
	int j;
	for (j = 0; j < 1; j++) {
		matrizAuxiliarParaSolicitud[j] = (int*) malloc(
				cantidadDePokeparadas * sizeof(int));
	}
	rellenarTabla(matrizSolicitud, matrizAuxiliarParaSolicitud, filas - 1,
			cantidadDePokeparadas);
	free(matrizAsignacion);
	free(matrizSolicitud);

	matrizAsignacion = (int**) malloc(filas * sizeof(int));
	int t;
	for (t = 0; i < 1; t++) {
		matrizAsignacion[t] = (int*) malloc(
				cantidadDePokeparadas * sizeof(int));

	}
	matrizSolicitud = (int**) malloc(filas * sizeof(int));
	int w;
	for (w = 0; j < 1; w++) {
		matrizSolicitud[w] = (int*) malloc(cantidadDePokeparadas * sizeof(int));

	}
	rellenarTabla(matrizAuxiliarParaAsignacion, matrizAsignacion, filas - 1,
			cantidadDePokeparadas);
	rellenarTabla(matrizAuxiliarParaSolicitud, matrizSolicitud, filas - 1,
			cantidadDePokeparadas);
	free(matrizAuxiliarParaAsignacion);
	free(matrizAuxiliarParaSolicitud);

}

void detectarDeadLock() {

	while (1) {

		if (ClienteConfig->Batalla == 1) {
			usleep(ClienteConfig->TiempoChequeoDeadLock*1000);
			pthread_mutex_lock(&sem_DeadLockAtiende);
			if (list_size(listaEntrenadoresParaCrearMatriz) > 0) {

				//creo las matrices y las pongo en cero
				crearMatrizSolicitudYAsignacion();
				//asigno las matrices segun las listas que tienen los entrenadores
				asignarpokemonesAEntrenadores();
				crearVectorDisponible();
				detectarEntrenadoresEnDeadlock();
				resolucionDeadLock();
				free(matrizAsignacion);
				free(matrizSolicitud);
				free(vectorDisponibles);

				//hacer free de las matrices
				pthread_mutex_unlock(&sem_DeadLockAtiende);
			}

		}

	}
}

void crearHiloDeteccionDeadLock() {
	pthread_create(&deadlock_thread, NULL, (void*) detectarDeadLock,
	NULL);
}

//pensar en la ultima pokeparada q pidio para poder darle despues el pokemon que queria
void resolucionDeadLock() {
	mensaje_MAPA_ENTRENADOR mensajeAEnviar;
	mensaje_MAPA_ENTRENADOR mensajeAEnviar1;
	mensaje_MAPA_ENTRENADOR mensajeARecibir;
	mensaje_MAPA_ENTRENADOR mensajeARecibir2;
	mensaje_MAPA_ENTRENADOR mensajeARecibir3;
	t_entrenador* EntrenadorAMorir;
	t_pokemon * pokemon1;
	t_pokemon * pokemon2;
	t_pokemon * loser;
	t_pokemon * PokemonNuevo;
	t_pokemon * derrotado;
	t_entrenador*unEntrenador3;
	while (list_size(listaDeadLock) >= 3) {
		t_entrenador *unEntrenador1 = list_get(listaDeadLock, 0);
		t_entrenador *unEntrenador2 = list_get(listaDeadLock, 1);

		recibirMensajeEntreMapaYEntrenador(unEntrenador1->socket,
				&mensajeARecibir);
		recibirMensajeEntreMapaYEntrenador(unEntrenador2->socket,
				&mensajeARecibir2);

		pokemon1 = create_pokemon(factory, mensajeARecibir.texto,
				mensajeARecibir.valor);
		pokemon2 = create_pokemon(factory, mensajeARecibir2.texto,
				mensajeARecibir2.valor);
//
		log_info(logger_mapa, "========Batalla!========\n");
		log_info(logger_mapa, "Primer Pokemon: %s[%s/%s] Nivel: %d\n",
				pokemon1->species, pkmn_type_to_string(pokemon1->type),
				pkmn_type_to_string(pokemon1->second_type), pokemon1->level);
		log_info(logger_mapa, "Segundo Pokemon: %s[%s/%s] Nivel: %d\n",
				pokemon2->species, pkmn_type_to_string(pokemon2->type),
				pkmn_type_to_string(pokemon2->second_type), pokemon2->level);
		//Función que sirve para ver el Tipo de Enum como un String

		//La batalla propiamente dicha
		loser = pkmn_battle(pokemon1, pokemon2);
		log_info(logger_mapa, "Perdio el Pokemon:%s", loser->species);

		// aca contemplo el caso en el cual solo haya 3 pokemones en deadLock
		// es decir que le damos la prioridad a los entrenadores en deadlock para resolverlo
		unEntrenador3 = list_get(listaDeadLock, 2);

		recibirMensajeEntreMapaYEntrenador(unEntrenador3->socket,
				&mensajeARecibir3);
		PokemonNuevo = create_pokemon(factory, mensajeARecibir3.texto,
				mensajeARecibir3.valor);

		log_info(logger_mapa, "Tercer Pokemon: %s[%s/%s] Nivel: %d\n",
				PokemonNuevo->species, pkmn_type_to_string(PokemonNuevo->type),
				pkmn_type_to_string(PokemonNuevo->second_type),
				PokemonNuevo->level);
		derrotado = pkmn_battle(loser, PokemonNuevo);
		log_info(logger_mapa, "El Pokemon Que Muere Es:%s", derrotado->species);
		// aca analizo si gano o si perdio el primer entrenador, en caso de perder envia PERdio
		//en caso de ganar se fijo si el pokemon derrotado es igual al que quiere atrapar
		// de ser asi lo atrapa y sino permanece en deadLock, lo mismo para el entrenador2

		if (derrotado == pokemon1) {
			mensaje_MAPA_ENTRENADOR unmensaje;
			unmensaje.protocolo = PERDISTE;
			FD_CLR(unEntrenador1->socket, &master);
			BorrarItem(items, unEntrenador1->simboloIdentificador[0]);
			nivel_gui_dibujar(items, mapaActual);
			actualizarDibujo(items, unEntrenador1);
			nivel_gui_dibujar(items, mapaActual);
			EntrenadorAMorir = unEntrenador1;
			if (mensajeARecibir.quantum == 0) {
				unmensaje.quantum = ClienteConfig->quantum;
			}
			enviarMensajeEntreMapaYEntrenador(unEntrenador1->socket, unmensaje);
			int k = unEntrenador1->pid;
			bool obtenerEntrenador1(void *data) {
				t_entrenador * unEntrenador = (t_entrenador *) data;
				return (unEntrenador->pid == k);
			}

			list_remove_by_condition(listaEntrenadoresParaCrearMatriz,
					obtenerEntrenador1);

			//liberar este entrenador del la listaParaCrearMatrices
		} else if (derrotado == pokemon2) {
			mensaje_MAPA_ENTRENADOR unmensaje;
			unmensaje.protocolo = PERDISTE;
			FD_CLR(unEntrenador2->socket, &master);
			BorrarItem(items, unEntrenador2->simboloIdentificador[0]);
			nivel_gui_dibujar(items, mapaActual);
			actualizarDibujo(items, unEntrenador2);
			nivel_gui_dibujar(items, mapaActual);
			EntrenadorAMorir = unEntrenador2;
			if (mensajeARecibir2.quantum == 0) {
				unmensaje.quantum = ClienteConfig->quantum;
			}
			enviarMensajeEntreMapaYEntrenador(unEntrenador2->socket, unmensaje);
			int k = unEntrenador2->pid;
			bool obtenerEntrenador2(void *data) {
				t_entrenador * unEntrenador = (t_entrenador *) data;
				return (unEntrenador->pid == k);
			}

			list_remove_by_condition(listaEntrenadoresParaCrearMatriz,
					obtenerEntrenador2);

		} else if (derrotado == PokemonNuevo) {
			mensaje_MAPA_ENTRENADOR unmensaje;
			unmensaje.protocolo = PERDISTE;
			FD_CLR(unEntrenador3->socket, &master);
			BorrarItem(items, unEntrenador3->simboloIdentificador[0]);
			nivel_gui_dibujar(items, mapaActual);
			actualizarDibujo(items, unEntrenador3);
			nivel_gui_dibujar(items, mapaActual);
			EntrenadorAMorir = unEntrenador3;
			if (mensajeARecibir3.quantum == 0) {
				unmensaje.quantum = ClienteConfig->quantum;
			}
			enviarMensajeEntreMapaYEntrenador(unEntrenador3->socket, unmensaje);
			int k = unEntrenador3->pid;
			bool obtenerEntrenador3(void *data) {
				t_entrenador * unEntrenador = (t_entrenador *) data;
				return (unEntrenador->pid == k);
			}

			list_remove_by_condition(listaEntrenadoresParaCrearMatriz,
					obtenerEntrenador3);
		}
		t_entrenador* entrenador35;
		int j = list_size(listaDeadLock);
		int w = 0;
		bool momento = true;
		while (j != 0) {
			entrenador35 = list_get(listaDeadLock, w);
			if (EntrenadorAMorir == entrenador35) {
				w++;
				j--;
			} else {
				bool confimarPokemon(void* data) {
					rutaPoke_t* unPokeAVerificar = (rutaPoke_t*) data;
					return unPokeAVerificar->nombrePOkemon[0]
							== derrotado->species[0];

				}

				bool verdadero = list_any_satisfy(
						entrenador35->pokemonesSolicitados, confimarPokemon);

				if (verdadero == true) {

					momento = false;
					// verificar si es correcto colocarlo en esta lista
					list_add(listaAuxiliar, entrenador35);
					bool obtenerEntrenadorAMorir(void *data) {
						t_entrenador * unEntrenador = (t_entrenador *) data;
						return (unEntrenador == EntrenadorAMorir);
					}
					list_remove_by_condition(listaDeadLock,
							obtenerEntrenadorAMorir);
					//hacer remove del este mismo
					mensaje_MAPA_ENTRENADOR mensajeAEntrenador;
					mensajeAEntrenador.protocolo = CAPTURAREALIZADA;
					restarRecurso(items, entrenador35->pokenestAPedir[0]);
							nivel_gui_dibujar(items, mapaActual);
							mensajeAEntrenador.protocolo = CAPTURAREALIZADA;
							mensajeAEntrenador.texto = rutaDelPokemonAtrapado(
									derrotado->species, entrenador35->listaAtrapados);
							char* letra=charToString(derrotado->species[0]);
							recursodePokenestSolicitado(letra);
							restarPokeparada(letra);
							verificarLasListas(entrenador35->listaAtrapados,
									entrenador35->pokemonesSolicitados);
//					mensajeAEntrenador.texto = rutaDelPokemonAtrapado(
//							derrotado->species, entrenador35->listaAtrapados);
//					restarPokeparada(entrenador35->pokenestAPedir);
//					restarRecurso(items, entrenador35->pokenestAPedir[0]);
//					verificarLasListas(entrenador35->listaAtrapados,
//							entrenador35->pokemonesSolicitados);
					bool obtenerEntrenador35(void *data) {
						t_entrenador * unEntrenador = (t_entrenador *) data;
						return (unEntrenador == entrenador35);
					}
					list_remove_by_condition(listaDeadLock,
							obtenerEntrenador35);
					//le mando el quantum correspondiente
					// en caso de que sea necesario

					if (!strcmp(ClienteConfig->algoritmo, "RR")) {
						if (entrenador35->quantum == 0) {
							mensajeAEntrenador.quantum = ClienteConfig->quantum;
						}
					}

					enviarMensajeEntreMapaYEntrenador(entrenador35->socket,
							mensajeAEntrenador);
					j = 0;

				} else {
					j--;
					w++;
				}

			}

		}
		if (momento == true) {

			list_add(listaEntrenadoresListos, entrenador35);
			bool obtenerEntrenadorAMorir(void *data) {
				t_entrenador * unEntrenador = (t_entrenador *) data;
				return (unEntrenador == EntrenadorAMorir);
			}
			list_remove_by_condition(listaDeadLock, obtenerEntrenadorAMorir);
		}
		momento = true;

		if (list_size(listaDeadLock) == 1 && list_size(listaAuxiliar) == 1
				&& list_size(listaEntrenadoresListos) == 0) {
			atenderPrimeraBloqueadoYdespuesContinuar = true;
		}
		//verificar si esta bien pasar este flag a falso
		superNecesario = false;
		free(pokemon2);
		free(pokemon1);
		free(PokemonNuevo);

	}

}

void crearVectorDisponible() {
	vectorDisponibles = (int*) malloc(cantidadDePokeparadas * sizeof(int));

	int i = list_size(cantidadDePokemones);
	int j = 0;
	log_info(logger_mapa, "\n");
	log_info(logger_mapa, "VECTOR DE DISPONIBLES\n");
	while (i != 0) {
		t_cantidad_pokemones* unPOke = list_get(cantidadDePokemones, j);
		vectorDisponibles[j] = unPOke->cantidadDePokemones;
		log_info(logger_mapa, "\t%d\t", vectorDisponibles[j]);
		i--;
		j++;

	}
	log_info(logger_mapa, "\n");

}
void detectarEntrenadoresEnDeadlock() {
	int filas = list_size(listaEntrenadoresParaCrearMatriz);
//	int contadorDeCeros = 0;
	bool flag = false;
	int i = 0;

	bool fladAnterior = false;

	while (filas != 0 && filas > 0) {
//		while (matrizAsignacion[i][j] == 0) {
//			j++;
//			contadorDeCeros++;
//		}

		int w = 0;
		int l = cantidadDePokeparadas;
		while (l != 0 && flag == false) {
			if (matrizSolicitud[i][w] > vectorDisponibles[w]
					&& vectorDisponibles[w] == 0) {
				//agregar entrenador en dead lock
				if (fladAnterior == false) {
					log_info(logger_mapa, "el entrenador bloqueado es:%d", i);

				}
				flag = true;
			} else if (matrizSolicitud[i][w] == vectorDisponibles[w]) {
				w++;
				l--;
			} else if (matrizSolicitud[i][w] < vectorDisponibles[w]) {
				w++;
				l--;
				fladAnterior = true;
			}

		}

		filas--;
		fladAnterior = false;
		i++;
		flag = false;

	}
}
int filas2;
void asignarpokemonesAEntrenadores() {

	int i = 0;
	int j = 0;
	int w = 0;
	int kk = 0;
	int ll = 0;
	int tamanio = list_size(listaEntrenadoresParaCrearMatriz);
	while (tamanio != 0) {
		t_entrenador* unEntrenador = list_get(listaEntrenadoresParaCrearMatriz,
				i);
		int tamanio2 = list_size(unEntrenador->listaAtrapados);
		int tamanio3 = list_size(unEntrenador->pokemonesSolicitados);
		while (tamanio2 != 0 || tamanio3 != 0) {

			if (tamanio2 > 0) {
				if (j != list_size(cantidadDePokemones)) {

					t_cantidad_pokemones* pokeparada = list_get(
							cantidadDePokemones, j);
					rutaPoke_t* unPoke = list_get(unEntrenador->listaAtrapados,
							w);

					if (pokeparada->pokeparada[0] == unPoke->nombrePOkemon[0]) {
						matrizAsignacion[i][j] = 1;

					}
				}
				if (j < list_size(cantidadDePokemones)) {

					j++;

				} else {
					j = 0;
					w++;
					tamanio2--;

				}

			} else {
				tamanio2 = 0;
			}
			if (tamanio3 > 0) {
				if (kk != list_size(cantidadDePokemones)) {

					t_cantidad_pokemones* pokeparada = list_get(
							cantidadDePokemones, kk);

					rutaPoke_t* unPoke = list_get(
							unEntrenador->pokemonesSolicitados, ll);

					if (pokeparada->pokeparada[0] == unPoke->nombrePOkemon[0]) {
						matrizSolicitud[i][kk] = 1;
					}
				}
				if (kk < list_size(cantidadDePokemones)) {

					kk++;

				} else {
					kk = 0;
					ll++;

					tamanio3--;

				}
			} else {
				tamanio3 = 0;
			}

		}
		tamanio--;
		i++;
		w = 0;
		ll = 0;
	}
	int b, n;
	log_info(logger_mapa, "\t\tMATRIZ ASIGNACION LLENA\n\n");
	for (b = 0; b < filas2; b++) {
		log_info(logger_mapa, "\n");
		for (n = 0; n < cantidadDePokeparadas; n++) {
			log_info(logger_mapa, " %d\t ", matrizAsignacion[b][n]);

		}
		log_info(logger_mapa, "\n");
	}

	log_info(logger_mapa, "\t\tMATRIZ SOLICITUD LLENA\n\n");
	for (b = 0; b < filas2; b++) {
		log_info(logger_mapa, "\n");
		for (n = 0; n < cantidadDePokeparadas; n++) {
			log_info(logger_mapa, " %d\t ", matrizSolicitud[b][n]);

		}
		log_info(logger_mapa, "\n");
	}

}

void crearMatrizSolicitudYAsignacion() {

//	int **matriz;
//	matriz = (int **)malloc (FILAS*sizeof(int *));
//
//	for (i=0;i<FILAS;i++)
//	matriz[i] = (int *) malloc (COLS*sizeof(int));

	int filas = list_size(listaEntrenadoresParaCrearMatriz);

	matrizAsignacion = (int**) malloc(filas * sizeof(int*));
	int i;
	for (i = 0; i < filas; i++) {
		matrizAsignacion[i] = (int*) malloc(
				cantidadDePokeparadas * sizeof(int));

	}
	matrizSolicitud = (int**) malloc(filas * sizeof(int*));
	int j;
	for (j = 0; j < filas; j++) {
		matrizSolicitud[j] = (int*) malloc(cantidadDePokeparadas * sizeof(int));

	}
	int t, u;
	//matriz cargada con numeros aleatorios entre 10 y 99

	for (t = 0; t < filas; t++) {
		for (u = 0; u < cantidadDePokeparadas; u++) {
			matrizAsignacion[t][u] = 0;

		}
	}
	for (t = 0; t < filas; t++) {
		for (u = 0; u < cantidadDePokeparadas; u++) {
			matrizSolicitud[t][u] = 0;

		}
	}

	int b, n;
	log_info(logger_mapa, "\t\tMATRIZ ASIGNACION VACIAl\n\n");
	for (b = 0; b < filas; b++) {
		//printf("\n");
		for (n = 0; n < cantidadDePokeparadas; n++) {
			log_info(logger_mapa, " %d\t ", matrizAsignacion[b][n]);

		}
		log_info(logger_mapa, "\n");
	}

	log_info(logger_mapa, "\t\tMATRIZ SOLICITUD VACIA\n\n");
	for (b = 0; b < filas; b++) {
		log_info(logger_mapa, "\n");
		for (n = 0; n < cantidadDePokeparadas; n++) {
			log_info(logger_mapa, " %d\t ", matrizSolicitud[b][n]);

		}
		log_info(logger_mapa, "\n");
	}
	filas2 = filas;
}

void planificacion() {
	if (!strcmp(ClienteConfig->algoritmo, "RR")) {
		roundRobin();
	} else {
		SRDF();
	}
}

void crearHiloPlanificacion() {
	pthread_create(&roundRobin_thread, NULL, planificacion,
	NULL);
}

void iniciarDatos() {
	logger_mapa = log_create("Log", "Mapa", false, LOG_LEVEL_INFO);
	listaEntrenadoresListos = list_create();
	listaDeadLock = list_create();
	recursosDeTodasLasPokenests = dictionary_create();
	diccionarioDePosiciones = dictionary_create();
	diccionarioDePokemonesAtrapados = dictionary_create();
	listaAuxiliar = list_create();
	listaPrioridad = list_create();
	listaEntrenadoresParaCrearMatriz = list_create();
	listaDePokemonesParaCrearMatriz = list_create();
	bool flagMacabro = true;
	listaDePokemones = list_create();
	listaPokenests = list_create();
	cantidadDePokemones = list_create();

	//sem_init(&vamoAsincronizarno, 0, 0);
	sem_init(&semaforo_EntrenadorLibre, 0, 0);
	sem_init(&mx, 1, 1);
	sem_init(&h, 0, 0);
	sem_init(&s, 1, 1);
	//sem_init(&semaforo_Entrenadorbloqueado, 0, 0);
	items = list_create();
	pthread_mutex_init(&sem_de_mapa, NULL);
	pthread_mutex_init(&sem_entradores, NULL);
	pthread_mutex_init(&sem_DeadLockAtiende, NULL);
//	pthread_mutex_t sem_entradores;
//	pthread_mutex_t sem_DeadLockAtiende;

	ClienteConfig = malloc(sizeof(t_config_server));

	ClienteConfig3 = malloc(sizeof(t_config_PokeNest));
	factory = create_pkmn_factory();

}

void dibujarElMapa() {
	int rows, cols;
	nivel_gui_inicializar();
	nivel_gui_get_area_nivel(&rows, &cols);
	int i = 0;
	while (list_size(listaPokenests) > 0) {
		t_config_PokeNest* unaPokenest = list_get(listaPokenests, 0);
		t_cantidad_pokemones* pokemones = list_get(cantidadDePokemones, i);
		CrearCaja(items, unaPokenest->Identificador[0],
				obtenerCoordenadaEnX(unaPokenest->Posicion),
				obtenerCoodenadaEnY(unaPokenest->Posicion),
				pokemones->cantidadDePokemones);
//	void CrearItem(t_list* items, char id, int x, int y, char tipo, int cant);
//		CrearItem(items,unaPokenest->Identificador[0],obtenerCoordenadaEnX(unaPokenest->Posicion),
//				obtenerCoodenadaEnY(unaPokenest->Posicion),unaPokenest->Tipo[0],pokemones->cantidadDePokemones);

///cargo lo necesario para los recursos
		recursoPokenest * unRecu2 = malloc(sizeof(recursoPokenest));
		unRecu2->cantidadDeRecurso = pokemones->cantidadDePokemones;
		dictionary_put(recursosDeTodasLasPokenests, unaPokenest->Identificador,
				unRecu2);

//cargo las posiciones de la pokenest
		posicionPokenest* unaPos = malloc(sizeof(posicionPokenest));
		unaPos->pokeparada = unaPokenest->Identificador[0];
		unaPos->posicionDePokenest = unaPokenest->Posicion;
		unaPos->posEnX = obtenerCoordenadaEnX(unaPokenest->Posicion);
		unaPos->PosEnY = obtenerCoodenadaEnY(unaPokenest->Posicion);
		dictionary_put(diccionarioDePosiciones, unaPokenest->Identificador,
				unaPos);

		list_remove(listaPokenests, 0);
//list_remove(cantidadDePokemones,0);
		i++;
	}

}

void iniciarConfiguracionDelMapa(char *direction1, char*direction2) {

	mapaActual = direction1;
	cargarMetadataDelMapa(direction1, direction2);
	cargarPokenestsDelMapa(direction1, direction2);

}

void cargarPokenestsDelMapa(char* direccion1, char*direccion2) {

	DIR *dir;
	struct dirent *direntp;
	char * homeUtn = "/home/utnso/";
	char* Mapas = "/Mapas/";
	char* pokenest = "/PokeNests";
	char* rutaPokenests = malloc(
			strlen(homeUtn) + strlen(direccion2) + strlen(direccion1)
					+ strlen(Mapas) + strlen(pokenest) + 2);
	rutaPokenests[0] = '\0';
	strcat(rutaPokenests, homeUtn);
	strcat(rutaPokenests, direccion2);
	strcat(rutaPokenests, Mapas);
	strcat(rutaPokenests, direccion1);
	strcat(rutaPokenests, pokenest);
	dir = opendir(rutaPokenests);

	while ((direntp = readdir(dir)) != NULL) {

		if (!strstr(direntp->d_name, ".") != NULL) {

			cargarLosPokemonesDeLaPokenest(direntp->d_name, rutaPokenests);
			cagarLaMedatadaDeLaPokenest(direntp->d_name, rutaPokenests);

		}
	}
	closedir(dir);
	free(rutaPokenests);
}

int cargarConfigPokeNest(char* archivoRuta) {
	tConfig2 = config_create(archivoRuta);
	t_config_PokeNest* configServer = malloc(sizeof(t_config_PokeNest));
	if (tConfig2 == NULL) {
		printf(
				"ERROR: no se encuentra o falta el archivo de configuracion en la direccion \t%s \n",
				archivoRuta);

		return 0;
	}
	if (config_has_property(tConfig2, "Tipo")) {
		configServer->Tipo = config_get_string_value(tConfig2, "Tipo");
	} else {
		printf("ERROR: Falta el parametro: %s. \n", "Tipo");
		return 1;
	}
	if (config_has_property(tConfig2, "Posicion")) {
		configServer->Posicion = config_get_string_value(tConfig2, "Posicion");
	} else {
		printf("ERROR: Falta el parametro: %s. \n", "Posicion");
		return 1;
	}

	if (config_has_property(tConfig2, "Identificador")) {
		configServer->Identificador = config_get_string_value(tConfig2,
				"Identificador");
	} else {
		printf("ERROR: Falta el parametro: %s. \n", "Identificador");
		return 1;
	}

	list_add(listaPokenests, configServer);

	return 1;

}

void cargarLosPokemonesDeLaPokenest(char* directorio, char*ruta) {
	DIR *dir;
	struct dirent *direntp;
	char* barra = "/";
	char* rutaPokemones = malloc(
			strlen(directorio) + strlen(ruta) + strlen(barra) + 1);
	rutaPokemones[0] = '\0';
	strcat(rutaPokemones, ruta);
	strcat(rutaPokemones, barra);
	strcat(rutaPokemones, directorio);
	dir = opendir(rutaPokemones);

	t_cantidad_pokemones* Pokemones;
	Pokemones = malloc(sizeof(t_cantidad_pokemones));
	Pokemones->cantidadDePokemones = 0;
	Pokemones->pokeparada = charToString(directorio[0]);
	//printf("%s\n", directorio);
	while ((direntp = readdir(dir)) != NULL) {
		//printf("%s\n", direntp->d_name);
		if (strstr(direntp->d_name, directorio) != NULL) {

//			 		 cargarElPokemon(direntp->d_name,rutaPokemones,directorio);
			Pokemones->cantidadDePokemones++;
		}
	}

	list_add(cantidadDePokemones, Pokemones);
	closedir(dir);
	cantidadDePokeparadas++;
	free(rutaPokemones);

}

void cagarLaMedatadaDeLaPokenest(char* directorio, char* ruta) {

	char* barra = "/";
	char* metadata = "/metadata/";
	char* txt = ".txt";
	char* rutaNueva = malloc(
			strlen(directorio) + strlen(ruta) + strlen(barra) + strlen(metadata)
					+ strlen(txt) + strlen(directorio) + 1);
	rutaNueva[0] = '\0';
	strcat(rutaNueva, ruta);
	strcat(rutaNueva, barra);
	strcat(rutaNueva, directorio);
	strcat(rutaNueva, metadata);
	strcat(rutaNueva, directorio);
	strcat(rutaNueva, txt);

	cargarConfigPokeNest(rutaNueva);
	free(rutaNueva);
}

void cargarMetadataDelMapa(char *direction1, char*direction2) {

	char * homeUtn = "/home/utnso/";
	char* Mapas = "/Mapas";
	char* barra = "/";

	char* metadata = "/metadata";
	char * txt = ".txt";
	char*archivoMetadata = malloc(strlen(direction1) + strlen(txt) + 1);
	strcat(archivoMetadata, direction1);
	strcat(archivoMetadata, txt);

	char* rutaPosta = malloc(
			strlen(direction1) + strlen(direction2) + strlen(Mapas)
					+ strlen(homeUtn) + strlen(barra) + strlen(barra)
					+ strlen(metadata) + strlen(archivoMetadata) + 1);
	strcat(rutaPosta, homeUtn);
	strcat(rutaPosta, direction2);
	strcat(rutaPosta, Mapas);
	strcat(rutaPosta, barra);
	strcat(rutaPosta, direction1);
	strcat(rutaPosta, metadata);
	strcat(rutaPosta, barra);
	strcat(rutaPosta, archivoMetadata);

	char* ConfigPath = rutaPosta;
	cargarConfigGeneral(ConfigPath, ClienteConfig);
	free(archivoMetadata);
	free(rutaPosta);
}

int main(int argc, char *argv[]) {

	iniciarDatos();
	iniciarConfiguracionDelMapa(argv[1], argv[2]);
	dibujarElMapa();

	crearHiloParaAtenderEntrenadores();
	crearHiloPlanificacion();
	detectarDeadLock();

	pthread_join(roundRobin_thread, NULL);
	pthread_join(entrenador_thread, NULL);
	pthread_join(deadlock_thread, NULL);

	return 0;
}
