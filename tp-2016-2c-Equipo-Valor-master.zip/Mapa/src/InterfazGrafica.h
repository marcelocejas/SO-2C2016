/*
 * InterfazGrafica.h
 *
 *  Created on: 5/9/2016
 *      Author: utnso
 */

#ifndef INTERFAZGRAFICA_H_
#define INTERFAZGRAFICA_H_

#include <stdlib.h>
#include <curses.h>
#include <commons/collections/list.h>
#include <tad_items.h>

#endif /* INTERFAZGRAFICA_H_ */
