/*
 * Configuracion.h
 *
 *  Created on: 29/8/2016
 *      Author: utnso
 */
//
#ifndef CONFIGURACION_H_
#define CONFIGURACION_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <commons/config.h>
#include <commons/collections/list.h>
#include <commons/collections/dictionary.h>

typedef struct configInfo {

	char* nombre;
	char* simbolo;
	t_dictionary* hojaDeViaje;
	int vidas;
	int reintentos;
} t_config_server;
typedef struct valuePokemon_t
{
	char* pokemon;
}valuePokemon;

typedef struct mapas_server_t{
	char* nombreMapa;
	char* serverIp;
	int puerto;
}t_mapas_server;


t_list* listaMapaServer;
t_config *tConfig;


#define CANTIDAD_PARAMETROS_CONFIG  10

int cargarConfig(char* archivoRuta, t_config_server* configCliente );
void finalizarConfig(void);

#endif /* CONFIGURACION_H_ */
