/*
 * Entrenador.h
 *
 *  Created on: 29/8/2016
 *      Author: utnso
 */

#ifndef ENTRENADOR_H_
#define ENTRENADOR_H_

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <commons/config.h>
#include <commons/log.h>
#include <netinet/in.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <src/sw_sockets.h>
#include <sys/inotify.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <src/tiposDato.h>
#include "Configuracion.h"
#include <math.h>
#include <commons/collections/list.h>
#include <commons/string.h>
#include <stdbool.h>

typedef struct pokemon_entrenador_t {

	char *nombre;
	int nivel;

} t_pokemon_entrenador;

typedef struct t_dir_bill{
	char* nombreMapa;
	char* nombreArchivoPokemon;
}t_dir_bill;

void iniciarLogTrace(void);
void quitarCaracter(char*);
void iniciarConfiguracionDelEntrenador(char*,char*);
void liberarDatos(void);
void procesarMapa(void*);
void incrementar_una_vida_entrenador(void );
void decrementar_una_vida_entrenador(void );
void thread_signal_usr1(void* th_signal);
void thread_signal_term(void* th_signal);
void agregarPokemonDirBill(char* ruta_pokemon,char* nombreMapa);
t_list* obtenerArchivosDeUnMapa(char* nombreMapa);
bool esDirDeBillDeMapa(void* bill_actual);
void borrarArchivoDirectorio(char* arch_o_dir);
void validarVidasReiniciar();
void borrarPokemonDirBill(void*);
t_list* eliminarBillDeUnMapa(char* nombreMapa);
void copiarMedalla(char* nombreMapa, char* nombreEntrenador);
#endif /* ENTRENADOR_H_ */
