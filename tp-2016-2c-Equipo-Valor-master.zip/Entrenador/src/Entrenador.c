/*
 ============================================================================
 Name : Entrenador.c
 Author :
 Version :
 Copyright : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include "Entrenador.h"
#include <dirent.h>
t_log* logger_entrenador;
t_config_server* ClienteConfig;
int socketParaMapa;
mensaje_MAPA_ENTRENADOR mensajeAEnviar;
mensaje_MAPA_ENTRENADOR mensajeARecibir;
char *fileName;
char *rutaDeAcceso;
char* fileName2;
int algoritmo;
pthread_mutex_t m_vidasEntrenador;
double tiempoPokenests;
int cantidadDeadlocks = 0;
int cantidadMuertes = 0;
int cantidadReintentos = 0;
char*Entrenador002;
char* mapaBuscadoBill;
int debeEmpezarDeCero = 0;
debeReprocesarMapa = 0;
t_list* listaDirBill;
bool flagParaTerminar = false;

char* argv1;
char* argv2;

void procesarMapa(void* mapa);
t_pokemon_entrenador* busquedaDelMejorPokemon(t_list* listaPokemonesConNivel);

int main(int argc, char *argv[]) {
	listaDirBill = list_create();
	time_t inicioAventura;
	time_t finAventura;
	time(&inicioAventura);
	tiempoPokenests = 0;
	iniciarLogTrace();
	iniciarConfiguracionDelEntrenador(argv[1], argv[2]);
	argv1 = malloc(strlen(argv[1]) + 1);
	argv1[0] = '\0';
	strcat(argv1, argv[1]);
	argv2 = malloc(strlen(argv[2]) + 1);
	argv2[0] = '\0';
	strcat(argv2, argv[2]);
	crear_hilos_para_signals();
	Entrenador002 = malloc(strlen(argv[1]) + 1);
	Entrenador002[0] = '\0';
	strcat(Entrenador002, argv[1]);
	procesarMapas: list_iterate(listaMapaServer, &(procesarMapa));
	if (debeEmpezarDeCero) {
		if (ofrecerReintento()) {
			debeEmpezarDeCero = 0;
			goto procesarMapas;
		} else {
			printf("El entrenador decidio salir del juego \n");
			return 0;
		}
	}
	time(&finAventura);
	imprimir_tiempos(inicioAventura, finAventura);
	free(Entrenador002);
	liberarDatos();
	return 0;
}
void procesarMapa(void* mapa) {
	procesarUnMapa: if (!debeEmpezarDeCero) {
		t_mapas_server* unMapaServer = (t_mapas_server*) mapa;
		printf("%s,%d", unMapaServer->serverIp, unMapaServer->puerto);
		socketParaMapa = conectarConServer(unMapaServer->serverIp,
				unMapaServer->puerto);
		iniciarJuegoConElMapa();
		comunicacionConMapa(unMapaServer);
		if (debeReprocesarMapa) {
			debeReprocesarMapa = 0;
			goto procesarUnMapa;

		}
	}
}

char* charToString(char element) {
	char* new = malloc(2);
	*new = element;
	*(new + 1) = '\0';
	return new;
}

static void pokemon_destroy(valuePokemon *self) {
	free(self->pokemon);
	free(self);
}
void iniciarJuegoConElMapa() {
	mensajeAEnviar.protocolo = INICIARJUEGO;
	char*dispositivo = ClienteConfig->simbolo;
	mensajeAEnviar.texto = malloc(strlen(dispositivo) + 1);
	strcpy(mensajeAEnviar.texto, dispositivo);
	enviarMensajeEntreMapaYEntrenador(socketParaMapa, mensajeAEnviar);
	log_trace(logger_entrenador, "INICIA JUEGO");
	free(mensajeAEnviar.texto);
	flagParaTerminar = false;
}
bool movX = true;
bool movY = false;
bool mov = false;
///
int x = 0;
int y = 0;
///
int contadorEnX = 0;
int contadorEnY = 0;
int posX = 0;
int posY = 0;
int aux1 = 0;
int aux2 = 0;
int FlagNUevo = false;
int valor;
int flagMolesto = false;
int flagMolesto2 = false;
int flagMolesto3 = false;
int quantum;
void hacerCopiaDePokemon(char* algo, char*algo1);
void comunicacionConMapa(t_mapas_server* mapa) {
	valuePokemon* unPoke;

	time_t bloqueadoPokeIni;
	time_t bloqueadoPokeFin;
	bool flagQuantum = true;
	bool flagAlgoritmo = true;
	bool flagDeadLock = false;
	mensaje_MAPA_ENTRENADOR ultimoProtocolo;
	DIR *dir;
	struct dirent *direntp;
	char * ruta4000;
	char *nombreEntrenador555;
	char * ruta2222;
	char* rutaPosta1234;

	while (flagParaTerminar == false
			&& recibirMensajeEntreMapaYEntrenador(socketParaMapa,
					&mensajeARecibir) > 0) {
		if (flagAlgoritmo) {
			algoritmo = mensajeARecibir.algoritmo;
			flagAlgoritmo = false;
			/// cuando termina el mapa debemos poner el flag en true denuevo...
		}
		flagMolesto3 = false;
		if (algoritmo == 1) {
			if (flagQuantum == true) {
				quantum = mensajeARecibir.quantum;
				int aux1 = quantum;
				flagQuantum = false;
			}
			if (quantum > 0) { // le falta u flag de finalizar al este while
				flagParaTerminar = false;
				switch (mensajeARecibir.protocolo) {
				case ACEPTARSOLICITUD:
					mensajeAEnviar.protocolo = PEDIRPOKENEST;
					unPoke = (valuePokemon *) dictionary_get(
							ClienteConfig->hojaDeViaje, mapa->nombreMapa);
					char*dispositivo = unPoke->pokemon;
					mensajeAEnviar.texto = malloc(strlen(dispositivo) + 1);
					strcpy(mensajeAEnviar.texto, dispositivo);
					enviarMensajeEntreMapaYEntrenador(socketParaMapa,
							mensajeAEnviar);
					log_trace(logger_entrenador, "PEDIR POKENEST:%s",
							mensajeAEnviar.texto);
					free(mensajeAEnviar.texto);
					quantum--;
					////aca guardo lo ultimo que se solicito
					ultimoProtocolo.protocolo = PEDIRPOKENEST;
					ultimoProtocolo.texto = malloc(strlen(dispositivo) + 1);
					strcpy(ultimoProtocolo.texto, dispositivo);
					flagQuantum = false;
					break;
				case ENVIARLOCALIZACIONPOKENEST:
					quantum--;
					x = obtenerCoordenadaEnX(mensajeARecibir.texto);
					y = obtenerCoodenadaEnY(mensajeARecibir.texto);
					aux1 = x;
					aux2 = y;
					mensajeAEnviar.protocolo = AVANZARUNAPOSICION;
					contadorEnX++;
					mensajeAEnviar.valor = contadorEnX;
					mensajeAEnviar.valor2 = contadorEnY;
					x--;
					mensajeAEnviar.texto = ClienteConfig->simbolo;
					ultimoProtocolo.protocolo = AVANZARUNAPOSICION;
					enviarMensajeEntreMapaYEntrenador(socketParaMapa,
							mensajeAEnviar);
					log_trace(logger_entrenador, "AVANZAR POSICION");
					ultimoProtocolo.valor = contadorEnX;
					ultimoProtocolo.valor2 = contadorEnY;
					ultimoProtocolo.texto = malloc(
							strlen(ClienteConfig->simbolo) + 1);
					strcpy(ultimoProtocolo.texto, ClienteConfig->simbolo);
					flagQuantum = false;
					movX = true;
					movY = false;
					break;
				case MOVIMIENTOREALIZADO:
					if (FlagNUevo == false) {
						x = x - posX;
						y = y - posY;
						FlagNUevo = true;
					}
					if (movX == false && x > 0 && mov == false) {
						contadorEnX++;
						mensajeAEnviar.protocolo = MOVERENX;
						mensajeAEnviar.valor = contadorEnX;
						mensajeAEnviar.valor2 = contadorEnY;
						x--;
						movX = true;
						movY = false;
						quantum--;
						ultimoProtocolo.protocolo = MOVERENX;
						ultimoProtocolo.valor = contadorEnX;
						ultimoProtocolo.valor2 = contadorEnY;
						log_trace(logger_entrenador, "MOVERSE EN X");
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						mov = true;
					} else if (movY == false && y > 0 && mov == false) {
						contadorEnY++;
						mensajeAEnviar.protocolo = MOVERENY;
						mensajeAEnviar.valor = contadorEnY;
						mensajeAEnviar.valor2 = contadorEnX;
						y--;
						movY = true;
						movX = false;
						ultimoProtocolo.protocolo = MOVERENY;
						ultimoProtocolo.valor = contadorEnY;
						ultimoProtocolo.valor2 = contadorEnX;
						quantum--;
						log_trace(logger_entrenador, "MOVERSE EN Y");
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						mov = true;
					} /////////////////
					if (movX == false && x < 0 && mov == false) {
						contadorEnX--;
						mensajeAEnviar.protocolo = MOVERENX;
						mensajeAEnviar.valor = contadorEnX;
						mensajeAEnviar.valor2 = contadorEnY;
						x++;
						movX = true;
						movY = false;
						quantum--;
						ultimoProtocolo.protocolo = MOVERENX;
						ultimoProtocolo.valor = contadorEnX;
						ultimoProtocolo.valor2 = contadorEnY;
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						log_trace(logger_entrenador, "MOVERSE EN X");
						mov = true;
					} else if (movY == false && y < 0 && mov == false) {
						contadorEnY--;
						mensajeAEnviar.protocolo = MOVERENY;
						mensajeAEnviar.valor = contadorEnY;
						mensajeAEnviar.valor2 = contadorEnX;
						y++;
						movY = true;
						movX = false;
						quantum--;
						ultimoProtocolo.protocolo = MOVERENY;
						ultimoProtocolo.valor = contadorEnY;
						ultimoProtocolo.valor2 = contadorEnX;
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						log_trace(logger_entrenador, "MOVERSE EN Y");
						mov = true;
					}
					///////////////////
					//////////////////
					if (x > 0 && y == 0 && mov == false) {
						contadorEnX++;
						mensajeAEnviar.protocolo = MOVERENX;
						mensajeAEnviar.valor = contadorEnX;
						mensajeAEnviar.valor2 = contadorEnY;
						x--;
						quantum--;
						ultimoProtocolo.protocolo = MOVERENX;
						ultimoProtocolo.valor = contadorEnX;
						ultimoProtocolo.valor2 = contadorEnY;
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						log_trace(logger_entrenador, "MOVERSE EN X");
						mov = true;
					}
					//////////////////////////////////
					if (x < 0 && y == 0 && mov == false) {
						contadorEnX--;
						mensajeAEnviar.protocolo = MOVERENX;
						mensajeAEnviar.valor = contadorEnX;
						mensajeAEnviar.valor2 = contadorEnY;
						x++;
						quantum--;
						ultimoProtocolo.protocolo = MOVERENX;
						ultimoProtocolo.valor = contadorEnX;
						ultimoProtocolo.valor2 = contadorEnY;
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						log_trace(logger_entrenador, "MOVERSE EN X");
						mov = true;
					}
					///////////////////////
					if (y > 0 && x == 0 && mov == false) {
						contadorEnY++;
						mensajeAEnviar.protocolo = MOVERENY;
						mensajeAEnviar.valor = contadorEnY;
						mensajeAEnviar.valor2 = contadorEnX;
						y--;
						quantum--;
						ultimoProtocolo.protocolo = MOVERENY;
						ultimoProtocolo.valor = contadorEnY;
						ultimoProtocolo.valor2 = contadorEnX;
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						log_trace(logger_entrenador, "MOVERSE EN Y");
						mov = true;
					}
					//////////////
					if (y < 0 && x == 0 && mov == false) {
						contadorEnY--;
						mensajeAEnviar.protocolo = MOVERENY;
						mensajeAEnviar.valor = contadorEnY;
						mensajeAEnviar.valor2 = contadorEnX;
						y++;
						quantum--;
						ultimoProtocolo.protocolo = MOVERENY;
						ultimoProtocolo.valor = contadorEnY;
						ultimoProtocolo.valor2 = contadorEnX;
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						log_trace(logger_entrenador, "MOVERSE EN Y");
						mov = true;
					}
					//////////////
					if (x == 0 && y == 0 && flagMolesto == false && mov == false) {
						mensajeAEnviar.protocolo = ATRAPARPOKEMON;
						unPoke = (valuePokemon *) dictionary_get(
								ClienteConfig->hojaDeViaje, mapa->nombreMapa);
						char*dispositivo = unPoke->pokemon;
						mensajeAEnviar.texto = malloc(strlen(dispositivo) + 1);
						strcpy(mensajeAEnviar.texto, dispositivo);
						log_trace(logger_entrenador, "ATRAPAR POKEMON:%s",
								mensajeAEnviar.texto);
						quantum--;
						mensajeAEnviar.quantum = quantum;
						ultimoProtocolo.protocolo = ATRAPARPOKEMON;
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						time(&bloqueadoPokeIni);
						flagMolesto = true;

					}
					mov = false;
					break;
				case CAPTURAREALIZADA:
					time(&bloqueadoPokeFin);
					tiempoPokenests = tiempoPokenests
							+ difftime(bloqueadoPokeFin, bloqueadoPokeIni);
					posX = aux1;
					posY = aux2;
					FlagNUevo = false;
					log_trace(logger_entrenador,
							"los valores que le llegan en X es:%d y en Y es:%d",
							posX, posY);
					dictionary_remove(ClienteConfig->hojaDeViaje,
							mapa->nombreMapa);
					agregarPokemonDirBill(mensajeARecibir.texto,
							mapa->nombreMapa);
					/*
					 aca debo hacer un if consultando si tengo algo en la lista de mapas
					 de ser asi sigo con lo de abajo y sino debo hacer un else saliendo de esta
					 funcion
					 */
					if (dictionary_has_key(ClienteConfig->hojaDeViaje,
							mapa->nombreMapa)) {
						mensajeAEnviar.protocolo = PEDIRPOKENEST;
						unPoke = (valuePokemon *) dictionary_get(
								ClienteConfig->hojaDeViaje, mapa->nombreMapa);
						char*dispositivo = unPoke->pokemon;
						mensajeAEnviar.texto = malloc(strlen(dispositivo) + 1);
						strcpy(mensajeAEnviar.texto, dispositivo);
						quantum--;
						ultimoProtocolo.protocolo = PEDIRPOKENEST;
						ultimoProtocolo.texto = malloc(strlen(dispositivo) + 1);
						strcpy(ultimoProtocolo.texto, dispositivo);
						enviarMensajeEntreMapaYEntrenador(socketParaMapa,
								mensajeAEnviar);
						log_trace(logger_entrenador, "PEDIR POKENEST:%s",
								mensajeAEnviar.texto);
						free(mensajeAEnviar.texto);
						flagMolesto = false;
						//
						void imprimirClaveYValor(char* key, void* data) {
							valuePokemon* unPoke = (valuePokemon *) data;
							printf("Variable: %s Valor: %s \n", key,
									unPoke->pokemon);
						}
						dictionary_iterator(ClienteConfig->hojaDeViaje,
								imprimirClaveYValor);
						hacerCopiaDePokemon(mensajeARecibir.texto, fileName);
					} else {
						//se desconecta del mapa y va a otro
						copiarMedalla(mapa->nombreMapa, ClienteConfig->nombre);
						close(socketParaMapa);
						log_trace(logger_entrenador,
								"el entrador termino con este mapa");
						flagAlgoritmo = true;
						flagParaTerminar = true;
						contadorEnX = 0;
						contadorEnY = 0;
						FlagNUevo = false;
						movX = true;
						movY = false;
						mov = false;
						flagMolesto = false;
						flagMolesto3 = false;
						posX = 0;
						posY = 0;
						aux1 = 0;
						aux2 = 0;
						hacerCopiaDePokemon(mensajeARecibir.texto, fileName);
					}
					break;
				case ESPERAR:
					mensajeAEnviar.protocolo = OKEY;
					enviarMensajeEntreMapaYEntrenador(socketParaMapa,
							mensajeAEnviar);

					break;
				case OKEY:
					// quantum++;
					seguirJugandoDespuesDeQuantum(socketParaMapa,
							ultimoProtocolo, flagMolesto, mapa);
					// quantum=mensajeARecibir.quantum;
					break;
				case PERDISTE:
					log_trace(logger_entrenador,
							"EL ENTRENADOR PERDIO LA BATALLA");
					cantidadMuertes++;
					validarVidasReiniciar(mapa->nombreMapa);
					if (debeEmpezarDeCero || debeReprocesarMapa) {
						close(socketParaMapa);

						dictionary_clean_and_destroy_elements(
								ClienteConfig->hojaDeViaje,
								(void*) pokemon_destroy);
						free(ClienteConfig);
						iniciarConfiguracionDelEntrenador(argv1, argv2);
						flagAlgoritmo = true;
						flagParaTerminar = true;
						contadorEnX = 0;
						contadorEnY = 0;
						FlagNUevo = false;
						movX = true;
						movY = false;
						mov = false;
						flagMolesto = false;
						flagMolesto3 = false;
						posX = 0;
						posY = 0;
						aux1 = 0;
						aux2 = 0;
						return;
					}
					printf(
							"El entrenador fue elegido como victima y ha muerto\n");
					log_trace(logger_entrenador,
							"El entrenador fue elegido como victima y ha muerto");
					flagAlgoritmo = true;
					flagParaTerminar = true;
					contadorEnX = 0;
					contadorEnY = 0;
					FlagNUevo = false;
					movX = true;
					movY = false;
					mov = false;
					flagMolesto = false;
					flagMolesto3 = false;
					posX = 0;
					posY = 0;
					aux1 = 0;
					aux2 = 0;
					break;
				case DEADLOCK:
					cantidadDeadlocks++;
					ruta4000 = "/home/utnso/mnt/pokedex/Entrenadores/";
					nombreEntrenador555 = fileName;
					ruta2222 = "/DirdeBill";
					rutaPosta1234 = malloc(
							strlen(ruta4000) + strlen(nombreEntrenador555)
									+ strlen(ruta2222) + 1);
					rutaPosta1234[0] = '\0';
					strcat(rutaPosta1234, ruta4000);
					strcat(rutaPosta1234, nombreEntrenador555);
					strcat(rutaPosta1234, ruta2222);

					dir = opendir(rutaPosta1234);

					t_list * listaPokemonesConNivel = list_create();
					direntp = readdir(dir);
					while (direntp != NULL) {

						if (strstr(direntp->d_name, "dat") != NULL) {

							cargarElPokemonConNivel(direntp->d_name,
									rutaPosta1234, listaPokemonesConNivel);

						}
						direntp = readdir(dir);
					}
					closedir(dir);
					t_pokemon_entrenador* unPokemonDelEntrenador =
							busquedaDelMejorPokemon(listaPokemonesConNivel);
					mensajeAEnviar.protocolo = MEJORENTRENADOR;
					mensajeAEnviar.texto = unPokemonDelEntrenador->nombre;
					mensajeAEnviar.valor = unPokemonDelEntrenador->nivel;
					mensajeAEnviar.quantum = quantum;
					enviarMensajeEntreMapaYEntrenador(socketParaMapa,
							mensajeAEnviar);

					while (list_size(listaPokemonesConNivel) != 0) {
						list_remove(listaPokemonesConNivel, 0);

					}

					list_destroy(listaPokemonesConNivel);
					log_trace(logger_entrenador,
							"el ENTRENADOR ENTRO EN DEADLOCK y elige a su mejor pokemones que es:%s, de nivel:%d",
							unPokemonDelEntrenador->nombre,
							unPokemonDelEntrenador->nivel);
					break;
				}
			} else {
				if (mensajeARecibir.protocolo == DEADLOCK) {
					cantidadDeadlocks++;
					ruta4000 = "/home/utnso/mnt/pokedex/Entrenadores/";
					nombreEntrenador555 = fileName;
					ruta2222 = "/DirdeBill";
					rutaPosta1234 = malloc(
							strlen(ruta4000) + strlen(nombreEntrenador555)
									+ strlen(ruta2222) + 1);
					rutaPosta1234[0] = '\0';
					strcat(rutaPosta1234, ruta4000);
					strcat(rutaPosta1234, nombreEntrenador555);
					strcat(rutaPosta1234, ruta2222);

					dir = opendir(rutaPosta1234);

					t_list * listaPokemonesConNivel = list_create();
					direntp = readdir(dir);
					while (direntp != NULL) {

						if (strstr(direntp->d_name, "dat") != NULL) {

							cargarElPokemonConNivel(direntp->d_name,
									rutaPosta1234, listaPokemonesConNivel);

						}
						direntp = readdir(dir);
					}
					closedir(dir);
					t_pokemon_entrenador* unPokemonDelEntrenador =
							busquedaDelMejorPokemon(listaPokemonesConNivel);
					mensajeAEnviar.protocolo = MEJORENTRENADOR;
					mensajeAEnviar.texto = unPokemonDelEntrenador->nombre;
					mensajeAEnviar.valor = unPokemonDelEntrenador->nivel;
					mensajeAEnviar.quantum = quantum;
					enviarMensajeEntreMapaYEntrenador(socketParaMapa,
							mensajeAEnviar);

					while (list_size(listaPokemonesConNivel) != 0) {
						list_remove(listaPokemonesConNivel, 0);

					}

					list_destroy(listaPokemonesConNivel);
					log_trace(logger_entrenador,
							"el ENTRENADOR ENTRO EN DEADLOCK y elige a su mejor pokemones que es:%s, de nivel:%d",
							unPokemonDelEntrenador->nombre,
							unPokemonDelEntrenador->nivel);
					flagDeadLock = true;
				} else {
					mensajeAEnviar.protocolo = FINDEQUANTUM;
					enviarMensajeEntreMapaYEntrenador(socketParaMapa,
							mensajeAEnviar);
				}
				flagQuantum = true;
				quantum = aux1;
				if (flagDeadLock == false) {
					if (flagMolesto3 == false
							&& ultimoProtocolo.protocolo == ATRAPARPOKEMON) {
						log_trace(logger_entrenador,
								"el Entrenador se le termino el QUANTUM");
						flagMolesto3 = true;
					} else {
						log_trace(logger_entrenador,
								"el Entrenador se le termino el QUANTUM");
					}
					flagDeadLock = false;
				}
			}
		} else {
			switch (mensajeARecibir.protocolo) {
			flagParaTerminar = false;
			// case OKEY:
			// mensajeAEnviar.protocolo=PEDIRPOKENEST;
			// enviarMensajeEntreMapaYEntrenador(socketParaMapa, mensajeAEnviar);
			// break;
		case ACEPTARSOLICITUD:
			mensajeAEnviar.protocolo = PEDIRPOKENEST;
			unPoke = (valuePokemon *) dictionary_get(ClienteConfig->hojaDeViaje,
					mapa->nombreMapa);
			char*dispositivo = unPoke->pokemon;
			mensajeAEnviar.texto = malloc(strlen(dispositivo) + 1);
			strcpy(mensajeAEnviar.texto, dispositivo);
			mensajeAEnviar.valor = x;
			mensajeAEnviar.valor2 = y;
			enviarMensajeEntreMapaYEntrenador(socketParaMapa, mensajeAEnviar);
			log_trace(logger_entrenador, "PEDIR POKENEST:%s",
					mensajeAEnviar.texto);
			free(mensajeAEnviar.texto);
			break;
		case ENVIARLOCALIZACIONPOKENEST:
			if (flagMolesto2 == false) {
				x = obtenerCoordenadaEnX(mensajeARecibir.texto);
				y = obtenerCoodenadaEnY(mensajeARecibir.texto);
				aux1 = x;
				aux2 = y;
				mensajeAEnviar.protocolo = AVANZARUNAPOSICION;
				contadorEnX++;
				mensajeAEnviar.valor = contadorEnX;
				mensajeAEnviar.valor2 = contadorEnY;
				x--;
				mensajeAEnviar.texto = ClienteConfig->simbolo;
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				log_trace(logger_entrenador, "AVANZAR POSICION");
				log_trace(logger_entrenador, "X:%d Y:%d", x, y);
				flagMolesto2 = true;
				movX = true;
				movY = false;
			}
			break;
		case MOVIMIENTOREALIZADO:
			if (FlagNUevo == false) {
				x = x - posX;
				y = y - posY;
				FlagNUevo = true;
			}
			if (movX == false && x > 0 && mov == false) {
				contadorEnX++;
				mensajeAEnviar.protocolo = MOVERENX;
				mensajeAEnviar.valor = contadorEnX;
				mensajeAEnviar.valor2 = contadorEnY;
				x--;
				movX = true;
				movY = false;
				log_trace(logger_entrenador, "MOVERSE EN X");
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				mov = true;
			} else if (movY == false && y > 0 && mov == false) {
				contadorEnY++;
				mensajeAEnviar.protocolo = MOVERENY;
				mensajeAEnviar.valor = contadorEnY;
				mensajeAEnviar.valor2 = contadorEnX;
				y--;
				movY = true;
				movX = false;
				mov = true;
				log_trace(logger_entrenador, "MOVERSE EN Y");
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
			} /////////////////
			if (movX == false && x < 0 && mov == false) {
				contadorEnX--;
				mensajeAEnviar.protocolo = MOVERENX;
				mensajeAEnviar.valor = contadorEnX;
				mensajeAEnviar.valor2 = contadorEnY;
				x++;
				movX = true;
				movY = false;
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				log_trace(logger_entrenador, "MOVERSE EN X");
				mov = true;
			} else if (movY == false && y < 0 && mov == false) {
				contadorEnY--;
				mensajeAEnviar.protocolo = MOVERENY;
				mensajeAEnviar.valor = contadorEnY;
				mensajeAEnviar.valor2 = contadorEnX;
				y++;
				movY = true;
				movX = false;
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				log_trace(logger_entrenador, "MOVERSE EN Y");
				mov = true;
			}
			///////////////////
			//////////////////
			if (x > 0 && y == 0 && mov == false) {
				contadorEnX++;
				mensajeAEnviar.protocolo = MOVERENX;
				mensajeAEnviar.valor = contadorEnX;
				mensajeAEnviar.valor2 = contadorEnY;
				x--;
				quantum--;
				ultimoProtocolo.protocolo = MOVERENX;
				ultimoProtocolo.valor = contadorEnX;
				ultimoProtocolo.valor2 = contadorEnY;
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				log_trace(logger_entrenador, "MOVERSE EN X");
				mov = true;
			}
			//////////////////////////////////
			if (x < 0 && y == 0 && mov == false) {
				contadorEnX--;
				mensajeAEnviar.protocolo = MOVERENX;
				mensajeAEnviar.valor = contadorEnX;
				mensajeAEnviar.valor2 = contadorEnY;
				x++;
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				log_trace(logger_entrenador, "MOVERSE EN X");
				mov = true;
			}
			///////////////////////
			if (y > 0 && x == 0 && mov == false) {
				contadorEnY++;
				mensajeAEnviar.protocolo = MOVERENY;
				mensajeAEnviar.valor = contadorEnY;
				mensajeAEnviar.valor2 = contadorEnX;
				y--;
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				log_trace(logger_entrenador, "MOVERSE EN Y");
				mov = true;
			}
			//////////////
			if (y < 0 && x == 0 && mov == false) {
				contadorEnY--;
				mensajeAEnviar.protocolo = MOVERENY;
				mensajeAEnviar.valor = contadorEnY;
				mensajeAEnviar.valor2 = contadorEnX;
				y++;
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				log_trace(logger_entrenador, "MOVERSE EN Y");
				mov = true;
			}
			//////////////
			if (x == 0 && y == 0 && flagMolesto == false && mov == false) {
				mensajeAEnviar.protocolo = ATRAPARPOKEMON;
				unPoke = (valuePokemon *) dictionary_get(
						ClienteConfig->hojaDeViaje, mapa->nombreMapa);
				char*dispositivo = unPoke->pokemon;
				mensajeAEnviar.texto = malloc(strlen(dispositivo) + 1);
				strcpy(mensajeAEnviar.texto, dispositivo);
				log_trace(logger_entrenador, "ATRAPAR POKEMON:%s",
						mensajeAEnviar.texto);
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				flagMolesto = true;
				time(&bloqueadoPokeIni);
				mov = true;
			}
			mov = false;
			break;

		case ESPERAR:
			mensajeAEnviar.protocolo = OKEY;
			enviarMensajeEntreMapaYEntrenador(socketParaMapa, mensajeAEnviar);

			break;
		case CAPTURAREALIZADA:
			posX = aux1;
			posY = aux2;
			time(&bloqueadoPokeFin);
			tiempoPokenests = tiempoPokenests
					+ difftime(bloqueadoPokeFin, bloqueadoPokeIni);
			agregarPokemonDirBill(mensajeARecibir.texto, mapa->nombreMapa);
			FlagNUevo = false;
			log_trace(logger_entrenador,
					"los valores que le llegan en X es:%d y en Y es:%d", posX,
					posY);
			dictionary_remove(ClienteConfig->hojaDeViaje, mapa->nombreMapa);
			/*
			 aca debo hacer un if consultando si tengo algo en la lista de mapas
			 de ser asi sigo con lo de abajo y sino debo hacer un else saliendo de esta
			 funcion
			 */
			if (dictionary_has_key(ClienteConfig->hojaDeViaje,
					mapa->nombreMapa)) {
				mensajeAEnviar.protocolo = PEDIRPOKENEST;
				unPoke = (valuePokemon *) dictionary_get(
						ClienteConfig->hojaDeViaje, mapa->nombreMapa);
				char*dispositivo = unPoke->pokemon;
				mensajeAEnviar.texto = malloc(strlen(dispositivo) + 1);
				strcpy(mensajeAEnviar.texto, dispositivo);
				enviarMensajeEntreMapaYEntrenador(socketParaMapa,
						mensajeAEnviar);
				log_trace(logger_entrenador, "PEDIR POKENEST:%s",
						mensajeAEnviar.texto);
				free(mensajeAEnviar.texto);
				flagMolesto = false;
				flagMolesto2 = false;
				//
				void imprimirClaveYValor(char* key, void* data) {
					valuePokemon* unPoke = (valuePokemon *) data;
					printf("Variable: %s Valor: %s \n", key, unPoke->pokemon);
				}
				dictionary_iterator(ClienteConfig->hojaDeViaje,
						imprimirClaveYValor);
				hacerCopiaDePokemon(mensajeARecibir.texto, fileName);

			} else {
				//se desconecta del mapa y va a otro
				copiarMedalla(mapa->nombreMapa, ClienteConfig->nombre);
				close(socketParaMapa);
				log_trace(logger_entrenador,
						"el entrador termino con este mapa");
				hacerCopiaDePokemon(mensajeARecibir.texto, fileName);
				flagParaTerminar = true;

				contadorEnX = 0;
				contadorEnY = 0;
				FlagNUevo = false;
				movX = true;
				movY = false;
				mov = false;
				flagMolesto = false;
				flagMolesto3 = false;
				flagMolesto2 = false;
				posX = 0;
				posY = 0;
				aux1 = 0;
				aux2 = 0;
			}
			break;
		case PERDISTE:
			log_trace(logger_entrenador, "EL ENTRENADOR PERDIO LA BATALLA");
			cantidadMuertes++;
			validarVidasReiniciar(mapa->nombreMapa);
			if (debeEmpezarDeCero || debeReprocesarMapa) {
				close(socketParaMapa);

				dictionary_clean_and_destroy_elements(
						ClienteConfig->hojaDeViaje, (void*) pokemon_destroy);
				free(ClienteConfig);
				iniciarConfiguracionDelEntrenador(argv1, argv2);
				flagAlgoritmo = true;
				flagParaTerminar = true;
				contadorEnX = 0;
				contadorEnY = 0;
				FlagNUevo = false;
				movX = true;
				movY = false;
				mov = false;
				flagMolesto = false;
				flagMolesto3 = false;
				flagMolesto2 = false;
				posX = 0;
				posY = 0;
				aux1 = 0;
				aux2 = 0;
				return;
			}
			printf("El entrenador fue elegido como victima y ha muerto\n");
			log_trace(logger_entrenador,
					"El entrenador fue elegido como victima y ha muerto");
			flagAlgoritmo = true;
			flagParaTerminar = true;
			contadorEnX = 0;
			contadorEnY = 0;
			FlagNUevo = false;
			movX = true;
			movY = false;
			mov = false;
			flagMolesto = false;
			flagMolesto3 = false;
			flagMolesto2 = false;
			posX = 0;
			posY = 0;
			aux1 = 0;
			aux2 = 0;

			break;
		case DEADLOCK:
			cantidadDeadlocks++;
			ruta4000 = "/home/utnso/mnt/pokedex/Entrenadores/";
			nombreEntrenador555 = fileName;
			ruta2222 = "/DirdeBill";
			rutaPosta1234 = malloc(
					strlen(ruta4000) + strlen(nombreEntrenador555)
							+ strlen(ruta2222) + 1);
			rutaPosta1234[0] = '\0';
			strcat(rutaPosta1234, ruta4000);
			strcat(rutaPosta1234, nombreEntrenador555);
			strcat(rutaPosta1234, ruta2222);

			dir = opendir(rutaPosta1234);

			t_list * listaPokemonesConNivel = list_create();
			direntp = readdir(dir);
			while (direntp != NULL) {

				if (strstr(direntp->d_name, "dat") != NULL) {

					cargarElPokemonConNivel(direntp->d_name, rutaPosta1234,
							listaPokemonesConNivel);

				}
				direntp = readdir(dir);
			}
			closedir(dir);
			t_pokemon_entrenador* unPokemonDelEntrenador =
					busquedaDelMejorPokemon(listaPokemonesConNivel);
			mensajeAEnviar.protocolo = MEJORENTRENADOR;
			mensajeAEnviar.texto = unPokemonDelEntrenador->nombre;
			mensajeAEnviar.valor = unPokemonDelEntrenador->nivel;
			enviarMensajeEntreMapaYEntrenador(socketParaMapa, mensajeAEnviar);

			while (list_size(listaPokemonesConNivel) != 0) {
				list_remove(listaPokemonesConNivel, 0);

			}

			list_destroy(listaPokemonesConNivel);
			log_trace(logger_entrenador,
					"el ENTRENADOR ENTRO EN DEADLOCK y elige a su mejor pokemones que es:%s, de nivel:%d",
					unPokemonDelEntrenador->nombre,
					unPokemonDelEntrenador->nivel);
			break;
			}
		}
	}
	//}
}

t_pokemon_entrenador* busquedaDelMejorPokemon(t_list* listaPokemonesConNivel) {

	int k = list_size(listaPokemonesConNivel);
	int i = 0;
	int j = 1;
	t_pokemon_entrenador* unPoke;

	if (k == 1) {

		unPoke = list_get(listaPokemonesConNivel, i);
		return unPoke;
	} else {
		while (j < list_size(listaPokemonesConNivel)
				&& i < list_size(listaPokemonesConNivel)) {

			t_pokemon_entrenador* pokeOne = list_get(listaPokemonesConNivel, i);
			t_pokemon_entrenador* poketwo = list_get(listaPokemonesConNivel, j);
			if (pokeOne->nivel >= poketwo->nivel) {
				j++;
				if (i == j) {
					j++;
				}
				unPoke = list_get(listaPokemonesConNivel, i);

			} else {
				i++;
				if (j == i) {
					i++;
					unPoke = list_get(listaPokemonesConNivel, j);

				}

			}

		}

	}
	return unPoke;
}

void cargarElPokemonConNivel(char* nombrePokeCon001, char* ruta,
		t_list* listaPokemonesConNivel) {
	t_pokemon_entrenador* unPokemonDelEntrenador = malloc(
			sizeof(t_pokemon_entrenador));
	bool delMomento = true;
	int w = 0;

	char*pokemon = malloc(strlen(nombrePokeCon001) + 1);
	pokemon[0] = '\0';
	while (delMomento) {
		if (isalpha(nombrePokeCon001[w])) {
			char *elem = charToString(nombrePokeCon001[w]);
			strcat(pokemon, elem);
			w++;

		} else {
			delMomento = false;
		}
	}

	unPokemonDelEntrenador->nombre = pokemon;
	///arriba saco el nombre pichachu abajo saco el nivel

	char * rutaNueva = malloc(
			strlen(ruta) + strlen("/") + strlen(nombrePokeCon001) + 1);
	rutaNueva[0] = '\0';
	strcat(rutaNueva, ruta);
	strcat(rutaNueva, "/");
	strcat(rutaNueva, nombrePokeCon001);

	t_config *tConfig3 = config_create(rutaNueva);
	if (config_has_property(tConfig3, "Nivel")) {
		unPokemonDelEntrenador->nivel = config_get_int_value(tConfig3, "Nivel");
	}
	list_add(listaPokemonesConNivel, unPokemonDelEntrenador);
	config_destroy(tConfig3);

}
char *String;
char * Concatena(char *String1, char *String2) {

	int i, j, i1, i2, tamano;
	for (i1 = 0; String1[i1] != '\0'; i1++)
		;
	i1--;
	for (i2 = 0; String2[i2] != '\0'; i2++)
		;
	i2--;
	tamano = i1 + i2;
	String = (char *) malloc(tamano + 1);
	for (j = 0, i = 0; String1[j] != '\0'; j++, i++)
		String[i] = String1[i];
	for (j = 0; String2[j] != '\0'; j++, i++)
		String[i] = String2[j];
	String[i] = '\0';
	return String;
}
bool flagpoke = true;
//liberar la palabraUnica
char*palabraUnica;
char* destino;
char*DirdeBill;
char* palabraUnica1;
void hacerCopiaDePokemon(char* algo, char*algo1) {
	char*copy = "cp ";

	//	char*origen = algo;

	if (flagpoke == true) {
		//liberar esto
		destino = malloc(strlen(" /home/utnso/mnt/pokedex/Entrenadores/") + 1);
		destino[0] = '\0';
		strcat(destino, " /home/utnso/mnt/pokedex/Entrenadores/");
		DirdeBill = malloc(strlen("/DirdeBill") + 1);
		DirdeBill[0] = '\0';
		strcat(DirdeBill, "/DirdeBill");
		palabraUnica1 = malloc(
						strlen(algo1) + strlen(destino) + strlen(DirdeBill) + 1);
				palabraUnica1[0] = '\0';
				strcat(palabraUnica1, destino);
				strcat(palabraUnica1, algo1);
				strcat(palabraUnica1, DirdeBill);
		flagpoke = false;
	}

	//	printf("%s\n", ret);
	char* ruta12 = malloc(strlen(algo) + 1);
		ruta12[0] = '\0';
		strcat(ruta12, algo);
	if (!string_ends_with(ruta12, ".dat")) {
		bool flag = true;
		int j = 0;
		while (flag) {
			if ('.' == ruta12[j]) {
				if ('d' == ruta12[j + 1]) {
					if ('a' == ruta12[j + 2]) {
						if ('t' == ruta12[j + 3]) {
							ruta12[j + 4] = '\0';
							flag = false;
						}
					}
				}
			}
			j++;
		}
	}
	copy = malloc(strlen(copy));
	copy[0] = '\0';
	strcat(copy, "cp ");

	char*rutaPoke = malloc(
			strlen(ruta12) + strlen(copy) + strlen(palabraUnica1) + 1);
	rutaPoke[0] = '\0';
	strcat(rutaPoke, copy);
	strcat(rutaPoke, ruta12);
	strcat(rutaPoke, palabraUnica1);

	system(rutaPoke);

	free(rutaPoke);
	free(copy);
	free(ruta12);

	//	free(destino);
	//	free(DirdeBill);

}
void seguirJugandoDespuesDeQuantum(int socket,
		mensaje_MAPA_ENTRENADOR ultimoProtocolo, int flag, t_mapas_server* mapa) {
	/// esta funcion va a enviar mensaje a mapa despues de q termine el quantum
	if (ultimoProtocolo.protocolo == PEDIRPOKENEST) {
		enviarMensajeEntreMapaYEntrenador(socket, ultimoProtocolo);
	} else if (ultimoProtocolo.protocolo == AVANZARUNAPOSICION) {
		enviarMensajeEntreMapaYEntrenador(socket, ultimoProtocolo);
	} else if (ultimoProtocolo.protocolo == MOVERENX) {
		enviarMensajeEntreMapaYEntrenador(socket, ultimoProtocolo);
	} else if (ultimoProtocolo.protocolo == MOVERENY) {
		enviarMensajeEntreMapaYEntrenador(socket, ultimoProtocolo);
	} else if (ultimoProtocolo.protocolo
			== ATRAPARPOKEMON&& flagMolesto==true) {
		log_trace(logger_entrenador, "entro acaaaaaaa");
		posX = aux1;
		posY = aux2;
		FlagNUevo = false;
		agregarPokemonDirBill(mensajeARecibir.texto, mapa->nombreMapa);
		dictionary_remove(ClienteConfig->hojaDeViaje, mapa->nombreMapa);
		if (dictionary_has_key(ClienteConfig->hojaDeViaje, mapa->nombreMapa)) {
			mensajeAEnviar.protocolo = PEDIRPOKENEST;
			valuePokemon * unPoke = (valuePokemon *) dictionary_get(
					ClienteConfig->hojaDeViaje, mapa->nombreMapa);
			char*dispositivo = unPoke->pokemon;
			mensajeAEnviar.texto = malloc(strlen(dispositivo) + 1);
			strcpy(mensajeAEnviar.texto, dispositivo);
			quantum--;
			ultimoProtocolo.protocolo = PEDIRPOKENEST;
			ultimoProtocolo.texto = malloc(strlen(dispositivo) + 1);
			strcpy(ultimoProtocolo.texto, dispositivo);
			enviarMensajeEntreMapaYEntrenador(socketParaMapa, mensajeAEnviar);
			log_trace(logger_entrenador,
					"la proxima pokenest que pide el entrenador es:%s",
					mensajeAEnviar.texto);
			free(mensajeAEnviar.texto);
			flagMolesto = false;
			//
			void imprimirClaveYValor(char* key, void* data) {
				valuePokemon* unPoke = (valuePokemon *) data;
				printf("Variable: %s Valor: %s \n", key, unPoke->pokemon);
			}
			dictionary_iterator(ClienteConfig->hojaDeViaje,
					imprimirClaveYValor);
			hacerCopiaDePokemon(mensajeARecibir.texto, fileName);
		} else {

			//se desconecta del mapa y va a otro
			close(socketParaMapa);
			log_trace(logger_entrenador, "el entrador termino con este mapa");
			hacerCopiaDePokemon(mensajeARecibir.texto, fileName);
			flagParaTerminar = true;
			flagParaTerminar = true;
			contadorEnX = 0;
			contadorEnY = 0;
			FlagNUevo = false;
			movX = true;
			movY = false;
			mov = false;
			flagMolesto = false;
			flagMolesto3 = false;
			posX = 0;
			posY = 0;
			aux1 = 0;
			aux2 = 0;
		}
	}
}
//ver mas adelante el tema de memori leaks
int obtenerCoordenadaEnX(char* posicion) {
	char *a = ";";
	char*palabra = charToString(a[0]);
	int contador = 0;
	int i = 0;
	while (posicion[i] != palabra[0]) {
		contador++;
		i++;
	}
	contador--;
	int j = 1;
	char*pos1 = charToString(posicion[0]);
	while (contador != 0) {
		char*pos2 = charToString(posicion[j]);
		strcat(pos1, pos2);
		j++;
		contador--;
	}
	return atoi(pos1);
}
//ver mas adelante el tema de memori leaks
int obtenerCoodenadaEnY(char* posicion) {
	char *a = ";";
	char*palabra = charToString(a[0]);
	int contador = 0;
	int i = 0;
	while (posicion[i] != palabra[0]) {
		contador++;
		i++;
	}
	contador += 1;
	char*pos1 = charToString(posicion[contador]);
	int j = contador + 1;
	char *b = "\0";
	char*palabra2 = charToString(b[0]);
	while (posicion[j] != palabra2[0]) {
		char*pos2 = charToString(posicion[j]);
		strcat(pos1, pos2);
		j++;
	}
	return atoi(pos1);
}
void iniciarLogTrace() {
	logger_entrenador = log_create("Log", "Entrenador", 1, 0);
}
void quitarCaracter(char *frase) {
	int i = 0;
	while (frase[i] != '\0') {
		frase[i] = frase[i + 1];
		i++;
	}
}
void iniciarConfiguracionDelEntrenador(char *direction, char* direction2) {
	fileName = malloc(strlen(direction) + 1);
	fileName2 = malloc(strlen(direction2) + 1);
	fileName[0] = '\0';
	strcat(fileName, direction);
	fileName2[0] = '\0';
	strcat(fileName2, direction2);
	char*metadata = malloc(strlen("metadata") + 1);
	metadata[0] = '\0';
	strcat(metadata, "metadata");
	char* barra = malloc(strlen("/") + 1);
	barra[0] = '\0';
	strcat(barra, "/");
	char* barra2 = malloc(strlen("/") + 1);
	barra2[0] = '\0';
	strcat(barra2, "/");

	char* utnSO = malloc(strlen("/home/utnso/") + 1);
	utnSO[0] = '\0';
	strcat(utnSO, "/home/utnso/");
	char* entrenadores = malloc(strlen("Entrenadores/") + 1);
	entrenadores[0] = '\0';
	strcat(entrenadores, "Entrenadores/");
	////ash.txt///
	char* barra3 = malloc(strlen("/") + 1);
	barra3[0] = '\0';
	strcat(barra3, "/");
	char* orden1 = malloc(strlen(fileName));
	orden1[0] = '\0';
	strcat(orden1, fileName);
	char* orden2 = malloc(strlen(".txt") + 1);
	orden2[0] = '\0';
	strcat(orden2, ".txt");
	char* archivo = malloc(strlen(fileName) + strlen(orden2) + 1);
	archivo[0] = '\0';
	strcat(archivo, barra3);
	strcat(archivo, orden1);
	strcat(archivo, orden2);
	// log_trace(log,"%s",archivo);
	rutaDeAcceso = malloc(
			strlen(direction) + strlen(utnSO) + strlen(barra) + strlen(barra2)
					+ strlen(direction2) + strlen(metadata) + strlen(archivo)
					+ strlen(entrenadores));
	rutaDeAcceso[0] = '\0';
	strcpy(rutaDeAcceso, utnSO);
	strcat(rutaDeAcceso, direction2);
	strcat(rutaDeAcceso, barra2);
	strcat(rutaDeAcceso, entrenadores);
	strcat(rutaDeAcceso, direction);
	strcat(rutaDeAcceso, barra);
	strcat(rutaDeAcceso, metadata);
	strcat(rutaDeAcceso, archivo);
	// log_trace(log,"%d",strlen(rutaDeAcceso));
	char* ConfigPath = rutaDeAcceso;
	ClienteConfig = malloc(sizeof(t_config_server));
	cargarConfig(ConfigPath, ClienteConfig);

	free(rutaDeAcceso);
	free(metadata);

	free(barra);

	free(barra2);

	free(utnSO);

	free(entrenadores);

	free(barra3);

	free(orden1);

	free(orden2);

	free(archivo);
}

void liberarDatos() {
	log_trace(logger_entrenador, "el entrenador libera datos");
	log_destroy(logger_entrenador);
	//	free(entrenador123123);
	while (list_size(listaDirBill) != 0) {
		list_remove(listaDirBill, 0);
	}
	while (list_size(listaMapaServer) != 0) {
		list_remove(listaMapaServer, 0);
	}

	dictionary_clean_and_destroy_elements(ClienteConfig->hojaDeViaje,
			(void*) pokemon_destroy);
	free(ClienteConfig);
	list_destroy(listaDirBill);
	list_destroy(listaMapaServer);
	free(palabraUnica);
	free(destino);
	free(DirdeBill);
	free(fileName);
	free(palabraUnica1);
	//free(fileName2);
	//free(rutaDeAcceso);
	free(mensajeAEnviar.texto);
	config_destroy(tConfig);
}

void sigusr1_handler(int sig) {
	incrementar_una_vida_entrenador(); //mutex aca adentro
	log_trace(logger_entrenador,
			string_from_format(
					"Se incrementaron las vidas del entrenador, el entrenador ahora tiene: %s vidas",
					string_itoa(ClienteConfig->vidas)));
}

void sigterm_handler(int sig) {
	decrementar_una_vida_entrenador(); //mutex aca adentro
	log_trace(logger_entrenador,
			string_from_format(
					"Se decrementaron las vidas del entrenador, el entrenador ahora tiene: %s vidas",
					string_itoa(ClienteConfig->vidas)));
}

void thread_signal_usr1(void* th_signal) {
	void sigusr1_handler(int sig);
	struct sigaction susr;

	susr.sa_handler = sigusr1_handler; //un struct para cada signal a tratar, struct del sigusr1
	susr.sa_flags = SA_RESTART; // si no se coloca este flag, la system call se interrumpe
	sigemptyset(&susr.sa_mask); //sa_mask contiene los signals que se pueden bloquear mientras, se trata el signal actual

	if (sigaction(SIGUSR1, &susr, NULL) == -1) {
		log_error(logger_entrenador,
				"thread_signal_usr1 -> error al catchear signal SIGUSR1");
		exit(1);
	}

	while (1)
		sleep(1);
}

void thread_signal_term(void* th_signal) {
	void sigterm_handler(int sig);
	struct sigaction sterm;

	sterm.sa_handler = sigterm_handler;
	sterm.sa_flags = SA_RESTART;
	sigemptyset(&sterm.sa_mask);

	if (sigaction(SIGTERM, &sterm, NULL) == -1) {
		log_error(logger_entrenador,
				"thread_signal_usr1 -> error al catchear signal SIGUSR1");
		exit(1);
	}

	while (1)
		sleep(1);

}

void incrementar_una_vida_entrenador(void) {
	pthread_mutex_lock(&m_vidasEntrenador);
	ClienteConfig->vidas = ClienteConfig->vidas + 1;
	pthread_mutex_unlock(&m_vidasEntrenador);

}

void decrementar_una_vida_entrenador(void) {
	pthread_mutex_lock(&m_vidasEntrenador);
	if (ClienteConfig->vidas > 0) {
		ClienteConfig->vidas = ClienteConfig->vidas - 1;
	}
	pthread_mutex_unlock(&m_vidasEntrenador);
	log_trace(logger_entrenador,
			"main_entrenador -> hilo para atender signal usr1 creado");
}

void crear_hilos_para_signals(void) {

	pthread_attr_t attr;
	pthread_t thread_usr1;
	pthread_t thread_term;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if (pthread_create(&thread_usr1, &attr, &thread_signal_usr1, NULL) < 0) {
		log_error(logger_entrenador,
				"main_entrenador -> error al crear el hilo para atender signal usr1");
	}
	log_trace(logger_entrenador,
			"main_entrenador -> hilo para atender signal usr1 creado");

	if (pthread_create(&thread_term, &attr, &thread_signal_term, NULL) < 0) {
		log_error(logger_entrenador,
				"main_entrenador -> error al crear el hilo para atender signal SIGTERM");
	}
	pthread_attr_destroy(&attr);
	log_trace(logger_entrenador,
			"main_entrenador -> hilo para atender signal SIGTERM creado");
}

void imprimir_segundos_formato_hh_mm_ss(double seg) {
	int st_hour = 3600;
	int st_min = 60;

	int cantidadSegundos = (int) round(seg);

	int hour = cantidadSegundos / st_hour;
	int second = cantidadSegundos % st_hour;
	int minute = second / st_min;
	second %= st_min;
	printf("%.2d:%.2d:%.2d\n", hour, minute, second);

	char str_formtat[11];
	sprintf(str_formtat, "%.2d:%.2d:%.2d", hour, minute, second);
	log_trace(logger_entrenador, str_formtat);
}

void imprimir_tiempos(time_t inicioAventura, time_t finAventura) {
	printf(
			"%s cumplio los objetivos de todos los mapas y se ha convertido en un Maestro Pokemon!\n",
			ClienteConfig->nombre);
	log_trace(logger_entrenador,
			string_from_format(
					"%s cumplio los objetivos de todos los mapas y se ha convertido en un Maestro Pokemon!\n",
					ClienteConfig->nombre));
	printf("El tiempo total de la aventura fue: \n ");
	log_trace(logger_entrenador, "El tiempo total de la aventura fue:");
	imprimir_segundos_formato_hh_mm_ss(difftime(finAventura, inicioAventura));
	printf("El tiempo que paso bloqueado en las PokeNest fue: \n ");
	log_trace(logger_entrenador,
			"El tiempo que paso bloqueado en las PokeNest fue:");
	imprimir_segundos_formato_hh_mm_ss(tiempoPokenests);
	printf("La cantidad de deadlocks en la que estuvo involucrado es: %d\n ",
			cantidadDeadlocks);
	log_trace(logger_entrenador,
			string_from_format(
					"La cantidad de deadlocks en la que estuvo involucrado es: %s\n ",
					string_itoa(cantidadDeadlocks)));
	printf("La cantidad de veces que murio es: %d\n ", cantidadMuertes);
	log_trace(logger_entrenador,
			string_from_format("La cantidad de veces que murio es: %s\n ",
					string_itoa(cantidadMuertes)));

}

void validarVidasReiniciar(char* nombreMapa) {
	t_list* pokemonsMapa = obtenerArchivosDeUnMapa(nombreMapa);
	if (ClienteConfig->vidas > 0) {
		decrementar_una_vida_entrenador();
		list_iterate(pokemonsMapa, &(borrarPokemonDirBill));
		listaDirBill = eliminarBillDeUnMapa(nombreMapa);
		debeReprocesarMapa = 1;
	} else {
		list_iterate(listaDirBill, &(borrarPokemonDirBill));
		list_clean(listaDirBill);
		debeEmpezarDeCero = 1;
	}
}

void borrarPokemonDirBill(void* pokeBill) {
	t_dir_bill* pokeB = (t_dir_bill*) pokeBill;
	char *pathArchivoBill = string_new();
	string_append(&pathArchivoBill, "/home/utnso/mnt/pokedex/Entrenadores/");
	string_append(&pathArchivoBill, ClienteConfig->nombre);
	string_append(&pathArchivoBill, "/DirdeBill/");
	string_append(&pathArchivoBill, pokeB->nombreArchivoPokemon);
	borrarArchivoDirectorio(pathArchivoBill);
}

void agregarPokemonDirBill(char* ruta_pokemon, char* nombreMapa) {
	int cad_actual = 0;
	t_dir_bill *dirBill = malloc(sizeof(t_dir_bill));
	char** cadenas_del_path = string_split(ruta_pokemon, "/");
	while (cadenas_del_path[cad_actual] != NULL) {
		if (string_ends_with(cadenas_del_path[cad_actual], ".dat")) {
			dirBill->nombreMapa = nombreMapa;
			dirBill->nombreArchivoPokemon = cadenas_del_path[cad_actual];
			list_add(listaDirBill, dirBill);

		}
		cad_actual++;
	}
	//free(dirBill);
}

t_list* obtenerArchivosDeUnMapa(char* nombreMapa) {
	mapaBuscadoBill = nombreMapa;
	return list_filter(listaDirBill, &(esDirDeBillDeMapa));
}

bool esDirDeBillDeMapa(void* bill_actual) {
	t_dir_bill* dir_bill = (t_dir_bill*) bill_actual;
	return string_equals_ignore_case(dir_bill->nombreArchivoPokemon,
			mapaBuscadoBill);
}

bool NoesDirDeBillDeMapa(void* bill_actual) {
	t_dir_bill* dir_bill = (t_dir_bill*) bill_actual;
	return !(string_equals_ignore_case(dir_bill->nombreArchivoPokemon,
			mapaBuscadoBill));
}

t_list* eliminarBillDeUnMapa(char* nombreMapa) {
	mapaBuscadoBill = nombreMapa;
	return list_filter(listaDirBill, &(NoesDirDeBillDeMapa));
}

void borrarArchivoDirectorio(char* arch_o_dir) {
	if (remove(arch_o_dir))
		log_error(logger_entrenador,
				string_from_format("Error al borrar el archivo o directorio %s",
						arch_o_dir));
}

int ofrecerReintento(void) {
	char respuesta;
	int retorno;
	printf(
			"Ya no le quedan vidas para seguir jugando, desea volver a intentarlo?\n");
	printf("Su cantidad de reintentos hasta ahora es: %d", cantidadReintentos);
	printf("Presione S seguido de un enter para volver a intentarlo \n");
	printf("Presione N seguido de un enter para salir \n");
	respuesta = getchar();
	if (respuesta == 'S' || respuesta == 's') {
		retorno = 1;
	} else {
		retorno = 0;
	}
	return retorno;
}

void copiarMedalla(char* nombreMapa, char* nombreEntrenador) {
	char* ruta= string_new();
	string_append(&ruta, "cp ");
	string_append(&ruta, "/home/utnso/mnt/pokedex/Mapas/");
	string_append(&ruta, nombreMapa);
	string_append(&ruta, "/medalla-");
	string_append(&ruta, nombreMapa);
	string_append(&ruta, ".jpg");
	string_append(&ruta, " /home/utnso/mnt/pokedex/Entrenadores/");
	string_append(&ruta, nombreEntrenador);
	string_append(&ruta, "/medallas/");

	system(ruta);

	free(ruta);

}

