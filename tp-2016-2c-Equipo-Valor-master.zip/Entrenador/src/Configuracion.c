/*
 * tConfig.c
 *
 *  Created on: 29/8/2016
 *      Author: utnso
 */

//
#include "Configuracion.h"
#include "stdio.h"
#include "string.h"




t_config *unaConfig;

char* objetivosDelMapa(char* palabraAAgregar) {

	char* hola= "obj[";
	char*hola1="]";
	char * new= malloc(strlen(palabraAAgregar)+strlen(hola)+strlen(hola1)+1);
	new[0]='\0';
	strcat(new,hola);

	strcat(new,palabraAAgregar);
	strcat(new,hola1);
	return new;
}



void agregarAlDiccionarioDeMapaServer(char* palabraAAgregar1) {



	char* amigo ="/home/utnso/mnt/pokedex/Mapas/";
	char* palabra1=palabraAAgregar1;
	char* palabra2 = palabraAAgregar1;

	char *barra ="/";
	char* barra1 ="/";
	char*metadata ="metadata";
	char* orden2=".txt";


	char* archivo1=malloc(strlen(palabra1)
			+strlen(palabra2)+strlen(amigo) +strlen(barra) +strlen(barra1)
			+strlen(metadata) +strlen(orden2)+1);


	archivo1[0]='\0';
	strcat(archivo1,amigo);
	strcat(archivo1,palabra1);
	strcat(archivo1,barra1);
	strcat(archivo1,metadata);
	strcat(archivo1,barra);
	strcat(archivo1,palabra2);
	strcat(archivo1,orden2);



	unaConfig = config_create(archivo1);




	t_mapas_server* mapaServer =malloc(sizeof(t_mapas_server));
	mapaServer->nombreMapa=palabraAAgregar1;
	printf("%d\n",strlen(archivo1));
	if (config_has_property(unaConfig, "IP")) {
		mapaServer->serverIp = config_get_string_value(unaConfig, "IP");
		printf("la ruta es:%s\n",config_get_string_value(unaConfig, "IP"));
	}
	if (config_has_property(unaConfig, "PUERTO")) {
		printf("la ruta es\n");
		mapaServer->puerto = config_get_int_value(unaConfig, "PUERTO");
		printf("la ruta es:%d\n",config_get_int_value(unaConfig, "PUERTO"));
	}

	list_add(listaMapaServer,mapaServer);


	///hace varios freesss

	free(archivo1);
}




int cargarConfig(char* archivoRuta, t_config_server* configCliente ) {
	// Genero tabla de tConfig
	tConfig = config_create(archivoRuta);
	if (tConfig == NULL) {
		printf("ERROR: no se encuentra o falta el archivo de tConfig en la direccion \t%s \n", archivoRuta);

		return 0;
	}



	// Verifico que el archivo de tConfig tenga la cantidad de parametros correcta.
	//	if (config_keys_amount(tConfig) == CANTIDAD_PARAMETROS_CONFIG) {
	// Verifico que los parametros tengan sus valores OK
	// Verifico parametro PUERTO
	if(config_has_property(tConfig,"nombre")){
		configCliente->nombre= config_get_string_value(tConfig,"nombre");
	}else {
		printf("ERROR: Falta el parametro: %s. \n", "nombre");
		return 1;
	}
	if(config_has_property(tConfig,"simbolo")){
		configCliente->simbolo = config_get_string_value(tConfig,"simbolo");
	}else {
		printf("ERROR: Falta el parametro: %s. \n", "simbolo");
		return 1;
	}
	configCliente->hojaDeViaje=dictionary_create();


	listaMapaServer = list_create();
	int k = 0;

	while (&(*config_get_array_value(tConfig, "hojaDeViaje")[k])
			!= NULL) {


		char *palabraAAgregar =config_get_array_value(tConfig, "hojaDeViaje")[k];
		agregarAlDiccionarioDeMapaServer(palabraAAgregar);

		if(config_has_property(tConfig,objetivosDelMapa(palabraAAgregar))){
			int i=0;
			while(&(*config_get_array_value(tConfig, objetivosDelMapa(palabraAAgregar))[i])
					!= NULL){
				valuePokemon* valor = malloc(sizeof(valuePokemon));

				valor->pokemon = config_get_array_value(tConfig, objetivosDelMapa(palabraAAgregar))[i];
				dictionary_put(configCliente->hojaDeViaje,
						&(*config_get_array_value(tConfig, "hojaDeViaje")[k]),
						(void*) valor);
				i++;

			}
		}

		k++;
	}
	void imprimirClaveYValor(char* key, void* data) {
		valuePokemon* unPoke = (valuePokemon *) data;

		printf("Variable: %s  Valor: %s \n", key, unPoke->pokemon);

	}
	dictionary_iterator(configCliente->hojaDeViaje, imprimirClaveYValor);




	if (config_has_property(tConfig, "vidas")) {
		configCliente->vidas = config_get_int_value(tConfig, "vidas");
	} else {
		printf("ERROR: Falta el parametro: %s. \n", "vidas");
		return 1;
	}
	if (config_has_property(tConfig, "reintentos")) {
		configCliente->reintentos = config_get_int_value(tConfig, "reintentos");
	} else {
		printf("ERROR: Falta el parametro: %s. \n", "reintentos");
		return 1;
	}
	//		i
	//	} else {
	//			printf("ERROR: Falta el parametro: %s. \n", "IP_SERVER");
	//			return 1;
	//		}



	printf("el nombre del entrenador es: %s\n su simbolo es: %s\n sus vidas son:%d\n sus reintentos son:%d\n"
			,configCliente->nombre,
			configCliente->simbolo,
			configCliente->vidas,
			configCliente->reintentos);
	return 1;
	//	} else {
	//		printf("ERROR: El archivo SERVER.cfg no tiene los %d campos que debería.\n", CANTIDAD_PARAMETROS_CONFIG);
	//		return 0;
	//	}
}

void finalizarConfig() {
	config_destroy(tConfig);
}





