#ifndef LIBRERIAS_SF_SOCKETS_H_
#define LIBRERIAS_SF_SOCKETS_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include "tiposDato.h"
#include <stdint.h>
#include <errno.h>

int crearSocketServidor(char PUERTO[]);
int IniciarSocketServidor(int puertoServer);
int conectarConServer(char *ipServer, int puertoServer);
int enviarMensaje(int socketCliente, char* mensaje);
char* recibirMsjConEncabezado(int, t_msjCabecera*);
int recibirMsjCompleto(int, char*, int);
int enviarMsjConEncabezado(int, char*, t_msjCabecera*);
int enviarMsjCompleto(int, char*, int);
char* empaquetarCabecera(t_msjCabecera*, int*);
t_msjCabecera* desempaquetarCabecera(char*);
int enviarmensajeMAPA_ENTRENADOR(int socket,mensaje_MAPA_ENTRENADOR* mensajeAEnviar);
int recibirmensajeMAPA_ENTRENADOR(int nuevoSocketAceptado, mensaje_MAPA_ENTRENADOR* mensajeARecibir);
int AceptarConexionCliente(int);

#endif /* LIBRERIAS_SF_SOCKETS_H_ */
