/*
 * mensajesPokeDex.h
 *
 *  Created on: 26/10/2016
 *      Author: Marcelo Cejas
 */

#ifndef SRC_MENSAJESPOKEDEX_H_
#define SRC_MENSAJESPOKEDEX_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <commons/collections/list.h>
#include <commons/log.h>
#include "tiposDato.h"

typedef struct directorioList_t{
	int fileLength;
	char* file;
}t_directorioList;

typedef struct mensaje_GETATTR_t {
	unsigned int mode;
	unsigned int nLink;
	unsigned int size;
	uint32_t lastMod;
}__attribute__((__packed__))  t_mensaje_GETATTR;

typedef struct mensaje_WRITE_t {
	long int size;
	int pathLen;
	char* path;
	char* buffer;
}__attribute__((__packed__))  t_mensaje_WRITE;

typedef struct mensaje_RENAME_t {
	int oldnameLen;
	int newnameLen;
	char* oldname;
	char* newname;
}__attribute__((__packed__))  t_mensaje_RENAME;

typedef struct mensaje_TRUNCATE_t {
	int newLen;
	int fileLen;
	char* filename;
}__attribute__((__packed__))  t_mensaje_TRUNCATE;

t_mensaje_GETATTR* desempaquetarGETATTR(char* empaquetado);
char* empaquetarGETATTR(t_mensaje_GETATTR* mensaje, int* largo);
t_list* desempaquetarDirectorio(char* empaquetado);
char* empaquetarDirectorio(t_list* files, int* size);
t_directorioList *file_create(char *name, unsigned int length);
char* empaquetarWRITE(t_mensaje_WRITE* mensaje, int* largo);
t_mensaje_WRITE* desempaquetarWRITE(char* empaquetado);
t_mensaje_RENAME* desempaquetarRENAME(char* empaquetado);
char* empaquetarRENAME(t_mensaje_RENAME* mensaje, int* largo);
char* empaquetarTRUNCATE(t_mensaje_TRUNCATE* mensaje, int* largo);
t_mensaje_TRUNCATE* desempaquetarTRUNCATE(char* empaquetado);

#endif /* SRC_MENSAJESPOKEDEX_H_ */
