#include "sw_sockets.h"

/////////////////////////funciones nuevas//////////////////////
int conectarConServer(char *ipServer, int puertoServer) {
	struct sockaddr_in socket_info;
	int nuevoSocket;
	// Se carga informacion del socket
	socket_info.sin_family = AF_INET;
	socket_info.sin_addr.s_addr = inet_addr(ipServer);
	socket_info.sin_port = htons(puertoServer);

	// Crear un socket:
	// AF_INET, SOCK_STREM, 0
	nuevoSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (nuevoSocket < 0)
		return -1;
	// Conectar el socket con la direccion 'socketInfo'.
	if (connect(nuevoSocket, (struct sockaddr *) &socket_info,sizeof(socket_info)) != 0) {
		perror("Problema al intentar la conexión con el Servidor");
		exit(3);
		return -1;
	}

	return nuevoSocket;
}

int IniciarSocketServidor(int puertoServer) {
	struct sockaddr_in socketInfo;
	int socketEscucha;
	int optval = 1;

	// Crear un socket
	socketEscucha = socket(AF_INET, SOCK_STREAM, 0);
	if (socketEscucha == -1)
		return -1;

	setsockopt(socketEscucha, SOL_SOCKET, SO_REUSEADDR, &optval,
			sizeof(optval));
	socketInfo.sin_family = AF_INET;
	socketInfo.sin_port = htons(puertoServer);
	socketInfo.sin_addr.s_addr = INADDR_ANY;
	if (bind(socketEscucha, (struct sockaddr *) &socketInfo, sizeof(socketInfo))!= 0) {
		close(socketEscucha);
		return -1;
	}

	/*
	 * Se avisa al sistema que comience a atender llamadas de clientes
	 */
	if (listen(socketEscucha, 10) == -1) {
		close(socketEscucha);
		return -1;
	}
	/*
	 * Se devuelve el descriptor del socket servidor
	 */
	return socketEscucha;
}

/////////////////////////funciones nuevas//////////////////////

int AceptarConexionCliente(int socketServer) {
	socklen_t longitudCliente;//esta variable tiene inicialmente el tamaño de la estructura cliente que se le pase
	struct sockaddr cliente;
	int socketNuevaConexion;//esta variable va a tener la descripcion del nuevo socket que estaria creando
	longitudCliente = sizeof(cliente);
	socketNuevaConexion = accept(socketServer, &cliente, &longitudCliente);	//acepto la conexion del cliente
	if (socketNuevaConexion < 0)
		return -1;

	return socketNuevaConexion;

}

int crearSocketCliente(char ip[], int puerto) {
	int socketCliente;
	struct sockaddr_in servaddr;

	if ((socketCliente = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("Problem creando el Socket.");
		exit(2);
	}

	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr(ip);
	servaddr.sin_port = htons(puerto);

	if (connect(socketCliente, (struct sockaddr *) &servaddr, sizeof(servaddr))
			< 0) {
		perror("Problema al intentar la conexión con el Servidor");
		exit(3);
	}
	return socketCliente;
}

//FUNCIONES PARA PASE DE CHARS
int enviarMensaje(int socketCliente, char* mensaje) {
	int estadoDeEnvio = send(socketCliente, mensaje, strlen(mensaje) + 1, 0);
	if (estadoDeEnvio > 0)
		printf("El mensaje se envio correctamente\n");
	return socketCliente;
}

void recibirEImprimirMensaje(int socketCliente, int tamanioMensaje) {
	char mensajeRecibido[tamanioMensaje];
	recv(socketCliente, (void*) mensajeRecibido, tamanioMensaje, 0);
	printf("%s\n", mensajeRecibido);
}

char* recibirMsjConEncabezado(int socketEmisor, t_msjCabecera* msjCabecera) {
	int totalLeido = 0;

	int msjTamanio = sizeof(t_msjCabecera);
	char* buffer = malloc(msjTamanio);

	if ((socketEmisor < 0) || (buffer == NULL)) {
		printf("Error inicando el buffer para la cabecera.\n");
		return NULL;
	}

	t_msjCabecera* cabeceraAux;
	if ((totalLeido = recibirMsjCompleto(socketEmisor, buffer, msjTamanio))
			> 0) {
		cabeceraAux = desempaquetarCabecera(buffer);
	} else {
		printf("Error recibiendo msj cabecera.\n");
		free(buffer);
		return NULL;
	}

	buffer = malloc(cabeceraAux->logitudMensaje);
	if ((totalLeido = recibirMsjCompleto(socketEmisor, buffer,
			cabeceraAux->logitudMensaje)) < 0) {
		free(buffer);
		return NULL;
	}

	if (totalLeido != cabeceraAux->logitudMensaje)
		printf("Mensaje recibido incompleto.\n");

	*msjCabecera = *cabeceraAux;
	return buffer;
}

int recibirMsjCompleto(int socketEmisor, char* buffer, int tamanio) {
	int totalLeido = 0, aux = 0;

	while (totalLeido < tamanio && totalLeido != -1) {
		aux = recv(socketEmisor, buffer + totalLeido, tamanio - totalLeido, 0);
		if (aux > 0) {
			totalLeido = totalLeido + aux;
		} else {
			if (aux == 0)
				break;
			if (aux == -1) {
				switch (errno) {
				case EINTR:
				case EAGAIN:
					usleep(100);
					break;
				default:
					totalLeido = -1;
				}
			}
		}
	}
	return totalLeido;
}

int enviarMsjConEncabezado(int socketDestino, char* msj, t_msjCabecera* msjCabecera) {
	int totalEnviado = 0;

	if ((socketDestino == -1) || (socketDestino < 1))
		return -1;

	char* buffer;
	int* largoBuffer = malloc(sizeof(int16_t));
	buffer = empaquetarCabecera(msjCabecera, largoBuffer);

	totalEnviado = enviarMsjCompleto(socketDestino, buffer, *largoBuffer);
	if (totalEnviado != sizeof(t_msjCabecera)) {
		printf("Error enviando cabecera de mensaje.");
		totalEnviado = -1;
	} else {
		totalEnviado = enviarMsjCompleto(socketDestino, msj,
				msjCabecera->logitudMensaje);
		if (totalEnviado != msjCabecera->logitudMensaje) {
			totalEnviado = -1;
			printf("Error enviando mensaje principal.\n");
		}
	}
	free(buffer);

	return totalEnviado;
}

int enviarMsjCompleto(int socketDestino, char* buffer, int longitudMensaje) {
	int totalEnviado = 0, aux = 0;

	while (totalEnviado < longitudMensaje && totalEnviado != -1) {
		aux = send(socketDestino, buffer + totalEnviado,
				longitudMensaje - totalEnviado, 0);
		if (aux > 0) {

			totalEnviado = totalEnviado + aux;
		} else {

			if (aux == 0)
				return totalEnviado;
			else
				switch (errno) {
				case EINTR:
				case EAGAIN:
					usleep(100);
					break;
				default:
					totalEnviado = -1;
				}
		}
	}
	return totalEnviado;
}

char* empaquetarCabecera(t_msjCabecera* mensaje, int* largo) {
	char *empaquetado = malloc(
			sizeof(mensaje->tipoMensaje) + sizeof(mensaje->logitudMensaje));

	int offset = 0, tmp_size = 0;
	memcpy(empaquetado + offset, &mensaje->tipoMensaje, tmp_size = sizeof(mensaje->tipoMensaje));
	offset = tmp_size;
	memcpy(empaquetado + offset, &mensaje->logitudMensaje, tmp_size = sizeof(mensaje->logitudMensaje));
	offset += tmp_size;

	*largo = offset;
	return empaquetado;
}

t_msjCabecera* desempaquetarCabecera(char* empaquetado) {
	t_msjCabecera* mensaje = malloc(sizeof(t_msjCabecera));
	int offset = 0, tmp_len = 0;
	memcpy(&mensaje->tipoMensaje, empaquetado + offset,	tmp_len = sizeof(mensaje->tipoMensaje));
	offset = tmp_len;
	memcpy(&mensaje->logitudMensaje, empaquetado + offset, tmp_len = sizeof(mensaje->logitudMensaje));

	return mensaje;

}

int recibirMensajeEntreMapaYEntrenador(int socket,
		mensaje_MAPA_ENTRENADOR *mensajeARecibir) {
	int resultado;
	char * buffer = malloc(	sizeof(uint32_t) * 2 + sizeof(instruccion_t) + sizeof(int) * 4);
	resultado = recv(socket, (void *) buffer, sizeof(uint32_t) * 2 + sizeof(instruccion_t) + sizeof(int) * 4, 0);
	if (resultado > 0) {
		memcpy(mensajeARecibir, buffer, sizeof(uint32_t) * 2 + sizeof(instruccion_t) + sizeof(int) * 4);
		if (mensajeARecibir->tamanoMensaje > 0) {
			free(buffer);
			buffer = malloc(mensajeARecibir->tamanoMensaje);
			recv(socket, (void *) buffer, mensajeARecibir->tamanoMensaje, 0);
			mensajeARecibir->texto = malloc(mensajeARecibir->tamanoMensaje + 1);
			memcpy(mensajeARecibir->texto, buffer, mensajeARecibir->tamanoMensaje);
			mensajeARecibir->texto[mensajeARecibir->tamanoMensaje] = '\0';
		}
		free(buffer);
		return resultado;
	}
	return resultado;
}

int enviarMensajeEntreMapaYEntrenador(int socket,
		mensaje_MAPA_ENTRENADOR mensajeAMandar) {
	int resultado;
	if (mensajeAMandar.protocolo == INSTRUCCION) {
		mensajeAMandar.tamanoMensaje = 0;
	} else if (mensajeAMandar.protocolo == PEDIRPOKENEST) {
		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	} else if (mensajeAMandar.protocolo == INICIARJUEGO) {
		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	} else if (mensajeAMandar.protocolo == ENVIARLOCALIZACIONPOKENEST) {
		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	} else if (mensajeAMandar.protocolo == AVANZARUNAPOSICION) {
		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	} else if (mensajeAMandar.protocolo == MOVERENX) {
		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	} else if (mensajeAMandar.protocolo == MOVERENY) {
		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	}else if(mensajeAMandar.protocolo==MEJORENTRENADOR){
		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	}
	else if(mensajeAMandar.protocolo == CAPTURAREALIZADA){

		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	}
	else if (mensajeAMandar.protocolo == ATRAPARPOKEMON) {
		mensajeAMandar.tamanoMensaje = strlen(mensajeAMandar.texto);
	} else {
		mensajeAMandar.tamanoMensaje = 0;
	}

	char*buffer = malloc(2 * sizeof(uint32_t) + 4 * sizeof(int) + sizeof(instruccion_t) + mensajeAMandar.tamanoMensaje);

	memcpy(buffer, &mensajeAMandar, 2 * sizeof(uint32_t) + 4 * sizeof(int) + sizeof(instruccion_t));

	if (mensajeAMandar.tamanoMensaje > 0) {
		memcpy(buffer + 2 * sizeof(uint32_t) + 4 * sizeof(int)+ sizeof(instruccion_t), mensajeAMandar.texto,
				mensajeAMandar.tamanoMensaje);
	}
	resultado = send(socket, buffer,2 * sizeof(uint32_t) + 4 * sizeof(int) + sizeof(instruccion_t)
					+ mensajeAMandar.tamanoMensaje, 0);
	free(buffer);
	return resultado;
}

