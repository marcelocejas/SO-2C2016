/*
 * mensajesPokeDex.c
 *
 *  Created on: 26/10/2016
 *      Author: Marcelo Cejas
 */

#include "mensajesPokeDex.h"

t_mensaje_GETATTR* desempaquetarGETATTR(char* empaquetado){
	t_mensaje_GETATTR* msjGetAttr = malloc(sizeof(t_mensaje_GETATTR));
	int offset = 0, tmp_len = 0;
	memcpy(&msjGetAttr->mode, empaquetado + offset, tmp_len = sizeof(msjGetAttr->mode));
	offset += tmp_len;
	memcpy(&msjGetAttr->nLink, empaquetado + offset, tmp_len = sizeof(msjGetAttr->nLink));
	offset += tmp_len;
	memcpy(&msjGetAttr->size, empaquetado + offset, tmp_len = sizeof(msjGetAttr->size));
	offset += tmp_len;
	memcpy(&msjGetAttr->lastMod, empaquetado + offset, tmp_len = sizeof(msjGetAttr->lastMod));

	return msjGetAttr;
}

char* empaquetarGETATTR(t_mensaje_GETATTR* mensaje, int* largo) {
	char *empaquetado = malloc(sizeof(mensaje->mode) + sizeof(mensaje->nLink) + sizeof(mensaje->size) + sizeof(mensaje->lastMod));

	int offset = 0, tmp_size = 0;
	memcpy(empaquetado + offset, &mensaje->mode, tmp_size = sizeof(mensaje->mode));
	offset = tmp_size;
	memcpy(empaquetado + offset, &mensaje->nLink, tmp_size = sizeof(mensaje->nLink));
	offset += tmp_size;
	memcpy(empaquetado + offset, &mensaje->size, tmp_size = sizeof(mensaje->size));
	offset += tmp_size;
	memcpy(empaquetado + offset, &mensaje->lastMod, tmp_size = sizeof(mensaje->lastMod));
	offset += tmp_size;

	*largo = offset;
	return empaquetado;
}

t_directorioList *file_create(char *name, unsigned int length) {
	t_directorioList *new = malloc(sizeof(t_directorioList));
    new->file = strdup(name);
    new->fileLength = length;
    return new;
}

t_list* desempaquetarDirectorio(char* empaquetado) {
	t_list* files = list_create();
	//t_directorioList* file = malloc(sizeof(t_directorioList));

	int nombreLargo;

	int offset = 0, tmp_len = 0;
	int i;
	int tamanio;
	memcpy(&tamanio, empaquetado + offset, tmp_len = sizeof(int));


	for (i = 0; i < tamanio; i++) {
		offset = offset + tmp_len;
		memcpy(&nombreLargo, empaquetado + offset, tmp_len = sizeof(int));
		offset = offset + tmp_len;
		char* nombre = malloc(nombreLargo);
		memcpy(nombre, empaquetado + offset, tmp_len = nombreLargo);
		list_add(files, file_create(nombre,nombreLargo));
	}

	return files;
}

char* empaquetarDirectorio(t_list* files, int* size) {
	int i;
	int tamanioBuffer=0;
	int listSize = list_size(files);
	t_directorioList* file = malloc(sizeof(t_directorioList));
	tamanioBuffer = listSize * sizeof(file->fileLength) + sizeof(listSize);
	file->file = malloc(7);
	for (i = 0; i < list_size(files); i++) {
		file = list_get(files, i);
		tamanioBuffer = tamanioBuffer + file->fileLength;
	}
	char *empaquetado = malloc(tamanioBuffer);

	int offset = 0, tmp_size = 0;
	memcpy(empaquetado + offset, &listSize, tmp_size = sizeof(int));
	offset = offset + tmp_size;

	for (i = 0; i < listSize; i++) {
		file = list_get(files, i);
		memcpy(empaquetado + offset, &file->fileLength,tmp_size = sizeof(file->fileLength));
		offset = offset + tmp_size;
		memcpy(empaquetado + offset, file->file, tmp_size = file->fileLength);
		offset = offset + tmp_size;
	}

	*size = offset;

	return empaquetado;
}

t_mensaje_WRITE* desempaquetarWRITE(char* empaquetado){
	t_mensaje_WRITE* msjWrite = malloc(sizeof(t_mensaje_WRITE));
	int offset = 0, tmp_len = 0;

	memcpy(&msjWrite->pathLen, empaquetado + offset, tmp_len = sizeof(msjWrite->pathLen));
	offset += tmp_len;
	memcpy(&msjWrite->size, empaquetado + offset, tmp_len = sizeof(msjWrite->size));
	offset += tmp_len;
	msjWrite->path = malloc(msjWrite->pathLen);
	memcpy(msjWrite->path, empaquetado + offset, tmp_len = msjWrite->pathLen);
	offset += tmp_len;
	msjWrite->buffer = malloc(msjWrite->size);
	memcpy(msjWrite->buffer, empaquetado + offset, tmp_len = msjWrite->size);

	return msjWrite;
}

char* empaquetarWRITE(t_mensaje_WRITE* mensaje, int* largo){
	char *empaquetado = malloc(sizeof(mensaje->pathLen) + sizeof(mensaje->size) + mensaje->size + mensaje->pathLen);

	int offset = 0, tmp_size = 0;
	memcpy(empaquetado + offset, &mensaje->pathLen, tmp_size = sizeof(mensaje->pathLen));
	offset = tmp_size;
	memcpy(empaquetado + offset, &mensaje->size, tmp_size = sizeof(mensaje->size));
	offset += tmp_size;
	memcpy(empaquetado + offset, mensaje->path, tmp_size = mensaje->pathLen);
	offset += tmp_size;
	memcpy(empaquetado + offset, mensaje->buffer, tmp_size = mensaje->size);
	offset += tmp_size;

	*largo = offset;
	return empaquetado;
}

t_mensaje_RENAME* desempaquetarRENAME(char* empaquetado){
	t_mensaje_RENAME* msjWrite = malloc(sizeof(t_mensaje_RENAME));
	int offset = 0, tmp_len = 0;

	memcpy(&msjWrite->newnameLen, empaquetado + offset, tmp_len = sizeof(msjWrite->newname));
	offset += tmp_len;
	memcpy(&msjWrite->oldnameLen, empaquetado + offset, tmp_len = sizeof(msjWrite->oldname));
	offset += tmp_len;
	msjWrite->newname = malloc(msjWrite->newnameLen);
	memcpy(msjWrite->newname, empaquetado + offset, tmp_len = msjWrite->newnameLen);
	offset += tmp_len;
	msjWrite->oldname = malloc(msjWrite->oldnameLen);
	memcpy(msjWrite->oldname, empaquetado + offset, tmp_len = msjWrite->oldnameLen);

	return msjWrite;
}

char* empaquetarRENAME(t_mensaje_RENAME* mensaje, int* largo){
	char *empaquetado = malloc(sizeof(mensaje->newnameLen) + sizeof(mensaje->oldnameLen) + mensaje->newnameLen + mensaje->oldnameLen);

	int offset = 0, tmp_size = 0;
	memcpy(empaquetado + offset, &mensaje->newnameLen, tmp_size = sizeof(mensaje->newnameLen));
	offset = tmp_size;
	memcpy(empaquetado + offset, &mensaje->oldnameLen, tmp_size = sizeof(mensaje->oldnameLen));
	offset += tmp_size;
	memcpy(empaquetado + offset, mensaje->newname, tmp_size = mensaje->newnameLen);
	offset += tmp_size;
	memcpy(empaquetado + offset, mensaje->oldname, tmp_size = mensaje->oldnameLen);
	offset += tmp_size;

	*largo = offset;
	return empaquetado;
}

t_mensaje_TRUNCATE* desempaquetarTRUNCATE(char* empaquetado){
	t_mensaje_TRUNCATE* msjTRUNCATE = malloc(sizeof(t_mensaje_TRUNCATE));
	int offset = 0, tmp_len = 0;

	memcpy(&msjTRUNCATE->fileLen, empaquetado + offset, tmp_len = sizeof(msjTRUNCATE->fileLen));
	offset += tmp_len;
	memcpy(&msjTRUNCATE->newLen, empaquetado + offset, tmp_len = sizeof(msjTRUNCATE->newLen));
	offset += tmp_len;
	msjTRUNCATE->filename = malloc(msjTRUNCATE->fileLen);
	memcpy(msjTRUNCATE->filename, empaquetado + offset, tmp_len = msjTRUNCATE->fileLen);

	return msjTRUNCATE;
}

char* empaquetarTRUNCATE(t_mensaje_TRUNCATE* mensaje, int* largo){
	char *empaquetado = malloc(sizeof(mensaje->fileLen) + sizeof(mensaje->newLen) + mensaje->fileLen);

	int offset = 0, tmp_size = 0;
	memcpy(empaquetado + offset, &mensaje->fileLen, tmp_size = sizeof(mensaje->fileLen));
	offset = tmp_size;
	memcpy(empaquetado + offset, &mensaje->newLen, tmp_size = sizeof(mensaje->newLen));
	offset += tmp_size;
	memcpy(empaquetado + offset, mensaje->filename, tmp_size = mensaje->fileLen);
	offset += tmp_size;

	*largo = offset;
	return empaquetado;
}
