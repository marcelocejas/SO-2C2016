#ifndef LIBRERIAS_SF_TIPOSDATO_H_
#define LIBRERIAS_SF_TIPOSDATO_H_
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

typedef enum {
	READDIR,
	GETATTR,
	READFILE,
	WRITE,
	CREATE,
	MKDIR,
	ERROR,
	RENAME,
	UNLINK,
	TRUNCATE
} filesystem_t;

typedef enum {
	INICIARJUEGO,
	ACEPTARSOLICITUD,
	PEDIRPOKENEST,
	ENVIARLOCALIZACIONPOKENEST,
	AVANZARUNAPOSICION,
	MOVIMIENTOREALIZADO,
	MOVERENX,
	MOVERENY,
	CAPTURAREALIZADA,
	DEADLOCK,
	ATRAPARPOKEMON,
	INSTRUCCION,
	FINDEQUANTUM,
	OKEY,
	FINALIZAR,
	ESPERAR,
	MEJORENTRENADOR,
	PERDISTE
//
} instruccion_t;

typedef enum {
	LISTO,
	LIBRE,
	EJECUTANDO,
	BLOQUEADO,
	AFINALIZAR,
	INVALIDO,
	ERRORINICIO,
	FINALIZADO
	} estado_t;

typedef struct{
	int unsigned tipoMensaje;
	int unsigned logitudMensaje;
}__attribute__((__packed__)) t_msjCabecera;

typedef struct mensaje_MAPA_ENTRENADOR_t {
	instruccion_t protocolo;
	uint32_t parametro;
	int valor;
	int valor2;
	int quantum;
	int algoritmo;
	uint32_t tamanoMensaje;
	char*texto;
} mensaje_MAPA_ENTRENADOR;

#endif /* LIBRERIAS_SF_TIPOSDATO_H_ */
