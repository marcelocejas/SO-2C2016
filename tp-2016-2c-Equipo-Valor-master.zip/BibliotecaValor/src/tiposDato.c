/*
 * tiposDato.c

 *
 *  Created on: 21/9/2015
 *      Author: utnso
 */
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include "tiposDato.h"
char * mostrarProtocolos(instruccion_t instruccion) {
	switch (instruccion) {
	case ATRAPARPOKEMON:
		return "ATRAPARPOKEMON";
		break;
	case INICIARJUEGO:
		return "INICIARJUEGO";
		break;
	case PEDIRPOKENEST:
		return "PEDIRPOKENEST";
		break;

	case INSTRUCCION:
		return "INSTRUCCION";
		break;

	default:
		return "SARAZA";
		break;
	}
}
