/*
 * Log.c
 *
 *  Created on: 10/10/2016
 *      Author: utnso
 */


#include "Log.h"


t_log* crearLog(char* logpath, char* proceso) {
	log = NULL;
	mkstemp(logpath);
	log = log_create(logpath,proceso,false,LOG_LEVEL_INFO);
	return log;
}

t_log* crearLogError(char* logpath, char* proceso) {
	logError = NULL;
	mkstemp(logpath);
	logError = log_create(logpath,proceso,false,LOG_LEVEL_ERROR);
	return log;
}

t_log* crearLogDebug(char* logpath, char* proceso) {
	logDebug = NULL;
	mkstemp(logpath);
	logDebug = log_create(logpath,proceso,false,LOG_LEVEL_DEBUG);
	return log;
}

t_log* crearLogTrace(char* logpath, char* proceso) {
	logTrace = NULL;
	mkstemp(logpath);
	logTrace = log_create(logpath,proceso,false,LOG_LEVEL_TRACE);
	return log;
}

t_log* crearLogWarning(char* logpath, char* proceso) {
	logWarning = NULL;
	mkstemp(logpath);
	logWarning = log_create(logpath,proceso,false,LOG_LEVEL_WARNING);
	return log;
}
