/*
 * PokeDexCliente.h
 *
 *  Created on: 29/8/2016
 *      Author: Marcelo Cejas
 */

#ifndef POKEDEXCLIENTE_H_
#define POKEDEXCLIENTE_H_

#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <fuse.h>
#include <commons/config.h>
#include <commons/string.h>
#include <commons/collections/list.h>
#include <src/sw_sockets.h>
#include <src/tiposDato.h>
#include <src/mensajesPokeDex.h>
#include "Configuracion.h"
#include "Log.h"

int socketServer;
#endif /* POKEDEXCLIENTE_H_ */
