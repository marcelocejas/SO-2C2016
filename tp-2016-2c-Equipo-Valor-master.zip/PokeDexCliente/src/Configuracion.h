/*
 * Configuracion.h
 *
 *  Created on: 29/8/2016
 *      Author: candelaria
 */

#ifndef CONFIGURACION_H_
#define CONFIGURACION_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <commons/config.h>

#define CANTIDAD_PARAMETROS_CONFIG  3

typedef struct configInfo {
	int puerto;
	char* ip_server;
	int puerto_server;
} t_config_cliente;


int cargarConfiguracion(t_config_cliente*);
void finalizarConfig(void);

#endif /* CONFIGURACION_H_ */
