/*
 * Loh.h
 *
 *  Created on: 10/10/2016
 *      Author: utnso
 */

#ifndef SRC_LOG_H_
#define SRC_LOG_H_
#include <stdio.h>
#include <stdlib.h>
#include <commons/log.h>

t_log* log;
t_log* logError;
t_log* logDebug;
t_log* logTrace;
t_log* logWarning;

t_log* crearLog(char* , char* );
t_log* crearLogWarning(char* logpath, char* proceso);
t_log* crearLogTrace(char* logpath, char* proceso);
t_log* crearLogDebug(char* logpath, char* proceso);
t_log* crearLogError(char* logpath, char* proceso);

#endif /* SRC_LOG_H_ */
