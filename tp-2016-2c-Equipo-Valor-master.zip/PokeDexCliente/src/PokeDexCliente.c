/*
 ============================================================================
 Name        : PokeDexCliente.c
 Author      : Marcelo
 Version     :
 Copyright   : Your copyright notice
 Description : Cliente de Poke Dex
 ============================================================================
 */

#include "PokeDexCliente.h"

t_config_cliente* config;
t_msjCabecera* cabeceraMsj;

static int ev_getattr(const char *path, struct stat *stbuf) {
	log_info(log, "GETATTR --> path: %s", path);
	int res = 0;
	memset(stbuf, 0, sizeof(struct stat));
	t_mensaje_GETATTR* msjGetAttr = malloc(sizeof(t_mensaje_GETATTR));
	cabeceraMsj = malloc(sizeof(t_msjCabecera));

	cabeceraMsj->tipoMensaje = GETATTR;
	cabeceraMsj->logitudMensaje = strlen(path);

//	log_info(log, "socket:%d Patch:%s tipo:%d Longitud: %d.", socketServer, path, cabeceraMsj->tipoMensaje, cabeceraMsj->logitudMensaje);

	if (strcmp(path, "/") == 0) {
		stbuf->st_mode = S_IFDIR | 0755;
		stbuf->st_nlink = 2;
	} else {

		if (enviarMsjConEncabezado(socketServer, (char*) path, cabeceraMsj)	== -1) {
			res = -ENOENT;
		}
		char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);
		msjGetAttr = desempaquetarGETATTR(mensajeRecibido);

		log_info(log, "modo %d, tipo: %d, tamanio: %d.\n, time: %d", msjGetAttr->mode, msjGetAttr->nLink, msjGetAttr->size, msjGetAttr->lastMod);
		//stbuf lleva los atributos del archivo.
		if (msjGetAttr != NULL) {
			stbuf->st_nlink = msjGetAttr->nLink;
			stbuf->st_size = msjGetAttr->size;
			time_t current_time = msjGetAttr->lastMod;
			stbuf->st_mtim.tv_sec = current_time;
			if (msjGetAttr->nLink == 1) {
				stbuf->st_mode = S_IFREG | 0755; //archivo --1
			} else {
				if (msjGetAttr->nLink == 2) {
					stbuf->st_mode = S_IFDIR | 0755; //Directorio --2
				} else {
					res = -ENOENT;
				}
			}

		} else {
			res = -ENOENT;
		}
	}

	return res;
}

static int ev_readdir(const char *path, void *buf, fuse_fill_dir_t filler,	off_t offset, struct fuse_file_info *fi) {
	//log_info(log, "readdir");
	int res = 0;
	int i;
	t_list* files = list_create();
	t_directorioList* fileAux = malloc(sizeof(t_directorioList));

	cabeceraMsj->tipoMensaje = READDIR;
	cabeceraMsj->logitudMensaje = strlen(path);

	if (enviarMsjConEncabezado(socketServer, (char*) path, cabeceraMsj) != -1) {
		char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);
		if (mensajeRecibido != NULL) {
			files = desempaquetarDirectorio(mensajeRecibido);

			if (files != NULL) {
				for (i = 0; i < list_size(files); i++) {
					fileAux = list_get(files, i);
					filler(buf, (char*) fileAux->file, NULL, 0);
					//log_info(log, "orden: %d, nombre: %s, longitud de la lista:%d", i, fileAux->file, list_size(files));
				}

			} else {
				res = -ENOENT;
			}
		} else {
			res = -ENOENT;
		}
	} else {
		res = -ENOENT;
	}
	return res;
}

static int ev_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi) {
	//log_info(log, "read");
	cabeceraMsj->tipoMensaje = READFILE;
	cabeceraMsj->logitudMensaje = strlen(path);

	if (enviarMsjConEncabezado(socketServer, (char*) path, cabeceraMsj) != -1) {
		char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);

		if (mensajeRecibido != NULL) {
			memcpy(buf,((char*)mensajeRecibido) + offset,size);
		}else{
			log_error(log, "No se pudo leer el archivo%s", path);
		}
	}

	return size;
}

//ssize_t write (int filedes, const void *buffer, size_t size)
static int ev_write (const char *path, void *buf, size_t size, off_t offset, struct fuse_file_info *fi) {
	int escrito = 0;
	if(!string_ends_with((char*)path, "swx") && !string_ends_with((char*)path, "swp") && !string_is_empty((char*)path)){
		t_mensaje_WRITE* msjWrite = malloc(sizeof(t_mensaje_WRITE));
		char* paquete;
		int* largoPaquete = malloc(sizeof(largoPaquete));

		msjWrite->pathLen = strlen(path);
		msjWrite->size = size;
		msjWrite->path = malloc(strlen(path));
		msjWrite->path = (char*) path;
		msjWrite->buffer = malloc(size);
		msjWrite->buffer = buf;

		paquete = empaquetarWRITE(msjWrite, largoPaquete);

		cabeceraMsj->tipoMensaje = WRITE;
		cabeceraMsj->logitudMensaje = *largoPaquete;

		if (enviarMsjConEncabezado(socketServer, (char*) paquete, cabeceraMsj) != -1) {
			char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);

			if (mensajeRecibido != NULL) {
				memcpy(&escrito, mensajeRecibido, sizeof(escrito));
				log_info(log,"WRITE --> filedes:%d, buffer: %s, size: %d, msjRecibido: %s",path, buf, escrito, mensajeRecibido);
			} else {
				log_error(log, "No se pudo escribir el archivo");
			}
		}
		free(msjWrite);
	}
	return escrito;
}

static int ev_truncate (const char *filename, off_t length){
	int res = 0;
	int resultado;

	log_info(log, "TRUNCATE --> filename: %s, length", filename, length);

	if(!string_ends_with((char*)filename, "swx") && !string_ends_with((char*)filename, "swp") && !string_is_empty((char*)filename)){
		t_mensaje_TRUNCATE* msjTRUNCATE = malloc(sizeof(t_mensaje_TRUNCATE));
		char* paquete;
		int* largoPaquete = malloc(sizeof(largoPaquete));

		msjTRUNCATE->fileLen = strlen(filename);
		msjTRUNCATE->newLen = length;
		msjTRUNCATE->filename = malloc(strlen(filename));
		msjTRUNCATE->filename = (char*) filename;

		paquete = empaquetarTRUNCATE(msjTRUNCATE, largoPaquete);

		cabeceraMsj->tipoMensaje = TRUNCATE;
		cabeceraMsj->logitudMensaje = *largoPaquete;

		if (enviarMsjConEncabezado(socketServer, (char*) paquete, cabeceraMsj) != -1) {
			char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);

			if (mensajeRecibido != NULL) {
				memcpy(&resultado, mensajeRecibido, sizeof(resultado));
				if(resultado== EXIT_FAILURE){
					res = -1;
					log_error(log, "No se pudo truncar el archivo %s", filename);
				}
				log_info(log,"WRITE --> filename:%s, length: %d,",filename, length);
			} else {
				log_error(log, "No se pudo truncar el archivo %s", filename);
				res = -1;
			}
		}
		free(msjTRUNCATE);
	}

	return res;
}

static int ev_create (const char* path, mode_t mode, struct fuse_file_info * fi) {
	log_info(log, "CREATE --> path: %s, mode: %d", path, mode);
	int res = 0;
	if(!string_ends_with((char*)path, "swx") && !string_ends_with((char*)path, "swp") && !string_is_empty((char*)path)){
		cabeceraMsj->tipoMensaje = CREATE;
		cabeceraMsj->logitudMensaje = strlen(path);

		if (enviarMsjConEncabezado(socketServer, (char*) path, cabeceraMsj) != -1) {
			char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);

			if (mensajeRecibido != NULL) {
				log_info(log, "Se creo el archivo %s", path);
			} else {
				log_error(logError, "No se pudo crear %s", path);
				res = -ENOENT;
			}
		}
	} else {
		log_error(logError, "No crea el archivo %s", path);
		res = -ENOENT;
	}

	return res;
}

static int ev_mkdir(const char *newdir,mode_t mode) {
	int res=EXIT_SUCCESS;

	cabeceraMsj->tipoMensaje = MKDIR;
	cabeceraMsj->logitudMensaje = strlen(newdir)+1;
	string_append(&newdir, "\0");
	log_info(log,"newdir");
	log_info(log,newdir);
	if (enviarMsjConEncabezado(socketServer, (char*) newdir, cabeceraMsj) != -1) {
		char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);
		log_info(log,"mensajeRecibido");
		log_info(log,mensajeRecibido);

		if (mensajeRecibido != NULL) {
			if(string_equals_ignore_case(mensajeRecibido, "NOT_OK")){
				res=EXIT_FAILURE;
			}
		}else{
			log_error(logError, "No se pudo crear el directorio");
			res = -ENOENT;
		}
	}

	return res;
}

static int ev_rename (const char *oldname, const char *newname){
	int res = 0;
	log_info(log, "RENAME --> oldaname: %s - newname: %s.", oldname, newname);

	t_mensaje_RENAME* msjRename = malloc(sizeof(t_mensaje_RENAME));
	char* paquete;
	int* largoPaquete = malloc(sizeof(largoPaquete));

	msjRename->newnameLen = strlen(newname);
	msjRename->oldnameLen = strlen(oldname);
	msjRename->newname = malloc(strlen(newname) + 1);
	msjRename->oldname = malloc(strlen(oldname) + 1);
	msjRename->newname = (char*)newname;
	msjRename->oldname = (char*)oldname;

	paquete = empaquetarRENAME(msjRename, largoPaquete);

	cabeceraMsj->tipoMensaje = RENAME;
	cabeceraMsj->logitudMensaje = *largoPaquete;

	if (enviarMsjConEncabezado(socketServer, (char*) paquete, cabeceraMsj) != -1) {
		char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);

		if (mensajeRecibido != NULL) {
			log_info(log, "Se renombro %s por %s", newname, oldname);
		} else {
			log_error(logError, "No se pudo renombrar %s", oldname);
			res = -1;
		}
	}

	return res;
}

static int ev_unlink (const char *filename){
	int resultado;
	log_info(log, "UNLINK --> filename: %s", filename);

	cabeceraMsj->tipoMensaje = UNLINK;
	cabeceraMsj->logitudMensaje = strlen(filename);

	if (enviarMsjConEncabezado(socketServer, (char*) filename, cabeceraMsj) != -1) {
		char* mensajeRecibido = recibirMsjConEncabezado(socketServer, cabeceraMsj);

		if (mensajeRecibido != NULL) {
			memcpy(&resultado, mensajeRecibido ,sizeof(resultado));
		}else{
			log_error(log, "No se pudo eliminar el archivo %s", filename);
			perror("No se pudo eliminar el archivo");
			return -1;
		}
	}else{
		log_error(log, "No se pudo eliminar el archivo %s", filename);
		perror("No se pudo eliminar el archivo");
		return -1;
	}

	return 0;
}

static struct fuse_operations ev_oper = {
		.getattr = ev_getattr,
		.readdir = ev_readdir,
		.read = ev_read,
		.write = ev_write,
		.mkdir = ev_mkdir,
		.truncate = ev_truncate,
		.create = ev_create,
		.rename = ev_rename,
		.unlink = ev_unlink,
};

int main(int argc, char *argv[]) {

	crearLog("PokeDexCliente.log", "PokeDexCliente");
	crearLogError("PokeDexCliente.log", "PokeDexCliente");
	crearLogDebug("PokeDexCliente.log", "PokeDexCliente");

	config = malloc(sizeof(t_config_cliente));
	if (cargarConfiguracion(config) == 1) {
		return EXIT_FAILURE;
	}
	socketServer = conectarConServer(config->ip_server, config->puerto_server);
	log_info(log, "Se lanza fuse.");
	return fuse_main(argc, argv, &ev_oper, NULL);
}

