/*
 * Configuracion.c
 *
 *  Created on: 29/8/2016
 *      Author: Candelaria
 */

#include "Configuracion.h"
t_config *tConfig;

int cargarConfiguracion(t_config_cliente* configCliente ) {

	char * variableIP = secure_getenv ("IP_SERVER_POKEDEX");
	char * variablePuerto = secure_getenv ("PUERTO_SERVER_POKEDEX");

	if (variablePuerto!=NULL) {
		configCliente->puerto_server = atoi(variablePuerto);
	} else {
		printf("ERROR: Falta la variable de entorno: %s. \n", "PUERTO_SERVER_POKEDEX");
		return EXIT_FAILURE;
	}
	if (variableIP!=NULL) {
		configCliente->ip_server = variableIP;
	} else {
		printf("ERROR: Falta la variable de entorno: %s. \n", "IP_SERVER_POKEDEX");
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}

void finalizarConfig() {
	config_destroy(tConfig);
}
