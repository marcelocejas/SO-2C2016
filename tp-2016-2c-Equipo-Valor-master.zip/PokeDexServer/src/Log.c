/*
 * Log.c
 *
 *  Created on: 10/10/2016
 *      Author: utnso
 */


#include "Log.h"


t_log* crearLog(char* logpath, char* proceso) {
	log = NULL;
	mkstemp(logpath);
	log = log_create(logpath, proceso,false,LOG_LEVEL_TRACE);
	return log;
}

void logDebug(char* logMensaje){
	log_info(log, logMensaje);
}
