/*
 * Configuracion.c
 *
 *  Created on: 29/8/2016
 *      Author: Candelaria
 */


#include "Configuracion.h"
t_config *tConfig;

int cargarConfig(char* archivoRuta, t_config_server* configCliente ) {

	// Genero tabla de tConfig
	tConfig = config_create(archivoRuta);
	if (tConfig == NULL) {
		printf("ERROR: no se encuentra o falta el archivo de tConfig en la direccion \t%s \n", archivoRuta);

		return EXIT_FAILURE;
	}

	// Verifico que el archivo de tConfig tenga la cantidad de parametros correcta.
	if (config_keys_amount(tConfig) == CANTIDAD_PARAMETROS_CONFIG) {
		// Verifico que los parametros tengan sus valores OK
		// Verifico parametro PUERTO

		if (config_has_property(tConfig, "PUERTO_SERVER")) {
			configCliente->puerto = config_get_int_value(tConfig, "PUERTO_SERVER");
		} else {
			printf("ERROR: Falta el parametro: %s. \n", "PUERTO_SERVER");
			return EXIT_FAILURE;
		}
	} else {
		printf("ERROR: El archivo SERVER.cfg no tiene los %d campos que debería.\n", CANTIDAD_PARAMETROS_CONFIG);
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}

void finalizarConfig() {
	config_destroy(tConfig);
}
