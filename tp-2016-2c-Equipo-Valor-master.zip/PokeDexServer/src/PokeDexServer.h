/*
 * PokeDexServer.h
 *
 *  Created on: 29/8/2016
 *      Author: Emanuel y Marce
 */

#ifndef POKEDEXSERVER_H_
#define POKEDEXSERVER_H_

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <commons/config.h>
#include <commons/log.h>
#include <src/sw_sockets.h>
#include <src/mensajesPokeDex.h>
#include "Configuracion.h"
#include "osada.h"

t_config_server* config;

typedef struct PD_Cliente_t{
	uint32_t socketCliente;
	uint32_t hiloCliente;
} t_PD_Cliente;

void manejarConexionesRecibidas(void);
void manejarConexionCliente(void);
void manejarPeticionesCliente(t_PD_Cliente*);
char* obtenerUltimoDirPath(char* path, int len);

#endif /* POKEDEXSERVER_H_ */
