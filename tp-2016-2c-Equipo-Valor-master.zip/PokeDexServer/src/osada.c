/*
 * osada.c
 *
 *  Created on: 29/8/2016
 *      Author: Emanuel y Marce
 */

#include "osada.h"

struct stat fs_stat;
int fd_filesystem;
int* pmap_fs;
osada_header* header_file;
t_bitarray* bitmap;
t_bitarray* bitArray;
osada_file* tabla_archivo;
osada_block_pointer* tabla_de_asignaciones;
char* tabla_de_datos;

unsigned int redondeando(unsigned int dividendo, unsigned int divisor) {
	return (dividendo + (divisor / 2)) / divisor;
}

char* stringFromOsadaFileState(osada_file_state f) {
	char *strings[] =
			{ "DELETED", "REGULAR", "DIRECTORY", /* continue for rest of values */};

	return strings[f];
}

int* mapearDisco(char* fspath) {
	pmap_fs = NULL;

	if ((fd_filesystem = open(fspath, O_RDWR)) == -1) {
		perror("open");
		return pmap_fs;
	};

	if ((fstat(fd_filesystem, &fs_stat)) == -1) {
		perror("stat");
		return pmap_fs;
	};

	pmap_fs = mmap(0, fs_stat.st_size, PROT_READ | PROT_WRITE, MAP_SHARED,
			fd_filesystem, 0);

	if (pmap_fs == NULL) {
		perror("mmap");
		return pmap_fs;
	}

	return pmap_fs;
}

void imprimirHeader(osada_header* header_file) {

	unsigned char fsNombre[8];
	memset(fsNombre, '\0', sizeof(unsigned char) * 8);

	memcpy(fsNombre, header_file->magic_number, sizeof(unsigned char) * 7);

	printf(
			"Header:\nIdentificador: %s\nVersion: %d\nTamanio del FS: %d\nTamanio del bitmap: %d\nInicio Tabla Asignaciones: %d\nTamanio Datos: %d.\n",
			fsNombre, header_file->version, header_file->fs_blocks,
			header_file->bitmap_blocks, header_file->allocations_table_offset,
			header_file->data_blocks);

}

void imprimirTablaArchivos(osada_file * tablaArchivos) {
	int i;
	for (i = 0; i < 2048; i++) {
		if (tablaArchivos[i].state != 0) {
			printf("indice: %d\n", i);
			printf("Estado: %s\n",
					stringFromOsadaFileState(tablaArchivos[i].state));
			printf("Nombre de archivo: %s\n", tablaArchivos[i].fname);
			printf("Bloque padre: %d\n", tablaArchivos[i].parent_directory);
			printf("Tamanio del archivo: %d\n", tablaArchivos[i].file_size);
			printf("Fecha ultima modificacion: %d\n", tablaArchivos[i].lastmod);
			printf("Bloque inicial: %d\n", tablaArchivos[i].first_block);
		}
	}
}

void imprimirBitmap(t_bitarray * bitArray) {
	printf("Bitmap contiene:\n");
	int i, j, k, m, value, cantOcupados;
	j = -1;
	k = -1;
	m = -1;
	cantOcupados = 0;

	for (i = 0; i < bitarray_get_max_bit(bitArray); i++) {
		value = bitarray_test_bit(bitArray, i);
		if (value) {
			cantOcupados++;
		}

		j++;
		if (j == 7) {
			k++;
			if (k == 3) {
				m++;
				if (m == 1) {
					printf("%d\n", value);
					m = -1;
				} else {
					printf("%d  ", value);
				}

				k = -1;
			} else {
				printf("%d ", value);
			}

			j = -1;

		} else {

			printf("%d", value);
		}
	}

	printf("\n");
	printf("%d used blocks - %d free\n", cantOcupados,
			bitarray_get_max_bit(bitArray) - cantOcupados);
}

osada_header* leerHeader() {
	osada_header *header_file;

	if (pmap_fs == NULL) {
		perror("pMap");
		return NULL;
	}

	header_file = (osada_header*) pmap_fs;

	HEADER_FILE = header_file;

	return header_file;
}

t_bitarray* leerBitArray() {
	t_bitarray* bitArray;

	bitArray = (t_bitarray*) pmap_fs + sizeof(osada_header);

	return bitArray;
}

osada_file* leerInicioTablaArchivo() {
	int tamanio_bitmap;
	// Tamaño BITMAP: Tamaño del FS [bloques] / 8 / BLOCK_SIZE
	header_file = leerHeader();

	tamanio_bitmap = (header_file->fs_blocks) / 8; //calculamos el tamaño del Bitmap en bytes

	tabla_archivo = (osada_file*) ((char*) header_file + tamanio_bitmap
			+ sizeof(osada_header)); //apuntamos al inicio de la tabla de archivos

	INICIO_TABLA_DE_ARCHIVOS = tabla_archivo;

	return tabla_archivo;
}

t_list* cargarListaTablaArchivo() {
	t_list *lista_archivos;
	osada_file *elemento;

	lista_archivos = list_create();
	tabla_archivo = leerInicioTablaArchivo();

	int i;
	for (i = 0; i < OSADA_TABLA_ARCHIVO_LENGTH; i++) {

		elemento = (osada_file*) (tabla_archivo) + i;
		list_add(lista_archivos, elemento);

	}

	return lista_archivos;
}

t_list* existeArchivo(char* ruta) {
	t_list *lista_archivos; //TODO: destroy listas
	t_list *listar_ruta;
	osada_file *archivo_actual;
	uint16_t archivo_padre;
	char** array_ruta;

	archivo_actual = malloc(sizeof(osada_file));

	archivo_padre = OSADA_RAIZ;

	array_ruta = malloc(sizeof(char*));
	array_ruta[0] = NULL;
	if (!string_equals_ignore_case(ruta, "/")) {

		array_ruta = string_split(ruta, "/"); //Me pidió listar un dir o file. Si no entra me pide listar el raiz.
	}

	lista_archivos = cargarListaTablaArchivo();

	int i = 0;
	while (array_ruta[i] != NULL) {

		osada_file* _soy_el_archivo_buscado(osada_file* p) {
			return string_equals_ignore_case(p->fname, array_ruta[i])
					&& p->parent_directory == archivo_padre;
		}

		archivo_actual = list_find(lista_archivos,
				(void*) _soy_el_archivo_buscado);

		if (archivo_actual != 0) {

			int k;
			for (k = 0; k < list_size(lista_archivos); k++) {

				osada_file* archivo_auxiliar;
				archivo_auxiliar = list_get(lista_archivos, k);

				if ((archivo_auxiliar->parent_directory
						== archivo_actual->parent_directory)
						&& (string_equals_ignore_case(archivo_auxiliar->fname,
								archivo_actual->fname))) {
					archivo_padre = k;
					break;
				}
			}

			i = i + 1;

		} else {
			perror(
					"No se puede acceder: No existe el archivo o el directorio.\n");
			return NULL;
		}
	} //final del proceso. En archivo_actual voy a tener el dir o file que quiero listar

	listar_ruta = list_create();

	if (((archivo_actual->state == 2) && (archivo_actual->state != 0))
			|| (archivo_padre == OSADA_RAIZ)) { //consulto en el archivo que quiero listar si es dir o file

		osada_file* _soy_el_archivo_padre(osada_file* p) {
			return p->parent_directory == archivo_padre && p->state != DELETED;
		}

		listar_ruta = list_filter(lista_archivos,
				(void*) _soy_el_archivo_padre);

		if (array_ruta != NULL) {
			free(array_ruta);
		}
		list_destroy(lista_archivos);
		return listar_ruta;
	} else {

		if ((archivo_actual->state == 1) && (archivo_actual->state != 0)) {
			printf("%s\n", archivo_actual->fname);
			list_add(listar_ruta, archivo_actual);

			if (array_ruta != NULL) {
				free(array_ruta);
			}
			list_destroy(lista_archivos);
			return listar_ruta;
		} else {
			perror(
					"No se puede acceder: No existe el archivo o el directorio.\n");

			if (array_ruta != NULL) {
				free(array_ruta);
			}
			list_destroy(lista_archivos);
			list_destroy(listar_ruta);

			return NULL;

		}

	}

}

void listarDirectorio(char* ruta) {
	t_list *listar_ruta;
	osada_file *archivo;
	int j = 0;

	listar_ruta = existeArchivo(ruta);

	for (j = 0; j < list_size(listar_ruta); j++) { //hago un for para imprimir los directorios.
		archivo = list_get(listar_ruta, j);
		printf("%s\n", (char*) archivo->fname);
	}

	if (listar_ruta != NULL) {
		list_destroy(listar_ruta);
	}
}

osada_block_pointer* buscarProximoBloque(osada_block_pointer posicion_bloque) {
	//int tamanio_bitmap;
	osada_block_pointer *elemento;
	//osada_block_pointer *tabla_asignaciones;

	/*header_file = leerHeader();

	 tamanio_bitmap = (header_file->fs_blocks) / 8; //calculamos el tamaño del Bitmap en bytes

	 tabla_asignaciones = (osada_block_pointer*) ((char*) header_file
	 + tamanio_bitmap + sizeof(osada_header)
	 + (OSADA_TABLA_ARCHIVO_LENGTH * (sizeof(osada_file)))); //apuntamos al inicio de la tabla de asignaciones*/

	elemento = TABLA_DE_ASIGNACIONES + posicion_bloque;

	return elemento;
}

osada_block_pointer* inicioTablaAsignaciones(osada_header* header_file) {
	int tamanio_bitmap;
	osada_block_pointer *tabla_asignaciones;

	tamanio_bitmap = (header_file->fs_blocks) / 8; //calculamos el tamaño del Bitmap en bytes

	tabla_asignaciones = (osada_block_pointer*) ((char*) header_file
			+ tamanio_bitmap + sizeof(osada_header)
			+ (OSADA_TABLA_ARCHIVO_LENGTH * (sizeof(osada_file)))); //apuntamos al inicio de la tabla de asignaciones

	TABLA_DE_ASIGNACIONES = tabla_asignaciones;

	return tabla_asignaciones;
}

char* inicioTablaDatos(osada_header* header_file) {
	int tamanio_tabla_asignaciones;
	int tamanio_bitmap;
	int dividendo;
	osada_block_pointer *tabla_asignaciones;
	char* tabla_datos;

	tamanio_bitmap = (header_file->fs_blocks) / 8; //calculamos el tamaño del Bitmap en bytes

	tabla_asignaciones = (osada_block_pointer*) ((char*) header_file
			+ tamanio_bitmap + sizeof(osada_header)
			+ (OSADA_TABLA_ARCHIVO_LENGTH * (sizeof(osada_file)))); //apuntamos al inicio de la tabla de asignaciones

	tamanio_bitmap = redondeando(tamanio_bitmap, OSADA_BLOCK_SIZE); //calculamos el tamaño del Bitmap en bloques

	dividendo = (((header_file->fs_blocks) - 1 - tamanio_bitmap - 1024) * 4);
	tamanio_tabla_asignaciones = redondeando(dividendo,
			sizeof(osada_block_pointer)); //calculamos el tamanio de la tabla de asignaciones en bloques

	tabla_datos = (char*) (tabla_asignaciones + tamanio_tabla_asignaciones + 1); //apuntamos al inicio de la tabla de datos

	TABLA_DE_DATOS = tabla_datos;

	return tabla_datos;
}

char* buscarBloqueDatos(osada_block_pointer posicion_bloque) {
	int tamanio_tabla_asignaciones;
	int tamanio_bitmap;
	int dividendo;
	char* elemento;
	osada_block_pointer *tabla_asignaciones;
	char* tabla_datos;

	header_file = leerHeader();

	tamanio_bitmap = (header_file->fs_blocks) / 8; //calculamos el tamaño del Bitmap en bytes

	tabla_asignaciones = (osada_block_pointer*) ((char*) header_file
			+ tamanio_bitmap + sizeof(osada_header)
			+ (OSADA_TABLA_ARCHIVO_LENGTH * (sizeof(osada_file)))); //apuntamos al inicio de la tabla de asignaciones

	tamanio_bitmap = redondeando(tamanio_bitmap, OSADA_BLOCK_SIZE); //calculamos el tamaño del Bitmap en bloques

	dividendo = (((header_file->fs_blocks) - 1 - tamanio_bitmap - 1024) * 4);
	tamanio_tabla_asignaciones = redondeando(dividendo,
			sizeof(osada_block_pointer)); //calculamos el tamanio de la tabla de asignaciones en bloques

	tabla_datos = (char*) (tabla_asignaciones + tamanio_tabla_asignaciones + 1); //apuntamos al inicio de la tabla de datos

	elemento = tabla_datos + (posicion_bloque * OSADA_BLOCK_SIZE);

	return elemento;
}

char* leerArchivo(char* ruta, int* largoArchivo) {
	t_list *existArchivo;
	osada_file *archivo;
	char* datos_archivo;
	char* bloque_datos;
	osada_block_pointer posicion_bloque;
	osada_block_pointer *proximo_bloque;
	int cantidad_bloques = 0;
	int cantidad_a_copiar = 0;
	int offset = 0;

	existArchivo = existeArchivo(ruta); //chequeo si existe el archivo que quiero leer
	if (existArchivo == NULL) {
		perror("No se puede acceder: No existe el archivo.\n");
		return NULL;
	}

	archivo = list_get(existArchivo, 0); //como devuelvo una lista de archivos que contiene un solo archivo me lo guardo en dicha variable

	if (archivo->state == 2 || archivo->state == 0) {
		perror("No se puede acceder: No se reconoce el archivo o no existe.\n");
		return NULL;
	}

	bloque_datos = malloc(OSADA_BLOCK_SIZE);
	datos_archivo = malloc(OSADA_BLOCK_SIZE);

	posicion_bloque = archivo->first_block;

	if (posicion_bloque == 0xFFFFFFFF || posicion_bloque == -1) {
		*largoArchivo = offset * OSADA_BLOCK_SIZE;
		printf("El archivo está vacío.\n");
		perror("El archivo está vacío.\n");
		return datos_archivo;
	}

	while (posicion_bloque != 0xFFFFFFFF) {

		datos_archivo = realloc(datos_archivo, OSADA_BLOCK_SIZE * (offset + 1));
		bloque_datos = buscarBloqueDatos(posicion_bloque);

		proximo_bloque = buscarProximoBloque(posicion_bloque);
		posicion_bloque = *proximo_bloque;

		if ((archivo->file_size - (cantidad_bloques * OSADA_BLOCK_SIZE))
				>= OSADA_BLOCK_SIZE) {
			cantidad_a_copiar = OSADA_BLOCK_SIZE;
		} else {
			cantidad_a_copiar = archivo->file_size
					- (cantidad_bloques * OSADA_BLOCK_SIZE);
		}

		memcpy(datos_archivo + (offset * OSADA_BLOCK_SIZE), bloque_datos,
				cantidad_a_copiar);

		cantidad_bloques++;
		offset++;

	}
	*largoArchivo = offset * OSADA_BLOCK_SIZE;
	//free(bloque_datos);

	/*
	 //grabo de manera temporal para ver si leemos bien los archivos

	 FILE * pFile;
	 pFile = fopen("/home/utnso/git/osada-utils/pruebas/basic-archivo.txt",
	 "wb");
	 fwrite(datos_archivo, sizeof(char), cantidad_bloques * OSADA_BLOCK_SIZE,
	 pFile);
	 fclose(pFile);
	 */

	return datos_archivo;
}

osada_file* getAtributos(char* ruta) {
	t_list *lista_archivos;
	osada_file *archivo_actual = malloc(sizeof(osada_file));
	uint16_t archivo_padre;
	char** array_ruta;

	archivo_padre = OSADA_RAIZ;

	array_ruta = malloc(sizeof(char*));
	array_ruta[0] = NULL;

	if (!string_equals_ignore_case(ruta, "/")) {
		array_ruta = string_split(ruta, "/"); //Me pidió listar un dir o file. Si no entra me pide listar el raiz.
	}

	lista_archivos = cargarListaTablaArchivo();

	int i = 0;
	while (array_ruta[i] != NULL) {

		osada_file* _soy_el_archivo_buscado(osada_file* p) {
			return string_equals_ignore_case(p->fname, array_ruta[i])
					&& p->parent_directory == archivo_padre;
		}

		archivo_actual = list_find(lista_archivos,
				(void*) _soy_el_archivo_buscado);

		if (archivo_actual != 0) {

			int k;
			for (k = 0; k < list_size(lista_archivos); k++) {

				osada_file* archivo_auxiliar;
				archivo_auxiliar = list_get(lista_archivos, k);

				if ((archivo_auxiliar->parent_directory
						== archivo_actual->parent_directory)
						&& (string_equals_ignore_case(
								(char*) archivo_auxiliar->fname,
								(char*) archivo_actual->fname))) {
					archivo_padre = k;
					break;
				}
				//free(archivo_auxiliar);
			}

			i = i + 1;

		} else {
			perror(
					"No se puede acceder: No existe el archivo o el directorio.\n");
			free(archivo_actual);
			return NULL;
		}
	}

	free(array_ruta);
	list_destroy(lista_archivos);

	return archivo_actual;
}

uint32_t** buscarBloquesLibres(int file_size_blocks) {
	int i, value, cantBloques;
	uint32_t** bloques_libres;
	uint32_t nroBloque;
	cantBloques = 0;
	nroBloque = -1;

	bloques_libres = malloc(sizeof(uint32_t*));

	for (i = 0; i < bitarray_get_max_bit(BITMAP); i++) {
		value = bitarray_test_bit(BITMAP, i);
		nroBloque++;
		if (value == 0) {
			bloques_libres[cantBloques] = malloc(sizeof(uint32_t));
			*(bloques_libres[cantBloques]) = nroBloque;
			cantBloques++;
			if (cantBloques >= file_size_blocks) {
				bloques_libres[cantBloques] = malloc(sizeof(uint32_t));
				*(bloques_libres[cantBloques]) = -999; //le pongo ese valor para saber donde termina el array
				break;
			}
		}
	}
	if (cantBloques < file_size_blocks) {
		*(bloques_libres[0]) = -999;
	}
	return bloques_libres;
}

uint32_t** buscarBloquesAsignados(int file_size_blocks,
		osada_block_pointer primer_bloque) {
	int i;
	uint32_t** bloques_asignados;
	osada_block_pointer posicion_bloque;
	osada_block_pointer *proximo_bloque;

	bloques_asignados = malloc(sizeof(uint32_t*));
	bloques_asignados[0] = malloc(sizeof(uint32_t));
	i = 0;

	posicion_bloque = primer_bloque;
	*(bloques_asignados[i]) = posicion_bloque;

	while (posicion_bloque != 0xFFFFFFFF) {
		proximo_bloque = buscarProximoBloque(posicion_bloque);
		posicion_bloque = *proximo_bloque;
		i = i + 1;
		bloques_asignados[i] = malloc(sizeof(uint32_t));
		*(bloques_asignados[i]) = posicion_bloque;
	}
	return bloques_asignados;
}

int existeNombre2(uint16_t posicion_padre, char* fname) {
	t_list *existArchivo;
	osada_file* archivo;
	uint16_t i;
	uint16_t posicion;
	char *padre;

	posicion = EXIT_FAILURE;

	if (posicion_padre == OSADA_RAIZ) {
		padre = "/";
	} else {
		padre = (char*) INICIO_TABLA_DE_ARCHIVOS[posicion_padre].fname;
	}

	existArchivo = existeArchivo(padre); //chequeo si existe el archivo que quiero leer
	if (existArchivo == NULL) {
		return EXIT_FAILURE;
	} else {

		for (i = 0; i < list_size(existArchivo); i++) {

			archivo = list_get(existArchivo, i);

			if (string_equals_ignore_case((char*) fname, (char*) archivo->fname)
					&& (archivo->parent_directory == posicion_padre)) {
				posicion = EXIT_SUCCESS;
				break;
			} else {
				posicion = EXIT_FAILURE;
			}

		}
	}

	return posicion;

}

int existeNombre(uint16_t posicion_padre, char* fname) {
	uint16_t i;
	uint16_t posicion;

	posicion = EXIT_FAILURE;

	for (i = 0; i < OSADA_TABLA_ARCHIVO_LENGTH; i++) {

		if (string_equals_ignore_case((char*) fname,
				(char*) (INICIO_TABLA_DE_ARCHIVOS[i].fname))
				&& (INICIO_TABLA_DE_ARCHIVOS[i].parent_directory
						== posicion_padre)
				&& (INICIO_TABLA_DE_ARCHIVOS[i].state != DELETED)) {
			posicion = EXIT_SUCCESS;
			break;
		} else {
			posicion = EXIT_FAILURE;
		}
	}

	return posicion;

}

int hayNodosDispoibles() {
	int i;
	int retorno;

	for (i = 0; i < 2048; i++) {
		if (INICIO_TABLA_DE_ARCHIVOS[i].state == DELETED) {
			retorno = EXIT_SUCCESS;
			break;
		}
		retorno = EXIT_FAILURE;
	}

	return retorno;
}

uint16_t buscarPosicionTablaArchivos2(char* path) {
	t_list *lista_archivos; //TODO: destroy listas
	osada_file *archivo_actual;
	uint16_t i;
	uint16_t posicion;
	osada_file* archivo;

	archivo = getAtributos(path); //chequeo si existe el archivo o dir que quiero borrar
	if (archivo == NULL) {
		perror(
				"No se puede acceder: No existe el archivo en la Tabla de Archivos.\n");
		return -99;
	}

	lista_archivos = cargarListaTablaArchivo();
	for (i = 0; i < list_size(lista_archivos); i++) {

		archivo_actual = list_get(lista_archivos, i);

		if (string_equals_ignore_case((char*) archivo_actual->fname,
				(char*) archivo->fname)
				&& (archivo_actual->parent_directory
						== archivo->parent_directory)) {
			posicion = i;
			break;
		}

	}

	list_destroy(lista_archivos);
	return posicion;
}

uint16_t buscarPosicionTablaArchivos(char* path) {
	uint16_t i;
	uint16_t posicion;
	osada_file* archivo;

	archivo = getAtributos(path); //chequeo si existe el archivo o dir que quiero borrar
	if (archivo == NULL) {
		perror(
				"No se puede acceder: No existe el archivo en la Tabla de Archivos.\n");
		return -99;
	}

	for (i = 0; i <= (OSADA_TABLA_ARCHIVO_LENGTH - 1); i++) {
		if (string_equals_ignore_case(
				(char*) (INICIO_TABLA_DE_ARCHIVOS[i]).fname,
				(char*) archivo->fname)
				&& (INICIO_TABLA_DE_ARCHIVOS[i].parent_directory
						== archivo->parent_directory)) {
			posicion = i;
			break;
		}
	}
	return posicion;
}

uint16_t buscarBorradoEnTablaArchivo() {
	uint16_t i;
	uint16_t posicion;

	for (i = 0; i <= (OSADA_TABLA_ARCHIVO_LENGTH - 1); i++) {
		if (INICIO_TABLA_DE_ARCHIVOS[i].state == DELETED) {
			posicion = i;
			break;
		}
	}

	return posicion;
}
void reemplazarEnTablaArchivos(osada_file* archivo, uint16_t posicion) {

	*(INICIO_TABLA_DE_ARCHIVOS + posicion) = *archivo;

}

void grabarEnTablaArchivos(osada_file* archivo) {
	uint16_t posicion_archivo;
	posicion_archivo = buscarBorradoEnTablaArchivo();
	reemplazarEnTablaArchivos(archivo, posicion_archivo);
}

void grabarEnTablaAsignaciones(uint32_t** bloques_libres) {
	osada_block_pointer posicion_bloque;
	int i;

	for (i = 0; *(bloques_libres[i]) != -999; i++) {
		posicion_bloque = *(bloques_libres[i]);
		if (*(bloques_libres[i + 1]) != -999) {
			*(TABLA_DE_ASIGNACIONES + posicion_bloque) =
					*(bloques_libres[i + 1]);
		} else {
			*(TABLA_DE_ASIGNACIONES + posicion_bloque) = 0xFFFFFFFF;

		}
	}

}

void setearBitmapOcupados(uint32_t** bloques_libres) {
	int i;

	for (i = 0; *(bloques_libres[i]) != -999; i++) {
		bitarray_set_bit(BITMAP, *(bloques_libres[i]));
	}

}

void cleanBitmap(uint32_t** bloques_asignados) {
	int i;

	for (i = 0; *(bloques_asignados[i]) != 0xFFFFFFFF; i++) {
		bitarray_clean_bit(BITMAP, *(bloques_asignados[i]));
	}

}

void grabarBloque(char* bloque_datos, osada_block_pointer posicion_bloque,
		int cantidad_a_copiar) {

	memcpy(TABLA_DE_DATOS + (posicion_bloque * OSADA_BLOCK_SIZE), bloque_datos,
			cantidad_a_copiar);

}

int grabarDatos2(uint32_t** bloques_libres, char* buffer, int cantidad_bloques,
		long int tamanio) {
	int i;
	int cantidad_a_copiar;
	char* bloque_datos;
	int cantidad_grabada;
	cantidad_grabada = 0;

	bloque_datos = malloc(OSADA_BLOCK_SIZE);

	for (i = 0; *(bloques_libres[i]) != -999; i++) {

		if ((tamanio - (cantidad_bloques * OSADA_BLOCK_SIZE))
				>= OSADA_BLOCK_SIZE) {
			cantidad_a_copiar = OSADA_BLOCK_SIZE;
		} else {
			cantidad_a_copiar = tamanio - (cantidad_bloques * OSADA_BLOCK_SIZE);
		}

		bloque_datos = realloc(bloque_datos, cantidad_a_copiar);

		memcpy(bloque_datos, buffer + (i * OSADA_BLOCK_SIZE),
				cantidad_a_copiar);

		grabarBloque(bloque_datos, *(bloques_libres[i]), cantidad_a_copiar);

		cantidad_grabada = cantidad_grabada + cantidad_a_copiar;

	}
	return cantidad_grabada;
}

int escribirArchivo(char *buffer, char* path, long int tamanio) {
	int file_size_blocks;
	int cantidad_bloques_existentes;
	uint32_t** bloques_libres;
	uint32_t** bloques_asignados;
	uint16_t posicion;
	int cantidad_grabada;

	//chequeo tamaño de archivo
	file_size_blocks = redondeando(tamanio, OSADA_BLOCK_SIZE);

	//chequeo si tengo espacio para grabar
	bloques_libres = buscarBloquesLibres(file_size_blocks);

	posicion = buscarPosicionTablaArchivos(path);

	//chequeo tamaño de archivo existente en bloques
	cantidad_bloques_existentes = redondeando(
			INICIO_TABLA_DE_ARCHIVOS[posicion].file_size,
			OSADA_BLOCK_SIZE);
	if (cantidad_bloques_existentes == 0) {
		if (*(bloques_libres[0]) != -999) {

			INICIO_TABLA_DE_ARCHIVOS[posicion].file_size = tamanio;
			INICIO_TABLA_DE_ARCHIVOS[posicion].first_block =
					*(bloques_libres[0]);
			INICIO_TABLA_DE_ARCHIVOS[posicion].lastmod =
					(uint32_t) temporal_get_string_time();

			grabarEnTablaAsignaciones(bloques_libres);
			setearBitmapOcupados(bloques_libres);
			cantidad_grabada = grabarDatos2(bloques_libres, buffer,
					file_size_blocks, tamanio);

			return cantidad_grabada;
		} else {

			perror(
					"No se puede escribir archivo: No hay espacio para grabar el archivo.\n");
			return EXIT_FAILURE;
		}

	} else {
		//chequeo los bloques que tenia en la tabla de asignaciones
		bloques_asignados = buscarBloquesAsignados(cantidad_bloques_existentes,
				INICIO_TABLA_DE_ARCHIVOS[posicion].first_block);
		cleanBitmap(bloques_asignados);
		if (*(bloques_libres[0]) != -999) {

			INICIO_TABLA_DE_ARCHIVOS[posicion].file_size = tamanio;
			INICIO_TABLA_DE_ARCHIVOS[posicion].first_block =
					*(bloques_libres[0]);
			INICIO_TABLA_DE_ARCHIVOS[posicion].lastmod =
					(uint32_t) temporal_get_string_time();

			grabarEnTablaAsignaciones(bloques_libres);
			setearBitmapOcupados(bloques_libres);
			cantidad_grabada = grabarDatos2(bloques_libres, buffer,
					file_size_blocks, tamanio);

			return cantidad_grabada;
		} else {

			perror(
					"No se puede escribir archivo: No hay espacio para grabar el archivo.\n");
			return EXIT_FAILURE;
		}
	}

}

int truncarArchivo(char* path, long int tamanio) {
	int file_size_blocks;
	int cantidad_bloques_existentes;
	uint32_t** bloques_a_limpiar;
	uint32_t** bloques_nuevos;
	uint32_t** bloques_asignados;
	uint16_t posicion;
	int i;

	bloques_a_limpiar = malloc(sizeof(uint32_t*));
	bloques_a_limpiar[0] = malloc(sizeof(uint32_t));

	bloques_nuevos = malloc(sizeof(uint32_t*));
	bloques_nuevos[0] = malloc(sizeof(uint32_t));

	posicion = buscarPosicionTablaArchivos(path);

	//chequeo tamaño de archivo nuevo
	file_size_blocks = redondeando(tamanio, OSADA_BLOCK_SIZE);

	//chequeo si tengo espacio para grabar si el tamaño es más grande
	if (tamanio > INICIO_TABLA_DE_ARCHIVOS[posicion].file_size) {
		perror(
				"No se puede truncar archivo: Tamaño pasado mayor tamaño archivo.\n");
		return EXIT_FAILURE;

	}

	//chequeo tamaño de archivo existente en bloques
	cantidad_bloques_existentes = redondeando(
			INICIO_TABLA_DE_ARCHIVOS[posicion].file_size,
			OSADA_BLOCK_SIZE);

	//chequeo los bloques que tenia en la tabla de asignaciones
	bloques_asignados = buscarBloquesAsignados(cantidad_bloques_existentes,
			INICIO_TABLA_DE_ARCHIVOS[posicion].first_block);

	INICIO_TABLA_DE_ARCHIVOS[posicion].file_size = tamanio;
	INICIO_TABLA_DE_ARCHIVOS[posicion].lastmod =
			(uint32_t) temporal_get_string_time();

	for (i = 0; i <= file_size_blocks; i++) {

		if (i == file_size_blocks){
			*(bloques_nuevos[i])=-999;
		}else{
			bloques_nuevos[i] = bloques_asignados[i];
		}

	}
	int k = 0;
	for (i = file_size_blocks; *(bloques_asignados[i])!=0xFFFFFFFF; i++) {

		bloques_a_limpiar[k] = bloques_asignados[i];
		if (*(bloques_asignados[i+1])==0xFFFFFFFF){
			bloques_a_limpiar[k+1] = malloc(sizeof(uint32_t));
			*(bloques_a_limpiar[k+1])=0xFFFFFFFF;
		}
		k++;
	}

	grabarEnTablaAsignaciones(bloques_nuevos);
	cleanBitmap(bloques_a_limpiar);

	return EXIT_SUCCESS;

}

int moverArchivo(char* file, char* path) {
	osada_file* archivo;
	uint16_t posicion_padre;
	uint16_t posicion_archivo;

	archivo = getAtributos(file); //chequeo si existe el archivo que quiero mover
	if (archivo == NULL) {
		perror("No se puede mover archivo: No existe el archivo.\n");
		return EXIT_FAILURE;
	}

	posicion_archivo = buscarPosicionTablaArchivos(file);

	if (posicion_archivo == -99) {
		perror(
				"No se puede mover archivo: No existe el archivo en Tabla de Archivos.\n");
		return EXIT_FAILURE;

	}

	//chequeo si existe el dir donde lo quiero mover
	posicion_padre = buscarPosicionTablaArchivos(path);
	if (posicion_padre == -99) {
		perror(
				"No se puede mover archivo: No existe ruta destino en Tabla de Archivos.\n");
		return EXIT_FAILURE;

	}

	if (INICIO_TABLA_DE_ARCHIVOS[posicion_padre].state == DELETED) {
		perror("No se puede mover archivo: No existe ruta destino.\n");
		return EXIT_FAILURE;
	}

	if (existeNombre(posicion_padre, (char*) archivo->fname) == EXIT_FAILURE) {
		archivo->parent_directory = posicion_padre;
		archivo->lastmod = (uint32_t) temporal_get_string_time();
		archivo->state = REGULAR;

		reemplazarEnTablaArchivos(archivo, posicion_archivo);
	} else {
		perror(
				"No se puede mover archivo: Nombre de archivo/carpeta ya existe.\n");
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

int borrarArchivo(char* ruta) {
	int cantidad_bloques;
	uint32_t** bloques_asignados;
	uint16_t posicion;

	posicion = buscarPosicionTablaArchivos(ruta);

	if (posicion == -99) {
		perror(
				"No se puede eliminar: No existe el archivo en Tabla de Archivos.\n");
		return EXIT_FAILURE;

	}

	//chequeo si existe el archivo que quiero borrar
	if (INICIO_TABLA_DE_ARCHIVOS[posicion].state == DELETED) {
		perror("No se puede eliminar: No existe el archivo.\n");
		return EXIT_FAILURE;
	}

	//chequeo tamaño de archivo en bloques
	cantidad_bloques = redondeando(INICIO_TABLA_DE_ARCHIVOS[posicion].file_size,
	OSADA_BLOCK_SIZE);
	if (cantidad_bloques == 0) {
		INICIO_TABLA_DE_ARCHIVOS[posicion].state = DELETED;

	} else {
		//chequeo los bloques que tenia en la tabla de asignaciones
		bloques_asignados = buscarBloquesAsignados(cantidad_bloques,
				INICIO_TABLA_DE_ARCHIVOS[posicion].first_block);

		if (bloques_asignados[0] != NULL) {
			INICIO_TABLA_DE_ARCHIVOS[posicion].state = DELETED;
			cleanBitmap(bloques_asignados);
		} else {
			return EXIT_FAILURE;
		}
	}
	return EXIT_SUCCESS;
}

int renombrarArchivo(char *nombre, char *nuevoNombre) {
	int i = 0;
	char *caracter_nombre;
	int posicion;
	osada_file* archivo;

	nuevoNombre = strrchr(nuevoNombre, '/') + 1;

	archivo = getAtributos(nombre); //chequeo si existe el archivo o dir que quiero renombrar
	if (archivo == NULL) {
		perror("No se puede renombrar: No existe el archivo/carpeta.\n");
		return EXIT_FAILURE;
	}

	posicion = buscarPosicionTablaArchivos(nombre);

	if (posicion == -99) {
		perror(
				"No se puede renombrar: No existe el archivo/carpeta en Tabla de Archivos.\n");
		return EXIT_FAILURE;

	}

	for (i = 0; i < (OSADA_FILENAME_LENGTH - 1); i++) {
		if (i < string_length(nuevoNombre)) {
			caracter_nombre = string_substring(nuevoNombre, i, 1);
			INICIO_TABLA_DE_ARCHIVOS[posicion].fname[i] = *caracter_nombre;
		} else {
			INICIO_TABLA_DE_ARCHIVOS[posicion].fname[i] = '\0';
		}

	}
	return EXIT_SUCCESS;

}

int crearUnArchivo(char* path) {
	int i;
	char *caracter_nombre;
	uint16_t posicion_padre;
	osada_file* archivo_nuevo;
	char* padre;
	char *nombre;

	nombre = strrchr(path, '/') + 1;

	padre = string_substring(path, 0,
			string_length(path) - string_length(nombre));

	if (string_length(nombre) > 17) {
		perror(
				"No se puede crear Archivo: Nombre de archivo mayor a 17 caracteres.\n");

		return EXIT_FAILURE;
	}
	if (hayNodosDispoibles() == EXIT_FAILURE) {
		perror(
				"No se puede crear archivo: No hay nodos disponibles en la tabla de archivos.\n");

		return EXIT_FAILURE;
	}

	archivo_nuevo = malloc(sizeof(osada_file));

	if (!string_equals_ignore_case(padre, "/")) {

		posicion_padre = buscarPosicionTablaArchivos(padre);
		if (posicion_padre == -99) {
			perror(
					"No se puede crear Archivo: No existe ruta destino en Tabla de Archivos.\n");

			return EXIT_FAILURE;

			if (INICIO_TABLA_DE_ARCHIVOS[posicion_padre].state == DELETED) {
				perror("No se puede crear Archivo: No existe ruta destino.\n");

				return EXIT_FAILURE;
			}

		}
	} else {
		posicion_padre = OSADA_RAIZ;
	}

	//chequear si existe un directorio con el mismo nombre en la ruta destino
	if (existeNombre(posicion_padre, nombre) == EXIT_FAILURE) {

		for (i = 0; i <= string_length(nombre); i++) {

			if (i != string_length(nombre)) {
				caracter_nombre = string_substring(nombre, i, 1);
				archivo_nuevo->fname[i] = *caracter_nombre;
			} else {
				archivo_nuevo->fname[i] = '\0';
			}

		}
		archivo_nuevo->parent_directory = posicion_padre;
		archivo_nuevo->first_block = 0xFFFFFFFF;
		archivo_nuevo->lastmod = (uint32_t) temporal_get_string_time();
		archivo_nuevo->state = REGULAR;
		archivo_nuevo->file_size = 0;

		grabarEnTablaArchivos(archivo_nuevo);

		return EXIT_SUCCESS;

	} else {

		perror(
				"No se puede crear Archivo: Nombre de archivo/carpeta ya existe.\n");

		return EXIT_FAILURE;
	}
}

int crearUnDirectorio(char* path) {
	int i;
	uint16_t posicion_padre;
	osada_file* archivo_nuevo;
	char* padre;
	char *nombre;

	nombre = strrchr(path, '/') + 1;

	padre = string_substring(path, 0,
			string_length(path) - string_length(nombre));

	if (string_length(nombre) > 17) {
		perror(
				"No se puede crear Directorio: Nombre de archivo mayor a 17 caracteres.\n");
		free(nombre);
		free(padre);
		return EXIT_FAILURE;
	}

	if (hayNodosDispoibles() == EXIT_FAILURE) {
		perror(
				"No se puede crear directorio: No hay nodos disponibles en la tabla de archivos.\n");
		free(nombre);
		free(padre);
		return EXIT_FAILURE;
	}

	archivo_nuevo = malloc(sizeof(osada_file));

	if (!string_equals_ignore_case(padre, "/")) {
		//chequeo si existe la ruta destino donde quiero crear archivo

		posicion_padre = buscarPosicionTablaArchivos(padre);
		if (posicion_padre == -99) {
			perror(
					"No se puede crear Directorio: No existe ruta destino en Tabla de Archivos.\n");
			free(nombre);
			free(padre);
			free(archivo_nuevo);
			return EXIT_FAILURE;

		}

		if (INICIO_TABLA_DE_ARCHIVOS[posicion_padre].state == DELETED) {
			perror("No se puede crear Directorio: No existe ruta destino.\n");
			free(nombre);
			free(padre);
			free(archivo_nuevo);
			return EXIT_FAILURE;
		}

	} else {
		posicion_padre = OSADA_RAIZ;
	}

	//chequear si existe un directorio con el mismo nombre en la ruta destino
	if (existeNombre(posicion_padre, nombre) == EXIT_FAILURE) {

		for (i = 0; i < string_length(nombre); i++) {
			archivo_nuevo->fname[i] = nombre[i];
		}
		archivo_nuevo->fname[i] = '\0';
		archivo_nuevo->parent_directory = posicion_padre;
		archivo_nuevo->first_block = 0xFFFFFFFF;
		archivo_nuevo->lastmod = (uint32_t) temporal_get_string_time();
		archivo_nuevo->state = DIRECTORY;
		archivo_nuevo->file_size = 0;

		grabarEnTablaArchivos(archivo_nuevo);

		free(archivo_nuevo);
		return EXIT_SUCCESS;

	} else {

		perror(
				"No se puede crear directorio: Nombre de archivo/carpeta ya existe.\n");

		free(archivo_nuevo);
		return EXIT_FAILURE;
	}
}

int borrarDirectorio(char* nombre) {
	uint16_t posicion;
	osada_file *archivo;
	int i;
	char* nombre_archivo;
	char* path_file;
	nombre_archivo = malloc(sizeof(osada_file));
	t_list* existArchivo;

	existArchivo = existeArchivo(nombre); //chequeo si existe el directorio que quiero borrar
	if (existArchivo == NULL) {
		perror("No se puede eliminar: No existe el directorio.\n");
		return EXIT_FAILURE;
	}

	posicion = buscarPosicionTablaArchivos(nombre);

	if (posicion == -99) {
		perror(
				"No se puede eliminar: No existe el directorio en Tabla de Archivos.\n");

		return EXIT_FAILURE;

	} else {
		INICIO_TABLA_DE_ARCHIVOS[posicion].state = DELETED;
		for (i = 0; i < list_size(existArchivo); i++) {

			archivo = list_get(existArchivo, i);
			nombre_archivo = (char*) archivo->fname;

			path_file = string_duplicate(nombre);

			string_append(&path_file, "/");

			string_append(&path_file, nombre_archivo);

			if (borrarArchivo(path_file) == EXIT_FAILURE) {
				perror("No se pudo eliminar el archivo.\n");
			}
		}
	}

	return EXIT_SUCCESS;
}

int initOsada(char* pathOsadaDrive) {

	//TODO: Verificar si debo grabar disco completo al modificar tabla de archivos, tabla de asignaciones, bitmap, bloque datos, etc
	//TODO:esta ruta se asigna dinamicamente.
	if (mapearDisco(pathOsadaDrive) == NULL) {
		perror("Error mapeando el fileSystem.\n");
		exit(EXIT_FAILURE);
	}

	//Header
	header_file = leerHeader();
	if (header_file == NULL) {
		return EXIT_FAILURE;
	}

	imprimirHeader(header_file);
	/* printf("\n");
	 printf("--------");
	 printf("\n");*/

	//Bitmap
	bitArray = leerBitArray();
	bitmap = bitarray_create_with_mode(bitArray, header_file->fs_blocks / 8,
			MSB_FIRST);

	BITMAP = bitmap;
	if (BITMAP == NULL) {
		return EXIT_FAILURE;
	}
	/*imprimirBitmap(bitmap);
	 printf("\n");
	 printf("--------");
	 printf("\n");*/

	//Tabla de Archivos
	tabla_archivo = leerInicioTablaArchivo();
	if (tabla_archivo == NULL) {
		return EXIT_FAILURE;
	}

	//imprimirTablaArchivos(tabla_archivo);

	//Tabla de Asignaciones
	tabla_de_asignaciones = inicioTablaAsignaciones(header_file);
	if (tabla_de_asignaciones == NULL) {
		return EXIT_FAILURE;
	}
	//Tabla de Datos
	tabla_de_datos = inicioTablaDatos(header_file);
	if (tabla_de_datos == NULL) {
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;

}

/*
 *
 * void guardarEnOsada2(int desde, void *elemento, int tamaniaDelElemento){
 printf("iniciio guardarEnOsada2\n");
 memcpy(&OSADA[desde], elemento, tamaniaDelElemento);
 printf("fin guardarEnOsada2\n");
 }

 void guardarEnOsada(unsigned char *osada, int desde, void *elemento, int tamaniaDelElemento){
 memcpy(&osada[desde], elemento, tamaniaDelElemento );
 int status = munmap(osada, tamaniaDelElemento);

 if (status == -1)
 printf("Estado del munmap: %i\n", status);
 }
 * */
