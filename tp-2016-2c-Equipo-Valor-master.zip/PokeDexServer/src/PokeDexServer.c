/*
 ============================================================================
 Name        : PokeDexServer.c
 Author      : Emanuel y Marce
 Version     :
 Copyright   : Your copyright notice
 Description : Server Poke Dex
 ============================================================================
 */

#include "PokeDexServer.h"

int socketServer;
int socketCliente;

pthread_t hiloConexiones;
pthread_t hiloCliente;
t_msjCabecera* cabeceraMsj;

char* obtenerUltimoDirPath(char* path, int len){
	char* fullpath= malloc((sizeof(char)*len)+1);
	fullpath= string_duplicate(path);
	char *ssc;
	int l = 0;
	ssc = strstr(fullpath, "/");
	do{
		l = strlen(ssc) + 1;
		path = &path[strlen(fullpath)-l+2];
		ssc = strstr(fullpath, "/");
	}while(ssc);
	return fullpath;
}

void manejarConexionesRecibidas() {
	printf("Esperando conexiones Clientes.\n");
	log_info(log, "Esperando conexiones Clientes.");
	socketCliente = AceptarConexionCliente(socketServer);
	if (socketCliente < 0) {
		log_error(log,"Ocurrio un error al intentar aceptar una conexion de Cliente");
		printf("Ocurrio un error al intentar aceptar una conexion de Cliente\n");
	} else {
		log_info(log, "Se conecto Cliente.");
		printf("Se conecto Cliente\n");
	}

	pthread_create(&hiloCliente, NULL, (void *) manejarConexionCliente, NULL);

	pthread_join(hiloCliente, NULL);
}

void manejarConexionCliente() {
	while (1) {
		pthread_t hiloEscuchaCliente;
		socketCliente = AceptarConexionCliente(socketServer);
		if (socketCliente < 0) {
			log_error(log,"Ocurrio un error al intentar aceptar una conexion de Cliente Socket: %d.", socketCliente);
			printf("Ocurrio un error al intentar aceptar una conexion de Cliente Socket: %d .\n", socketCliente);
		} else {
			log_info(log, "Nueva conexion de Cliente.");
			printf("Nueva conexion de clinete.\n");
			t_PD_Cliente* pdClietne = malloc(sizeof(pdClietne));
			pdClietne->socketCliente = socketCliente;
			pthread_create(&hiloEscuchaCliente, NULL, (void*) manejarPeticionesCliente, pdClietne);//TODO: socket cliente se pasa hasta nuevos avances.
			pdClietne->hiloCliente = hiloEscuchaCliente;
		}
	}
}

void manejarPeticionesCliente(t_PD_Cliente* pdCliente) {
	while (1) {
		log_debug(log, "Esperando solicitud de Cliente %d.", pdCliente->socketCliente);

		cabeceraMsj = malloc(sizeof(t_msjCabecera));

		char* mensajeRecibido = recibirMsjConEncabezado(pdCliente->socketCliente, cabeceraMsj);

		if (mensajeRecibido == NULL) {
			log_error(log,"No se recibio ningun dato del Cliente %d. Cierro conexion", pdCliente->socketCliente);
			printf("No se recibio ningun dato del Cliente %d. Cierro conexion\n", pdCliente->socketCliente);
			close(pdCliente->socketCliente);
			pthread_join(pdCliente->hiloCliente, NULL);
			break;
		} else {
			t_mensaje_GETATTR* msjGetAttr = malloc(sizeof(t_mensaje_GETATTR));
			t_msjCabecera* cabeceraRespuestaFS = malloc(sizeof(t_msjCabecera));
			t_mensaje_WRITE* msjWrite = malloc(sizeof(t_mensaje_WRITE));
			t_mensaje_RENAME* msjRename = malloc(sizeof(t_mensaje_RENAME));
			t_mensaje_TRUNCATE* msjTruncate = malloc(sizeof(t_mensaje_TRUNCATE));
			osada_file* archivo;
			t_list* files = list_create();
			t_list* osadaFiles = list_create();
			char* archivoContenido;
			char* msjRespuesta;
			int iFile;
			int resultado;

			int* largoPaquete = malloc(sizeof(largoPaquete));

			char* archivoNombre;
			int archivoLeng;

			switch(cabeceraMsj->tipoMensaje){
			case GETATTR:
				archivoNombre = string_substring_until(mensajeRecibido, cabeceraMsj->logitudMensaje);
				archivo = getAtributos(archivoNombre);
				if (archivo != NULL) {
					msjGetAttr->mode = 0; //TODO:definir que va aca
					msjGetAttr->nLink = archivo->state;
					msjGetAttr->size = archivo->file_size;
					msjGetAttr->lastMod = archivo->lastmod;
				} else {
					msjGetAttr->mode = 0;
					msjGetAttr->nLink = 0;
					msjGetAttr->size = 0;
					msjGetAttr->lastMod = 0;
				}
				msjRespuesta = empaquetarGETATTR(msjGetAttr, largoPaquete);
				cabeceraRespuestaFS->tipoMensaje = GETATTR;
				cabeceraRespuestaFS->logitudMensaje = *largoPaquete;
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta,	cabeceraRespuestaFS);
				free(msjGetAttr);
				break;
			case READDIR:
				archivoNombre = string_substring_until(mensajeRecibido, cabeceraMsj->logitudMensaje);
				osadaFiles = existeArchivo(archivoNombre);
				for(iFile=0; iFile < list_size(osadaFiles); iFile++){
					archivo = list_get(osadaFiles, iFile);
					archivoLeng = strlen(archivo->fname) + 1;
					list_add(files,	file_create(archivo->fname,	archivoLeng));
				}

				msjRespuesta = empaquetarDirectorio(files, largoPaquete);

				cabeceraRespuestaFS->tipoMensaje = READDIR;
				cabeceraRespuestaFS->logitudMensaje = *largoPaquete;
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta,	cabeceraRespuestaFS);
				list_destroy(files);
				list_destroy(osadaFiles);
				break;
			case READFILE:
				archivoNombre = string_substring_until(mensajeRecibido, cabeceraMsj->logitudMensaje);
				archivoContenido = leerArchivo(archivoNombre, largoPaquete);
				cabeceraRespuestaFS->tipoMensaje = READDIR;
				cabeceraRespuestaFS->logitudMensaje = *largoPaquete;
				enviarMsjConEncabezado(pdCliente->socketCliente, archivoContenido, cabeceraRespuestaFS);
				break;
			case MKDIR:
				archivoNombre = string_substring_until(mensajeRecibido, cabeceraMsj->logitudMensaje);
				log_info(log,"archivoNombre");
				log_info(log,archivoNombre);
				resultado = crearUnDirectorio(archivoNombre);
				log_info(log,"mkdir_result");
				log_info(log,resultado);

				cabeceraRespuestaFS->tipoMensaje = MKDIR;
				if(resultado==EXIT_SUCCESS){
					msjRespuesta = string_from_format("%s", "OK");
					string_append(&msjRespuesta, "\0");
				}else{
					msjRespuesta = string_from_format("%s", "NO_OK");
					string_append(&msjRespuesta, "\0");
				}
				cabeceraRespuestaFS->logitudMensaje = string_length(msjRespuesta)+1;
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta, cabeceraRespuestaFS);
				break;

			case WRITE:
				msjWrite = desempaquetarWRITE(mensajeRecibido);
				resultado = escribirArchivo(msjWrite->buffer, msjWrite->path, msjWrite->size);
				cabeceraRespuestaFS->tipoMensaje = WRITE;
				cabeceraRespuestaFS->logitudMensaje = sizeof(msjWrite);
				memcpy(msjRespuesta, &resultado, sizeof(resultado));
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta, cabeceraRespuestaFS);
				free(msjWrite);
				break;
			case CREATE:
				archivoNombre = string_substring_until(mensajeRecibido, cabeceraMsj->logitudMensaje);
				resultado = crearUnArchivo(archivoNombre);
				cabeceraRespuestaFS->tipoMensaje = CREATE;
				cabeceraRespuestaFS->logitudMensaje = sizeof(resultado);
				msjRespuesta = malloc(resultado);
				memcpy(msjRespuesta, &resultado, sizeof(resultado));
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta, cabeceraRespuestaFS);
				break;
			case RENAME:
				msjRename = desempaquetarRENAME(mensajeRecibido);
				resultado = renombrarArchivo(msjRename->oldname, msjRename->newname);
				cabeceraRespuestaFS->tipoMensaje = RENAME;
				cabeceraRespuestaFS->logitudMensaje = sizeof(resultado);
				msjRespuesta = malloc(resultado);
				memcpy(msjRespuesta, &resultado, sizeof(resultado));
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta, cabeceraRespuestaFS);
				free(msjRename);
				break;
			case UNLINK:
				archivoNombre = string_substring_until(mensajeRecibido, cabeceraMsj->logitudMensaje);
				resultado = borrarArchivo(archivoNombre);
				cabeceraRespuestaFS->tipoMensaje = UNLINK;
				cabeceraRespuestaFS->logitudMensaje = sizeof(resultado);
				msjRespuesta = malloc(resultado);
				memcpy(msjRespuesta, &resultado, sizeof(resultado));
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta, cabeceraRespuestaFS);
				break;
			case TRUNCATE:
				msjTruncate = desempaquetarTRUNCATE(mensajeRecibido);
				//resultado = renombrarArchivo(msjTruncate->filename, msjTruncate->newLen);
				cabeceraRespuestaFS->tipoMensaje = TRUNCATE;
				cabeceraRespuestaFS->logitudMensaje = sizeof(resultado);
				msjRespuesta = malloc(resultado);
				memcpy(msjRespuesta, &resultado, sizeof(resultado));
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta, cabeceraRespuestaFS);
				free(msjTruncate);
				break;
			default:
				cabeceraRespuestaFS->tipoMensaje = ERROR;
				cabeceraRespuestaFS->logitudMensaje = 0;
				msjRespuesta = NULL;
				enviarMsjConEncabezado(pdCliente->socketCliente, msjRespuesta, cabeceraRespuestaFS);
				break;
			}

			free(largoPaquete);
			if (archivoNombre != NULL)
				free(archivoNombre);
			if (msjRespuesta != NULL)
				free(msjRespuesta);
			free(cabeceraRespuestaFS);
		}

		free(mensajeRecibido);
	}
}

int main(int argc, char *argv[]) {

	crearLog("PokeDexServer.log", "PokeDexServer");

	char * configFilePath;
	char * discoFilePath;

	if (argc != 3) {
		log_error(log, "Error de recepcion de parametros.");
		printf("No se recibieron los parametros correctamente \n");
		printf("-->%s [PATH\\DiscoOsada.bin] [PATH\\PokeDecServer.conf]\n", argv[0]);
		return EXIT_FAILURE;
	}
	else{
		discoFilePath = malloc(strlen(argv[1]));
		discoFilePath = argv[1];
		configFilePath = malloc(strlen(argv[2]));
		configFilePath = argv[2];
	}

	char* configPath = configFilePath;//"./PokeDecServer.conf";

	char* discoOsada = discoFilePath;//"/home/utnso/git/osada-utils/challenge.bin";

	config = malloc(sizeof(t_config_server));

	if(cargarConfig(configPath, config)==1){
		perror("Error cargando configuracion del servidor.");
		printf("Error cargando configuracion del servidor.\n");
		return EXIT_FAILURE;
	}
	socketServer = IniciarSocketServidor(config->puerto);
	if(socketServer==-1){
		perror("Finalizacion de server, no se puso asignar socket.\n");
		printf("Finalizacion de server, no se puso asignar socket.\n");
		return EXIT_FAILURE;
	}

	if(initOsada(discoOsada)==1){
		perror("Error levantando el FileSystem.");
		printf("Error levantando el FileSystem.\n");
		return EXIT_FAILURE;
	}

	printf("Servidor listo, esperando conexiones.\n");
	//pthread_create(&hiloConexiones, NULL, (void *) manejarConexionCliente,	NULL);
	manejarConexionCliente();
	//pthread_join(hiloConexiones,NULL);

	log_info(log, "Proceso PokeDexServer finalizado");
	printf("Proceso PokeDexServer finalizado\n");

	finalizarConfig();
	free(config);
	return EXIT_SUCCESS;
}


