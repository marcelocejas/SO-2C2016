/*
 ============================================================================
 Name        : PokeDexServer.c
 Author      : Emanuel y Marce
 Version     :
 Copyright   : Your copyright notice
 Description : Server Poke Dex
 ============================================================================
 */

#include "PokeDexServer.h"

int main(int argc, char *argv[]) {

	crearLog("PokeDexServer.log", "PokeDexServer");

	char* directorio = "/PRUEBAFINAL";
	char* archivo = "/PRUEBAFINAL/ARCHIVO-1.txt";
	char* archivo2 = "/PRUEBAFINAL/ARCHIVO-2.txt";
	char* archivo3 = "/PRUEBAFINAL/ARCHIVO-3.txt";
	char* datos_archivo;
	char* datos_archivo2;
	char* datos_archivo3;
	int cantidad;
	long int* largoArchivo;
	long int* largoArchivo2;
	long int* largoArchivo3;
	char* archivoContenido;
	char* archivoContenido2;
	char* archivoContenido3;
	char* archivoN = "/PRUEBAFINAL/ARCHIVO-NEW.txt";
	char* directorioN = "/PRUEBAFIN";
	char* archivoN2 = "/PRUEBAFIN/ARCHIVO-2.txt";

	datos_archivo = "ESCRIBO EL PRIMER ARCHIVO";
	datos_archivo2 = "ESCRIBO EL SEGUNDO ARCHIVO";
	datos_archivo3 = "ESCRIBO EL TERCER ARCHIVO";

	largoArchivo = malloc(sizeof(OSADA_BLOCK_SIZE));
	largoArchivo2 = malloc(sizeof(OSADA_BLOCK_SIZE));
	largoArchivo3 = malloc(sizeof(OSADA_BLOCK_SIZE));
	archivoContenido = malloc(sizeof(OSADA_BLOCK_SIZE));
	archivoContenido2 = malloc(sizeof(OSADA_BLOCK_SIZE));
	archivoContenido3 = malloc(sizeof(OSADA_BLOCK_SIZE));

	*largoArchivo = 25;
	*largoArchivo2 = 26;
	*largoArchivo3 = 25;

	char* discoOsada = "/home/utnso/git/osada-utils/challenge.bin";
	if (initOsada(discoOsada) == 1) {
		printf("Error levantando el FileSystem.\n");
		return EXIT_FAILURE;
	}


	listarDirectorio("/");
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");


	if (crearUnDirectorio(directorio) == EXIT_FAILURE) {
		printf("Error creando DIRECTORIO.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	if (crearUnArchivo(archivo) == EXIT_FAILURE) {
		printf("Error creando ARCHIVO.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	if (crearUnArchivo(archivo2) == EXIT_FAILURE) {
		printf("Error creando ARCHIVO-2.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	if (crearUnArchivo(archivo3) == EXIT_FAILURE) {
		printf("Error creando ARCHIVO-3.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	listarDirectorio(directorio);
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	cantidad = escribirArchivo(datos_archivo, archivo, *largoArchivo);
	if (cantidad != *largoArchivo) {
		printf("Error escribiendo ARCHIVO.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	cantidad = escribirArchivo(datos_archivo2, archivo2, *largoArchivo2);
	if (cantidad != *largoArchivo2) {
		printf("Error escribiendo ARCHIVO-2.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	cantidad = escribirArchivo(datos_archivo3, archivo3, *largoArchivo3);
	if (cantidad != *largoArchivo3) {
		printf("Error escribiendo ARCHIVO-3.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	archivoContenido = leerArchivo(archivo, (int*) largoArchivo);
	if (!string_equals_ignore_case(archivoContenido, datos_archivo)) {
		printf("Error leyendo ARCHIVO.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	archivoContenido2 = leerArchivo(archivo2, (int*) largoArchivo2);
	if (!string_equals_ignore_case(archivoContenido2, datos_archivo2)) {
		printf("Error leyendo ARCHIVO-2.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	archivoContenido3 = leerArchivo(archivo3, (int*) largoArchivo3);
	if (!string_equals_ignore_case(archivoContenido3, datos_archivo3)) {
		printf("Error leyendo ARCHIVO-3.\n");
	}
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	if (renombrarArchivo(archivo, archivoN) == EXIT_FAILURE) {
		printf("Error renombrando FILE.\n");

	}
	listarDirectorio(directorio);

	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	if (renombrarArchivo(directorio, directorioN) == EXIT_FAILURE) {
		printf("Error renombrando DIR.\n");

	}
	listarDirectorio("/");
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	if (borrarArchivo(archivoN2) == EXIT_FAILURE) {
		printf("Error eliminando FILE.\n");

	}
	listarDirectorio(directorioN);
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	if (borrarDirectorio(directorioN) == EXIT_FAILURE) {
		printf("Error eliminando DIR-N.\n");

	}
	listarDirectorio("/");
	printf(
			"-----------------------------------------------------------------------------------------------------------------------------------------------\n");

	free(largoArchivo);
	free(largoArchivo2);
	free(largoArchivo3);
	free(archivoContenido);
	free(archivoContenido2);
	free(archivoContenido3);

	return EXIT_SUCCESS;
}
