#ifndef __OSADA_H__
#define __OSADA_H__

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <commons/bitarray.h>
#include <commons/string.h>
#include <commons/collections/list.h>
#include <commons/temporal.h>
#include <src/tiposDato.h>
#include "Log.h"

#define OSADA_BLOCK_SIZE 64
#define OSADA_FILENAME_LENGTH 17
#define OSADA_TABLA_ARCHIVO_LENGTH 2048
#define OSADA_RAIZ 0xFFFF

typedef unsigned char osada_block[OSADA_BLOCK_SIZE];
typedef uint32_t osada_block_pointer;

// set __attribute__((packed)) for this whole section
// See http://stackoverflow.com/a/11772340/641451
#pragma pack(push, 1)

typedef struct {
	unsigned char magic_number[7]; // OSADAFS
	uint8_t version;
	uint32_t fs_blocks; // total amount of blocks
	uint32_t bitmap_blocks; // bitmap size in blocks
	uint32_t allocations_table_offset; // allocations table's first block number
	uint32_t data_blocks; // amount of data blocks
	unsigned char padding[40]; // useless bytes just to complete the block size
} osada_header;

_Static_assert( sizeof(osada_header) == sizeof(osada_block), "osada_header size does not match osada_block size");

typedef enum
	__attribute__((packed)) {
		DELETED = '\0', REGULAR = '\1', DIRECTORY = '\2',
} osada_file_state;

_Static_assert( sizeof(osada_file_state) == 1, "osada_file_state is not a char type");

typedef struct {
	osada_file_state state;
	unsigned char fname[OSADA_FILENAME_LENGTH];
	uint16_t parent_directory;
	uint32_t file_size;
	uint32_t lastmod;
	osada_block_pointer first_block;
} osada_file;

static osada_header *HEADER_FILE;
static t_bitarray *BITMAP;
static char *TABLA_DE_DATOS;
static osada_block_pointer *TABLA_DE_ASIGNACIONES;
static osada_file *INICIO_TABLA_DE_ARCHIVOS;


_Static_assert( sizeof(osada_file) == (sizeof(osada_block) / 2.0), "osada_file size does not half osada_block size");

#pragma pack(pop)

int initOsada(char* pathOsadaDrive);
osada_header* leerHeader(void);
int* mapearDisco(char*);
osada_file* leerInicioTablaArchivo();
t_bitarray* leerBitArray();
t_list* cargarListaTablaArchivo();
void listarDirectorio(char* ruta);
t_list* existeArchivo(char* ruta);
char* stringFromOsadaFileState(osada_file_state f);
char* leerArchivo(char* ruta, int* largoArchivo);
char* buscarBloqueDatos(osada_block_pointer posicion_bloque);
osada_block_pointer* buscarProximoBloque(osada_block_pointer posicion_bloque);
osada_file* getAtributos(char* ruta);
unsigned int redondeando(unsigned int dividendo, unsigned int divisor);
void imprimirHeader(osada_header*);
void imprimirBitmap(t_bitarray * bitArray);
void imprimirTablaArchivos(osada_file * tablaArchivos);
int hayNodosDispoibles();
uint32_t** buscarBloquesLibres(int file_size_blocks);
uint32_t** buscarBloquesAsignados(int file_size_blocks, osada_block_pointer primer_bloque);
uint16_t buscarPosicionTablaArchivos(char* path);
uint16_t buscarPosicionTablaArchivos2(char* path);
osada_block_pointer* inicioTablaAsignaciones(osada_header* header_file);
void grabarEnTablaArchivos(osada_file* archivo);
void reemplazarEnTablaArchivos(osada_file* archivo, uint16_t posicion);
void grabarEnTablaAsignaciones(uint32_t** bloques_libres);
void grabarBloque(char* bloque_datos, osada_block_pointer posicion_bloque, int cantidad_a_copiar);
int grabarDatos2(uint32_t** bloques_libres, char* buffer, int cantidad_bloques, long int tamanio);
void setearBitmapOcupados(uint32_t** bloques_libres);
int existeNombre(uint16_t posicion_padre, char* fname);
int moverArchivo(char* file, char* path);
int escribirArchivo(char *buffer, char* path, long int tamanio);
int truncarArchivo(char* path, long int tamanio);
int crearUnArchivo(char* path);
int crearUnDirectorio(char* path);
void cleanBitmap(uint32_t** bloques_asignados);
int borrarArchivo(char* ruta);
int borrarDirectorio(char *nombre);
int renombrarArchivo(char *nombre, char *nuevoNombre);

void guardarCambiosEnOsada(int desde, void *elemento, int largoDelElemento);


#endif /*__OSADA_H__*/
