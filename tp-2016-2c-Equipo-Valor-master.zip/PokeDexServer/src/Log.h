/*
 * Loh.h
 *
 *  Created on: 10/10/2016
 *      Author: utnso
 */

#ifndef SRC_LOG_H_
#define SRC_LOG_H_
#include <stdio.h>
#include <stdlib.h>
#include <commons/log.h>

t_log* log;

t_log* crearLog(char* , char* );

#endif /* SRC_LOG_H_ */
